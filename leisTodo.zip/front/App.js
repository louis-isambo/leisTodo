import { leistrap } from "./leistrap1.0/leistrap.js"
import { Setting } from "./ls.setting.js"
import { dataAPI } from "./src/todo/dataApis/dataApi.js"
import { App } from "./src/app.js"
import { dataAPI as df, initData } from "./src/todo/data.js"


export function leisMain() {
  initData()
  var param = Setting(leistrap)
  leistrap.whenReady(function () {
    leistrap.event.handle("main", (e) => e.send(this))
    if (param.dataAPI) {
      if (param.dataAPI.web && !param.dataAPI.local && !param.dataAPI.vd) {
        dataAPI.LeisTodoWebApi(param.dataAPI.web.address, leistrap)
      }
      if (param.dataAPI.local && !param.dataAPI.web && !param.dataAPI.vd) {
        dataAPI.LeisTodoLocalApi()
      }
      if (param.dataAPI.vd && !param.dataAPI.web && !param.dataAPI.local) {
        dataAPI.VirtualData(leistrap.event, df.MainTaskList, param.dataAPI.vd.name)
      }
    }
    leistrap.event.invoke("dataApi", null, (data_) => this.add(App(param, data_)))
  })

  leistrap.render("main")
}

