
export interface _Leis<type> {
    isUndifend: (obj) => bool
    isArray: (obj) => bool
    isObject: (obj) => bool
    isString: (obj) => bool
    isNumber: (obj) => bool
    isFunction: (obj) => bool
    setEmptyArray: (arr) => Array<any>
    isNone: (obj)=> bool
    isEmpty: (obj) => bool
    has: (prop, obj) => bool
    isTypeOf: (prop, obj) => bool,
    copyObject: (obj, target, overwrite :bool, ...exp) => object
    copyArray: (arr, target, overwrite : bool) => object
    getUrl: (o) => null | any
    hasUrl: (o) => bool
    arrayRemove: (index, arr) => void
    arrayReplace: (index, value, arr) => Array<any>
    arrayInsert: (index, arr, args) => Array<any>
    tryCode: (callback, error) => void
    after: (s, func, ...args) => void
    loopObj: (obj, callback : (value, key, index, finished) => any) => void

    bindFunc: (fc, bc) => Function

    arrAddWhen: (arr, item, num1, num2, callback) => void 
    arrBegin: (condi, callback) => void
    initObj: (obj, value) => void
    objKeysToLowerCase:  (o) => Object
    filter: (o, callback)=> Object 
    defineObj: (obj, proName, value, writable : bool) => void
    countArray: ()=> void,
}

type bool = true | false