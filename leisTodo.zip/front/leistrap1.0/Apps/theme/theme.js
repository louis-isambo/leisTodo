import { leistrap } from "../../leistrap.js";
import light from "./themes/light.css"
import dark from "./themes/dark.css"

export function Theme() {
    "use strict";

    leistrap.defineExtension("theme", function (option, Core, { obj }) {
        if (!option) option = {};
        if (!option.theme) option.theme = "light";
        if (!option.dir) option.dir = "./"


        const _themes_ = {
            light: light,
            dark: dark
        }
        let TN = obj.has(option.theme, _themes_) ? option.theme : "light"
        const _theme_ = Core.addStyle(_themes_.light)

        function Theme(name) {
            if (obj.has(name, themes)) {
                _theme_.addAttr("href",
                    `${option.theme.dir}Apps/theme/themes/${name}.css`)
            }
        }
        return Theme
    })
}