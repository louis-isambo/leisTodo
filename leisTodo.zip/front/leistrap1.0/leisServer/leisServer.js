var express = require("express")
var stream = require("fs")
var use = require("./aoi.js")

var app = express()

var port = 3000

var read = stream.createReadStream("./index.html")
app.get("/", function(req, res){
    res.set("Content-type", "text/html")
    read.on("data", function(chunk){
        res.send(chunk.toString())
    })
    
})
app.get("/name/:user_name", function(req, resp){
    resp.status(200)
    resp.set("Content-type", "text/html")
    resp.send(`<h1> Hllo ${req.params.user_name}</h1>`)
})
app.use("/admin",function(req, res, next){
    res.redirect("/")
    console.log("%s %s - %s", (new Date).toString(), req.method, req.url);
    // return next()
})


app.get("/search", function(req, res){
    res.send(JSON.stringify({name:"louis"}))
} )

app.get("/use/:setting", function(req, res){
    if (req.params.setting == "close"){
        console.log("Server is closed ")
        process.exit(1)
    }
    use.use[req.params.setting]()
})
app.listen(port, function(){
    console.log("server start at http://localhost:%s", port)
})

