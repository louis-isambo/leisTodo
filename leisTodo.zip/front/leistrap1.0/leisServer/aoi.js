var os =  require("os")
module.exports.use = {
    displayInfo : (req, res)=>{
        console.log(os.popen);
    }
}

