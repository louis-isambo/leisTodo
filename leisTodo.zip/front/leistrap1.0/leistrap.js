
import { ls } from "./dist/leistrap.main.js";

const leistrap = ls

export { leistrap }