
const VirtualData = function (event, data, name) {

    // localStorage.removeItem(name)
    // verify if there is a leisVD item into the localStorage

    if (localStorage.getItem(name)) {

        const data = JSON.parse(localStorage.getItem(name))

        event.handle("data:all", (e) => e.send(data))
        event.handle("data:makechanges", (e) => updateData(data))
        event.handle("data:add:task", (e, newTask) => addNewTask(newTask, data))
        event.handle("data:add:tasklist", (e, newTasklist) => addNewTasklist(newTasklist, data))
        event.handle("data:tasks", (e) => e.send(data.tasks || []))
        event.handle("data:folders", (e) => e.send(data.folders || []))
        event.handle("data:tasklist", (e) => e.send(data.tasklist || []))
        event.handle("data:update", (e) => updateData(data))
        event.handle("data:add:folder", (e, newFolder) => addNewFolder(newFolder, data))

    }
    else { localStorage.setItem(name, setDefaultData()) }

    function setDefaultData() {
        // console.log(data);
        return JSON.stringify({ tasklist: data })
    }

    function updateData(changes) {
        localStorage.clear();
        if (localStorage.getItem(name)) localStorage.removeItem(name)
        localStorage.setItem(name, JSON.stringify(changes))
    }

    function addNewTask(newTask, data) {
        if (!data.tasks) data.tasks = []
        data.tasks.push(newTask)
        updateData(data)
    }

    function addNewTasklist(newTasklist, data) {
        if (!data.tasklist) data.tasklist = [];
        data.tasklist.push(newTasklist)
        updateData(data)
    }

    function addNewFolder(folderObject, data) {
        if (!data.folders) data.folders = [];
        data.folders.push(folderObject)
        updateData(data)
    }
}


export { VirtualData }