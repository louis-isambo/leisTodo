

const LeisTodoWebApi = function (address, leistrap) {

    fetch(`${address}/api/all_data`).then(data => {
        data.json().then(d => {
            leistrap.event.handle("data:all", (e) => e.send(d))
        })
    })

    leistrap.event.handle("data:update", function (event, o) {
        var data = []
        for (var c of JSON.stringify(o)) {
            data.push(c.charCodeAt(0))
        }
        fetch(`${address}/api-update/${data.join("_")}`)
    })

}

export { LeisTodoWebApi }