import { LeisTodoWebApi } from "./web.js";
import { LeisTodoLocalApi } from "./local.js"
import { VirtualData } from "./virtualdata.js";

const dataAPI = { LeisTodoWebApi, LeisTodoLocalApi, VirtualData }
export { dataAPI }