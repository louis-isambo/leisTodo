
const LeisTodoLocalApi = function () {

}

export { LeisTodoLocalApi }

// const DB = {}

// class Models {
//     constructor(name, columns) {
//         this.name = name;
//         this.columns = columns;
//         DB[this.name] = accessTable(this.columns)
//     }

//     static foreign(tableName) {
//         if (tableName instanceof Models) {
//             return accessTable(tableName)
//         }
//     }
//     create(columns) { console.log(DB[this.name].create); }
// }

// function accessTable(name) {
//     function e() {
//         const table = []
//         var newObject = {}

//         this.create = function (o) {
//             Object.keys(name).forEach(item => {
//                 newObject[item] = o[item]
//             })
//             table.push(newObject)
//             return newObject
//         }

//     }
//     e.create = "cre"
//     return e

// }


// const Students = new Models("student", {
//     name: String,
//     age: Number
// })

// var is = Students.create({
//     name: "isambo",
//     age: 15
// })

// console.log(is);