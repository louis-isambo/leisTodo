import { today } from "./tasklist/today"
import { tomorrow } from "./tasklist/tomorrow"
import { sevenDays } from "./tasklist/sevenDays"
import { inbox } from "./tasklist/inbox"
import { tags } from "./tasklist/tags"
import { folders } from "./tasklist/folders"
import { formTask } from "../_todo/formtask.js"
import { Color_ } from "../_todo/color.js"
import { tasksOperator } from "../_todo/tasksOpera.js"
import { tasklistOperator } from "../_todo/ftasklistOpera.js"
import { folderOperator } from "../_todo/folderOpera.js"

const tasklist = (function (leistrap, data, colorPalette) {

    // init all dependencies


    formTask(leistrap, data)
    Color_(leistrap, colorPalette)
    tasksOperator(leistrap, data)
    tasklistOperator(leistrap, data)
    folderOperator(leistrap)

    /*
    taskList functionality

    create a sideBar for taskLisk tab Button.
    the first functionality of the application, it about Todtasks,
    create, modification etc.. of the task. this first functionality contains others 
    subfunctionalities.

        1. Aujourd'hui:         -today
        2. Demain               -tomorrow
        3. Prochains jours      -sevenDays
        4. Boîte de réception   -inbox
        5. Étiquettes*          -tags
        6. Dossiers             -foldes
    we will create a tabPage for each subfunctionlity, these will be in the "ui5.body" part as content
     */

    // create a collapsible for displaying all foldes
    const CONTENT_FOLDER_COLL = leistrap.GroupItem({ items: [] })
    const coll = leistrap.Collapsible({
        caption: "Dossiers",
        content: [CONTENT_FOLDER_COLL]
    })
    //configure our main folder parentList and expose that
    CONTENT_FOLDER_COLL.folderConf = { name: "main", id: "mainFolder" }
    leistrap.event.handle("folderId:mainmainFolder", event => event.send(CONTENT_FOLDER_COLL))

    /*
        configure  the  taskList header.
        1. define the taskList functionality title
        2. make a button for adding a new task 
        3 . make a button for creating a new folder 
    */

    const GROUP_BTN = leistrap.Button().groupBtn()
    GROUP_BTN.setType("success")
    // new task button
    const NEW_TASK_BTN = GROUP_BTN.add(null)

    GROUP_BTN.on(NEW_TASK_BTN, "click", function () {
        leistrap.event.invoke("newTask", function ({ modal, result }) {
            result(da => leistrap.event.invoke("taskOperator:add", null, da, true))
            modal.show()
        })
    })

    // new folder button
    const NEW_FOLDER_BTN = GROUP_BTN.add(null)

    function showHideFolderInput(parent) {
        var input = leistrap.Input({ parent }).getTextBox()
        var folderInput = input.add(null, "folder", null,
            {
                attr: {
                    placeholder: "Nom du dossier",
                    style: "background: var(--leis-body-cl)"
                }
            })

        input.setSize(folderInput, "100%")
        leistrap.main.addEvent("click", () => input.main.hide())
        input.main.addEvent("click", (e_) => e_.stopPropagation())
        GROUP_BTN.on(NEW_FOLDER_BTN, "click", function (e) {
            e.stopPropagation()
            input.main.show()
            input.setValue(folderInput, "")
        })
        input.on(folderInput, 'keyup', function (e) {
            if (e.keyCode == 13) {
                createNewFolder(this.getValue());
                input.main.hide()
            }
        })
        return input
    }

    function createNewFolder(folderName) {
        leistrap.event.invoke("folder:operator:add",
            null, { name: folderName }, "folderId:gylainlt77Oya2tR5uVRbk403qpA92")
    }
    leistrap.event.invoke("leistrapCustom", function (custom) {
        custom.setGroupBtnIcon(NEW_FOLDER_BTN, "bi bi-folder-plus")
        custom.setGroupBtnIcon(NEW_TASK_BTN, "bi bi-card-checklist")
    })
    // the header container
    const HEADER = leistrap.Div({
        content: [leistrap.P({ text: "Be focus", attr: { className: "hd-title" } }),
        leistrap.Div({ content: [GROUP_BTN] })],
        attr: { className: "todo-sideBar-header" }
    })

    const dataTaskList = {
        "header": leistrap.Div({
            content: [HEADER, showHideFolderInput()],
            attr: { className: "todo-sideBar-header-container" }
        }),
        "items":
            [
                { "caption": "Aujourd'hui", "icon": "bi bi-calendar2-range-fill" },
                { "caption": "Demain", "icon": "bi bi-sunrise-fill" },
                { "caption": "Prochains jours", "icon": "bi bi-calendar-day-fill" },
                { "caption": "Boîte de réception", "icon": "bi bi-envelope-paper-fill" },
                { "caption": "Étiquettes", "icon": "bi bi-tags-fill" }
            ],
        collapsible: [
            [coll]
        ]
    }

    /*
    the default Tab Button , has a default content
     */
    const defaultBtn = leistrap.Input({ otherAttr: { type: "hidden" }, linkName: "default" })
    const defaultContent = leistrap.Div({ text: "Welcome to task list" })

    // options

    const options = [
        today(leistrap, data),
        tomorrow(leistrap, data),
        sevenDays(leistrap, data),
        inbox(leistrap, data),
        tags(leistrap, data),
        folders(leistrap, data)
    ]
    /*
      funtionality controller  function   
    */

    function sbFunc(side, home, tab) {

        side.allItems.forEach((i, id) => {
            const res = options[id]
            if (leistrap.dep.obj.isFunction(res)) {
                // emit the  folder:operator:addPage channel
                res(resultSended => {
                    checkFunctionalityValueReturned({ res: resultSended, id, i, tab })
                })
            }

        })
        tab.addTab(defaultBtn, defaultContent, true)

    }

    function checkFunctionalityValueReturned({ res, id, i, tab }) {

        if (res.init) {
            tab.addTab(i, res.elem, true)
            var folder = data.MainTasklist[id]
            res.elem.addData.id = folder.id + folder.root
            res.init(res.elem)
        }
        else {
            tab.addTab(i, res, true)
        }
    }
    /*
    expose the functionality to the entire application
     */

    const TaskList = {
        "funIcon": {
            "icon": "bi bi-card-checklist",
            "action": function () {
                if (!defaultBtn.dp) {
                    defaultBtn.getAttr("click"); defaultBtn.dp = true
                }
            }
        },
        "sideData": dataTaskList,
        "sbFunc": sbFunc,
    }
    return TaskList
})

export { tasklist }