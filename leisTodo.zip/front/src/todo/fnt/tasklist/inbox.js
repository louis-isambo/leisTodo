const inbox = function (ls) {
    var title = ls.H2({
        attr: { className: "todotitle" },
        text: "La boite de reception"
    })
    const main = ls.Div({
        content: [title]
    })
    function createPage(cbk) {
        // emit creation of Folder page chennel
        ls.event.invoke("tasklist:operator:addPage", cbk, "tasklist:inBox", main)
    }
    return createPage
}

export { inbox }