const tomorrow = function (ls) {

    var title = ls.H2({
        attr: { className: "todotitle" },
        text: "Les tâches à faire demain"
    })
    const main = ls.Div({
        content: [title]
    })

    function createPage(cbk) {
        // emit creation of Folder page chennel
        ls.event.invoke("tasklist:operator:addPage", cbk, "tasklist:tomorrow", main)
    }
    return createPage
}

export { tomorrow }