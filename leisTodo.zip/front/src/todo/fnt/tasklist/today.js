
// today page

const today = function (ls, data, cp) {

    var title = ls.H2({
        attr: { className: "todotitle" },
        text: "Les tâches à faire Aujourd'hui"
    })
    const main = ls.Div({
        content: [title]
    })

    function createPage(cbk) {
        // emit creation of Folder page chennel
        ls.event.invoke("tasklist:operator:addPage", cbk, "tasklist:today", main)
    }
    return createPage

}

export { today }