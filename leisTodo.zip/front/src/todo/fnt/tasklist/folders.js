const folders = function (ls) {
    return ls.Div({ text: "Cliquez sur un dossier ..." })
}

export { folders }