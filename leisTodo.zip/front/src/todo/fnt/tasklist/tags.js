const tags = function (ls) {


    var title = ls.H2({
        attr: { className: "todotitle" },
        text: "Mes étiquettes"
    })
    const main = ls.Div({
        content: [title]
    })

    function createPage(cbk) {
        // emit creation of Folder page chennel
        ls.event.invoke("tasklist:operator:addPage", cbk, "tasklist:tags", main)
    }
    return createPage
}

export { tags }