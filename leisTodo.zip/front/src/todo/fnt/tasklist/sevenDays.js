const sevenDays = function (ls) {

    var title = ls.H2({
        attr: { className: "todotitle" },
        text: "Les tâche affaire pour les prochains jours"
    })
    const main = ls.Div({
        content: [title]
    })
    function createPage(cbk) {
        // emit creation of Folder page chennel
        ls.event.invoke("tasklist:operator:addPage", cbk, "tasklist:nextWeek", main)
    }
    return createPage
}

export { sevenDays }