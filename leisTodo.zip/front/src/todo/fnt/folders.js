
import { folderOperator } from "../_todo/folderOpera.js";
/**
 * 
 * this functionality displays all folders which are in our application
 * and if  a user clicks on one of this folder will display in detail the 
 * folder clicked. 
 */
const folders = (function (leistrap, data) {


    // init the dependencies
    folderOperator(leistrap, data)

    // creation  the function which will create a new folder when the folder icon is clicked 
    // before  creating a new folder we have to create a form which will help us to do it.
    //todo creating a form NewFolderForm
    // ! i use the DropDown widget for displaying the form 

    var sideBar;
    function newFolder() {
        var input = leistrap.Input().getTextBox()
        var folderInput = input.add(null, "folder", null,
            { attr: { style: "background: var(--leis-body-cl)" } })

        input.setSize(folderInput, "100%")
        sideBar.addItems([
            { "icon": "ni bi-folder", widget: input }
        ])
        leistrap.event.invoke("newTask", function (modal) {
            modal.setTitle("Nouvelle tâche")
            modal.show()
        })
    }

    // setting  the date 
    const dataFolder = {
        "header": leistrap.P({ text: "Tous les dossiers" }),
        "items": [
            { caption: "Nouveau dossier", icon: "bi bi-folder-plus", action: newFolder }
        ]
    }
    // display all  mainFolders
    data.MainDirs.forEach(folder => dataFolder.items.push(
        { caption: folder.name, "icon": "bi bi-folder" }
    ))

    function sbFunc(side, home, tab) {
        sideBar = side
    }
    /*
    expose the functionality to the entire application
     */
    const track = {
        "funIcon": { "icon": "bi bi-folder" },
        "sideData": dataFolder,
        sbFunc
    }
    return track
})

export { folders }