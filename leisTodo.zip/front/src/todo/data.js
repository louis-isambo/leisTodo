import { leistrap } from "../../leistrap1.0/leistrap.js"


var TASKLIST = []
const MainTaskList = [
    {
        "name": "Aujourd'hui",
        "widget": "today",
        "root": "Aujourd'hui/",
        "icon": "bi bi-calendar2-range-fill",
        "type": "main",
        "id": leistrap.dep.generateId(3, 10)
    },

    {
        "name": "Demain",
        "widget": "tomorrow",
        "root": "Demain/",
        "icon": "bi bi-sunrise-fill",
        "type": "main",
        "id": leistrap.dep.generateId(3, 10)
    },
    {
        "name": "Prochains jours",
        "widget": "nextWeek",
        "root": "Prochains jours/",
        "icon": "bi bi-calendar-day-fill",
        "type": "main",
        "id": leistrap.dep.generateId(3, 10)
    },
    {
        "name": "Boîte de réception",
        "widget": 'inBox',
        "root": "Boîte de réception/",
        "icon": "bi bi-envelope-paper-fill",
        "type": "main",
        "id": leistrap.dep.generateId(3, 10)
    },
    {
        "name": "Etiquettes",
        "widget": 'tags',
        "root": "Etiquettes/",
        "icon": "bi bi-tags-fill",
        "type": "main",
        "id": leistrap.dep.generateId(3, 10)
    },

]



function getTasklist(tasklistConf) {
    var result;
    for (var tasklist = 0; tasklist < TASKLIST.length; tasklist++) {
        if (TASKLIST[tasklist].id === tasklistConf.id && TASKLIST[tasklist].name === tasklistConf.name) {
            result = TASKLIST[tasklist]
            result.idTasklist = result.id + result.root
            break;
        }
    }
    return result;
}

function getTasklistBy(tag, value) {
    var result;
    for (var tasklist = 0; tasklist < TASKLIST.length; tasklist++) {
        if (TASKLIST[tasklist][tag] === value) {
            result = TASKLIST[tasklist]
            result.idTasklist = result.id + result.root
            break;
        }
    }
    return result;
}


const defData = {
    mainTasklist: MainTaskList
}
var defaultTasklist = MainTaskList[3]
defaultTasklist.idTasklist = "tasklist:inBox"

const dataAPI = {
    MainTaskList,
    getTasklist,
    getTasklist,
    defData,
    defaultTasklist,
    allTasklistName: MainTaskList.map(item => item.name)
}

function initData() {
    leistrap.event.handle("dataApi", function (event, listener) {
        leistrap.event.invoke('data:all', function (allData) {

            TASKLIST = allData.tasklist
            dataAPI.MainTasklist = allData.tasklist
            dataAPI.allTasklistName = allData.tasklist.map(item => item.name)
            listener(dataAPI)
        })
    })
}

export { dataAPI, initData }