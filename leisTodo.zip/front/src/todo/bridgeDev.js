
import { Todo } from "./home.js"
import { leistrap } from "../../leistrap1.0/leistrap.js"
import { tasklist } from "./fnt/tasklist.js"
import { calendarView } from "./fnt/calendarView.js"
import { trdacking } from "./fnt/tracking.js"
// import { folders } from "./fnt/folders.js"


const todoTask = (ui5, dir, colorPalette, dataAPI) => Todo(
    [
        tasklist(leistrap, dataAPI, colorPalette),
        calendarView(leistrap, dataAPI,),
        trdacking(leistrap, dataAPI,),

        // folders(leistrap, dataAPI)
    ],
    leistrap,
    ui5,
    leistrap.dep.leis,
    dir,
    dataAPI

)

export { todoTask }