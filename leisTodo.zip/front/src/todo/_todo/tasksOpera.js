

const tasksOperator = function (ls, data) {

    // create  the function which allows us to add a new task to the tasklist
    //selected
    function addNewTask(event, res, save = false) {

        // this variable will get the tasklistConf of the defaultTasklist
        // if the tasklistName and id that a user typed doesn't exist to
        // our tasklist object
        var tasklistTyped = data.getTasklist(res.tasklist)

        if (!tasklistTyped) {

            //tasklist cases
            // case 1: tasklist not selected
            if (!res.tasklist.name || res.tasklist.name.replace(/\s/, "") == "") {
                // if there is no tasklist with this folderConf by default we set
                // the defaultFolder that can have a task
                console.log("tasklist field not selected !");
                tasklistTyped = data.defaultTasklist


            }


            // case 2 : tasklist name doesn't exist
            if (!ls.dep.obj.has(res.tasklist.name, data.allTasklistName) && res.tasklist.name) {
                console.log(`the tasklist ${res.tasklist.name} doesn't exist`);
                tasklistTyped = data.defaultTasklist
            }

            // case 3 : tasklist name exists but there is no folder id associated to it

            if (ls.dep.obj.has(res.tasklist.name, data.allTasklistName)) {
                var rest = data.getTasklistBy("id", res.tasklist.id) || {}
                if (rest.name === res.tasklist.name) console.log(rest);
                else {
                    console.log(`the tasklist ${res.tasklist.name} exists but there is some problem`);
                    //get the id of this folder
                    tasklistTyped = data.getTasklistBy("name", res.tasklist.name)
                }
            }
        }

        var card = setTaskStyle(tasklistTyped, res)

        var cnt = ls.Div({ innerHtml: res.zoneText })
        var container = ls.Div({ content: [cnt] })
        ls.dep.leis.addClassList(cnt, "todo-task-container")

        ls.event.invoke(tasklistTyped.idTasklist, function (page) {
            page.container.add(ls.Div({
                content: [card.cardInfo],
                tooltip: card.comment ? card.comment : undefined
            }))
            var id = ls.dep.generateId(3, 5)
            page.page.define(id, container)
            container.addData.id = id;
            ls.event.handle(`task:${id}`, (e) => e.send(res))
            card.btnViewTask.addEvent("click", () => page.page.invoke(id))
            card.cardInfo.addEvent("dblclick", () => page.page.invoke(id))
            // save the task to our database
            if (save) ls.event.invoke("data:add:task", null, res);
        })
    }


    // function which creates the default task style
    function setTaskStyle(tasklist, res) {
        var check = ls.Input().getCheckBox(); check.add()
        var TaskTitle = ls.H4({ text: res.title })
        const containerHead = ls.Div({ content: [check, TaskTitle] })


        var color = ls.Button({
            otherAttr: {
                style: `background:${res.color}; width:15px; height:15px; top:3px`,
                "class": "colorBtn todo-task-color"
            },
            events: { click: showColorModal }
        })

        // show the color picker modal when a user clicks on  the color button
        function showColorModal(e) {
            ls.event.invoke('colorPicker', function ({ ColorModal, result }) {
                result(getColor)
                function getColor(colorValue) {
                    e.target.currentElement.setStyleProp("backgroundColor", colorValue)
                    ColorModal.once("close", function () {
                        if (colorValue) {
                            res.color = colorValue
                            ls.event.invoke("data:makechanges")
                        }
                    })
                }
            }, e.clientX - 600, e.clientY - 100)

        }
        var comment;
        if (res.comment) {
            comment = {
                postion: 'top',
                text: res.comment
            }
        }
        var tasklistTyped = tasklist
        const tasklistInfo = ls.Div({
            content: [
                ls.Span({ content: [ls.I({ otherAttr: { "class": tasklistTyped.icon ? tasklistTyped.icon : "bi bi-folder" } })] }),
                ls.Span({ text: tasklistTyped.root ? tasklistTyped.root : tasklistTyped.name })
            ],
            otherAttr: { "class": "todo-card-folder-info", "title": "Le dossier que contient cette tâche" },

        })

        const btnViewTask = ls.Button({ text: "Voir", type: "primary" })
        var containerFoot = ls.Div({ content: [tasklistInfo, color, btnViewTask] })
        var cardInfo = ls.Div({ content: [containerHead, containerFoot] })

        ls.dep.leis.addClassList(cardInfo, "todo-task-info-card leis-flex leis-row")
        ls.dep.leis.addClassList(containerHead, "todo-card-info-head  leis-flex leis-row")
        ls.dep.leis.addClassList(containerFoot, "todo-card-info-foot  leis-flex leis-row")
        return { cardInfo, btnViewTask, comment }
    }

    ls.event.handle("taskOperator:add", addNewTask)
    // init all tasks which are in our database 
    ls.event.invoke("data:tasks", (tasks) => tasks.forEach((item, index) => {
        ls.event.invoke("taskOperator:add", null, item)
    }))
}

export { tasksOperator }