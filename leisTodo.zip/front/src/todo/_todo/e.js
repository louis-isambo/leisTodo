
// creating a input widget which allows us to add a new task directly
const newInputTask = ls.Input().getTextBox()
const _addNewtask = newInputTask.add("Nouvelle tâche")
newInputTask.on(_addNewtask, "keyup", MoreOptionsNewTask)
const title = ls.H2({
    text: "Liste des tâches à faire pour Aujourd'hui.",
    attr: { className: "todotitle" }
})



// add pane tool 
var btns = ls.Button().groupBtn()
btns.setType("light")
btns.add("Piece jointe");
var zoneText = btns.add("Zone de text");
btns.add("Codes")
var saveTodoPapierBtn = btns.add("Enregister")

function setZoneText(w, content, innerHTML, pass) {
    var input = ls.Div({
        otherAttr: {
            "class": "todo-zoneText leis-textinput",
            "contenteditable": "true"
        }
    })

    if (innerHTML && !pass) {
        w._conf.innerHTML = content
    }
    if (content && !innerHTML) input.add(content);
    w.add(input)
}
btns.on(zoneText, "click", function () {
    ls.event.invoke("folder:today", function (o) {
        setZoneText(o.page.currentPage.content[0])
    })
})

function saveZoneText() {
    ls.event.invoke("folder:today", function (o) {
        var id = o.page.currentPage.addData.id
        ls.event.invoke(`task:${id}`, save)
        function save(res) {
            res.zoneText = o.page.currentPage.content[0]._conf.innerHTML
            ls.event.invoke("data:update", null, res, ["zoneText"])
        }
    })

}

btns.on(saveTodoPapierBtn, "click", function () {
    saveZoneText()
})
btns.setSize("100%")

// hide and show the pannel tool
ls.event.invoke('folder:today', function (o) {
    if (o.page.currentPage == "main") {
        paneTool.hide()
        title.show()
    }
    o.page.point.addEvent("click", function (e) {
        if (o.page.currentPage === "main") {
            paneTool.hide()
            title.show()
        }
        else { paneTool.show(); title.hide() }
    })
})
var pane = ls.Div({ content: [btns] })
var paneTool = ls.Div({ otherAttr: { "class": "todo-pane" }, content: [pane] })




// create  the function which allows us to add a new task to the folder
//selected
function addNewTask(res) {
    if (!data.getFolder(res.folder)) {
        res.folder = "Boîte de réception";
    }
    var card = setTaskStyle(res)
    var cnt = ls.Div({ innerHtml: res.zoneText })
    var container = ls.Div({ content: [cnt] })
    ls.dep.leis.addClassList(cnt, "todo-task-container")


    ls.event.invoke("folder:today", function (o) {
        o.def.add(ls.Div({
            content: [card.cardInfo],
            tooltip: card.comment ? card.comment : undefined
        }))
        var id = ls.dep.generateId(3, 5)
        o.page.define(id, container)
        container.addData.id = id;
        ls.event.handle(`task:${id}`, (e) => e.send(res))
        card.btnViewTask.addEvent("click", () => o.page.invoke(id))
        card.cardInfo.addEvent("dblclick", () => o.page.invoke(id))
    })
}


// function which creates the default task style
function setTaskStyle(res) {
    var check = ls.Input().getCheckBox(); check.add()
    var TaskTitle = ls.H4({ text: res.title })
    const containerHead = ls.Div({ content: [check, TaskTitle] })


    var color = ls.Button({
        otherAttr: {
            style: `background:${res.color}; width:15px; height:15px; top:3px`,
            "class": "colorBtn todo-task-color"
        }
    })

    var comment;
    if (res.comment) {
        comment = {
            postion: 'top',
            text: res.comment
        }
    }
    var folderIcon = data.getFolder(res.folder)

    const folderInfo = ls.Div({
        content: [
            ls.Span({ content: [ls.I({ otherAttr: { "class": folderIcon.icon ? folderIcon.icon : "bi bi-folder" } })] }),
            ls.Span({ text: folderIcon.root ? folderIcon.root : folderIcon.name })
        ],
        otherAttr: { "class": "todo-card-folder-info", "title": "Le dossier que contient cette tâche" },

    })

    const btnViewTask = ls.Button({ text: "Voir", type: "primary" })
    var containerFoot = ls.Div({ content: [folderInfo, color, btnViewTask] })
    var cardInfo = ls.Div({ content: [containerHead, containerFoot] })

    if (res.zoneText) {

    }
    ls.dep.leis.addClassList(cardInfo, "todo-task-info-card leis-flex leis-row")
    ls.dep.leis.addClassList(containerHead, "todo-card-info-head  leis-flex leis-row")
    ls.dep.leis.addClassList(containerFoot, "todo-card-info-foot  leis-flex leis-row")

    return { cardInfo, btnViewTask, comment }
}

// creating a function which will display the Modal
// if a user hits return key to the input newtask
function MoreOptionsNewTask(event) {
    if (event.keyCode === 13) {
        taskTitle.setValue(_taskTitleInput, newInputTask.getValue(_addNewtask))
        modalNewtask.setTitle("Nouvelle tâche")
        modalNewtask.show()
    }

}

newInputTask.setSize(_addNewtask, "80%")



// create a today page
const p = ls.pageButton({
    contentPage: ls.Div({ text: ls.MLorem(20) })
})
var def_ = ls.Div()
const pageTody = ls.Page({
    legend: [p],
    content: [def_]
})
// expose the pageToday
ls.event.handle("folder:today", (event) => event.send({ page: pageTody, def: def_ }))

// getall Data
ls.event.invoke("data:tasks", function (data) {
    data.forEach((item, index) => {
        addNewTask(item)
    })
})
function init(main) {
    ls.event.handle(`folder:${main.addData.id}today/`,
        (event) => event.send({ page: pageTody, def: def_ }))
}
return {
    elem: ls.Div({
        content: [
            newInputTask,
            paneTool,
            title,
            pageTody
        ]
    }),
    init

}