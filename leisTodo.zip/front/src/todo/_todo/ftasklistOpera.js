
const tasklistOperator = function (ls, data) {


    function createTasklistPage(event, pageName, element) {
        const CONTAINER = ls.Div()
        const PAGE = ls.Page({
            content: [CONTAINER]
        })
        ls.event.handle(pageName,
            (event) => event.send({ page: PAGE, container: CONTAINER }))

        function init(elem) {
            ls.event.handle(elem.addData.id,
                (event, listener) => event.send({ page: PAGE, container: CONTAINER }))

        }
        event.send({
            elem: ls.Div({
                content: [element, PAGE],

            }),
            init
        })
    }


    // create folder:operator:addPage channel
    ls.event.handle("tasklist:operator:addPage", createTasklistPage)

}

export { tasklistOperator }