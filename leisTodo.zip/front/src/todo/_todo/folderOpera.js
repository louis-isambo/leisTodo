const folderOperator = function (ls) {

    function createSubDirs(event, res, parentList, save = true) {
        ls.event.invoke(parentList, parent => {
            parent.addItem(setFolder(res, parentList, save))
        })


    }

    function setFolder(res, parent, save) {
        var content = ls.GroupItem({ items: [] })
        const coll = ls.Collapsible({
            caption: res.name,
            content: [content]
        })
        var folderConf = {
            id: res.id || ls.dep.generateId(3, 8),
            name: res.name,
            parent
        }
        content.folderConf = folderConf
        ls.event.handle(`folderId:${folderConf.name + folderConf.id}`, event => {
            console.log("okay bien");
            event.send(content)
        })

        if (save) ls.event.invoke("data:add:folder", null, folderConf)
        const folderResult = ls.Li({ content: [coll] })
        folderResult.folderConf = folderConf
        return folderResult
    }

    function createTaskList(event, res) {
        var tabBtn = ls.Span({ text: res.title })
        ls.event.invoke("mainTab", (tab) => tab.addTab(tabBtn, res.content, true))
    }

    // expose the folder:operator:add chanel
    ls.event.handle("folder:operator:add", createSubDirs)

    // init all folder
    ls.event.invoke("data:folders", function (folderList) {
        var folderRes = folderList.map((item, index) => setFolder(item, item.parent))
        folderRes.forEach((item, index) => {
            ls.event.invoke(item.folderConf.parent, parent => parent.addItem(item))
        })

    })
}

export { folderOperator }