

const formTask = function (ls, data) {

    // create a modal form
    const modalNewTask = ls.Modal()
    modalNewTask.setSize("400px", "80vh")
    modalNewTask.clear()

    //configure modal buttons
    modalNewTask.closeBtn.setText("Annuler")
    modalNewTask.saveBtn.setText("Enregistrer")


    //! let create the options what a task can have
    //todo title
    const taskTitle = ls.Input().getTextBox()
    const _taskTitleInput = taskTitle.add("Titre")
    taskTitle.setSize(_taskTitleInput, "85%")
    modalNewTask.add(taskTitle)


    //todo tasklist
    var TASKLIST_CONF = {}
    const defaultValue = data.MainTasklist.map(tasklist => {
        return {
            icon: ls.I({
                otherAttr: { "class": tasklist.icon ? tasklist.icon : "bi bi-tasklist" }
            }),
            text: tasklist.name,
            id: tasklist.id

        }
    })
    const taskList = ls.Input().getTextBox()
    taskList.autoComplete = {
        defaultValue: defaultValue,
        autoComplete: defaultValue,
        whenSelect: getPageOfFolder,
        limit: 5
    }
    const _taskListInput = taskList.add("Liste", "dossier")
    taskList.setSize(_taskListInput, "85%")
    modalNewTask.add(taskList)


    //todo priority
    const taskPriority = ls.Input().getRadio()
    taskPriority.add("Très élévée", 1)
    taskPriority.add("Elévée", 2,)
    taskPriority.add("Moyenne", 3)
    taskPriority.add("Faible", 4)
    taskPriority.add("Sans priorité", 5)
    modalNewTask.add(ls.H4({ text: "Priorité" }))
    modalNewTask.add(taskPriority)


    //todo color picker
    function shoColorPicker(e) {
        ls.event.invoke("colorPicker", null, e.clientX - 100, e.clientY - 100)
    }
    const colorIcon = ls.Div({
        attr: { className: ["todo-colorIcon"] },
        content: [
            ls.Span({
                content: [ls.I({ otherAttr: { "class": "bi bi-palette" } })],
                events: { click: shoColorPicker }
            }),
            ls.Span({ text: "🙂" }),
        ]
    })
    modalNewTask.add(colorIcon)

    //todo : comment textarea inout
    const commentTask = ls.Textarea({
        otherAttr: {
            placeholder: "Ajouter un commentaire  ",
            "class": "leis-textinput",
            style: "height: 90px; width:98%; margin-left:2px"
        },

    })

    modalNewTask.add(ls.Div({
        tooltip: { postion: "top", text: "commentaire" },
        content: [commentTask]
    }))

    function getPageOfFolder(d, dataset) {
        TASKLIST_CONF.id = dataset.id

    }
    // get the result or data that user typed from
    // our newTask form
    // adding a task to the folder selected
    var cbk = null
    function getNewTaskFormResult() {
        if (typeof res === "object") { res = null }
        TASKLIST_CONF.name = taskList.getValue(_taskListInput).trim()
        var res = {
            title: taskTitle.getValue(_taskTitleInput),
            tasklist: TASKLIST_CONF,
            priority: taskPriority.getChecked(),
            comment: commentTask._conf.value,
            color: null,
            zoneText: null
        }
        ls.event.invoke("colorPicker:color",
            (colorValue) => {
                res.color = colorValue
                console.log(colorValue);
                if (cbk) cbk(res)
            })
    }
    modalNewTask.saveBtn.on("click", getNewTaskFormResult, "newTask")

    // emit our newTask form and colorPicker
    ls.event.handle("newTask", function (event) {
        event.send({ modal: modalNewTask, result: getResult })
        function getResult(c) { cbk = c }
    })
    ls.event.invoke("main", (m) => m.add(modalNewTask))
}

export { formTask }