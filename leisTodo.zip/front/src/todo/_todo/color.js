
function Color_(ls, cp) {

    //todo colorPicker and Icon
    var cbk;
    var COLOR = null;
    const ColorModal = ls.Modal()
    ColorModal.removeHeader()
    ColorModal.removeFooter()
    ColorModal.clear()
    ColorModal.setEffect("modal-zoom-out")
    ColorModal.body.setStyleProp("height", "100%")
    const cp1 = cp(function (value) { COLOR = value; if (cbk) { cbk(value) } })
    cp1.setStyleProp("height", "100%")
    ColorModal.add(cp1)
    ColorModal.setSize("600px", "60vh")

    ls.event.handle("colorPicker", function (event, x, y) {
        event.send({ ColorModal, result: (listener) => { cbk = listener } })
        ColorModal.moveTo(x, y)
    })
    ls.event.handle("colorPicker:color", (event) => event.send(COLOR))
    ColorModal.once("active", () => { COLOR = null; cbk = null })
    ls.event.invoke("main", (m) => m.add(ColorModal))
}

export { Color_ }