
const CustomLeistrap = function (ls) {


    const CUSTOM = {}
    CUSTOM.setGroupBtnIcon = function (btn, iconName) {
        var ic = ls.Span({ content: [ls.I({ attr: { className: iconName } })] })
        btn.leisBtnConfId.add(ic)
    }

    // extend our API
    ls.event.handle("leistrapCustom", event => event.send(CUSTOM))
}

export { CustomLeistrap }