import { leistrap } from "../leistrap1.0/leistrap.js";
import { CustomLeistrap } from "./custom_leistrap.js";
import { MyTasks } from "./todo/index.js";
import { Ui5 } from "../leistrap1.0/Apps/plugin.js"
import { Colorpalette } from "../leistrap1.0/Apps/plugin.js";

function App(setting, data) {
  CustomLeistrap(leistrap)
  const ui = Ui5()

  return leistrap.Div({
    content: [
      MyTasks(ui(setting.dir), setting.dir, Colorpalette, data).home
    ]
  })
}

export { App }