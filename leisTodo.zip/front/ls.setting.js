import { Theme } from "./leistrap1.0/Apps/plugin.js";

export function Setting(ls) {
    'use strict';
    var conf = {
        dir: "./leistrap1.0/",
        theme: "light",
        plugin: [
            Theme
        ],
        dataAPI: {
            // web: {
            //     address: "http://localhost:2020"
            // }
            vd: {
                name: "leisData"
            }
        }
    }
    ls(conf)
    return conf
}

