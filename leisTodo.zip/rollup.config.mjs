import { string } from "rollup-plugin-string"
import json from "@rollup/plugin-json"

export default {
    input: "main.js",
    output: {
        file: "bundle.js",
        format: "iife",
        name: "leistrap",

    },
    plugins: [
        string({
            include: ["**/*.html", "**/*.css"]
        }),
        json()
    ]
}