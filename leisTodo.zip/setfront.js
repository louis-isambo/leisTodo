
var fs = require("fs")

var write_frontContent = fs.createWriteStream("./front.js")

var read_htmlHead = fs.createReadStream("./html.html")
var read_bundle = fs.createReadStream("./bundle.js")

read_htmlHead.on("data", function (chuck) {
    var head = chuck.toString().replace(/\<body\>[^]*/gi, "")
    write_frontContent.write(`module.exports.frontContent = \`${head.replace(/`/gi, "\\`")}`)

})
var data = ""
function readBundel() {
    read_bundle.on("data", function (chuck) {
        data += chuck.toString()
            .replace(/\\/g, "\\\\")
            .replace(/`/gi, "\\`")
            .replace(/\$/g, "\\$")
    })
}

readBundel()
read_bundle.on("end", () => {
    write_frontContent.write(`<body><div id="main"></div><script>${data}</script></body></html>\``)
})