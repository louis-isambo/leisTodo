const { leisdata } = require("./data");

const DB = "./back/database.db"

const Faculte = new leisdata(
    DB,
    "faculte",
    {
        nom: leisdata.Text(),
    },

)

const Promotion = new leisdata(
    DB,
    "promotion",
    {
        nom: leisdata.Text(),
    },
)

const Salle = new leisdata(
    DB,
    "salle",
    {
        designation: leisdata.Text(),
        promotion: leisdata.ForeignKey(Promotion)
    }
)

const Etudiant = new leisdata(
    DB,
    "etudiant",
    {
        nom: leisdata.Text(),
        post_nom: leisdata.Text(),
        pre_nom: leisdata.Text(),
        sexe: leisdata.Text(),
        lieu_naissance: leisdata.Text(),
        date_naissance: leisdata.Text(),
        ecole: leisdata.Text(),
        pouecentage: leisdata.Int(),
        nom_pere: leisdata.Text(),
        nom_mere: leisdata.Text(),
        etat_civil: leisdata.Text(),
        adresse: leisdata.Text(),
        tel: leisdata.Text(),
        promotion: leisdata.ForeignKey(Promotion),
        faculte: leisdata.ForeignKey(Faculte)
    })

// module.exports = {
//     Faculte,
//     Promotion,
//     Salle,
//     Etudiant
// }

Etudiant.getAllObject().then(data => {
    console.log(data);
})