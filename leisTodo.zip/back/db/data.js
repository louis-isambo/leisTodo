"use strict"

/**
 * the database table definition
 */
class leisdata {
    #query = function (sql, database, callback) {
        const sqlite3 = require("sqlite3").verbose()
        const db = new sqlite3.Database(database, (error) => {
            if (error) { console.log(error.message) }
        })
        db.serialize(() => {

            db.each(sql, callback ? callback : (err, row) => {
                if (err)
                    console.log(err.message)
            })
        })

        db.close((err) => {
            if (err)
                console.log(err.message)
        })

    }
    #filename;
    #table;
    #columns;
    #tdf = 8;
    #param
    #exCol = o => {
        const k = Object.keys(o)
        let r = ""
        k.forEach(item => r += ` ${typeof o[item] === "function" ? `${o[item]().name} ${o[item]().value},` : `${item} ${o[item]},`}`)
        r = r.trim()
        return r.endsWith(',') ? r.slice(0, r.length - 1) : r
    }

    /**
     * 
     * @param {string} table table name 
     * @param {{}} columns columns definition
     * @param {string} fileName
     * @param {string} tableName
     * @param {{useTable ?: boolean, useColumn ?: string, default:{useColumn ? : string[], values? : string[]}}} param  
     */
    constructor(fileName, tableName, columns, param) {
        this.#filename = fileName;
        this.#table = tableName;
        this.#param = param
        Object.defineProperty(this, "__clName__", { writable: false, value: "leisData" })
        if (typeof param === "object") {
            if (typeof param.useTable === "boolean" && param.useTable === true) {
                this.#columns = columns
            } else {
                this.#columns = columns;
                this.#setObject()
            }
        }
        else {
            this.#columns = columns;
            this.#setObject()
        }

    }

    static Text() {
        return "text"
    }
    static Int() {
        return "integer"
    }
    static Blob() {
        return "blob"
    }
    /**
     * join table
     * @param {leisdata} table 
     */
    static ForeignKey(table) {
        try {
            return function () { return { name: `${table.#table}_id`, value: "integer not null" } }
        } catch {
            throw new Error(`can not use ${typeof table}`)
        }
    }

    /**
     * get  SQLITE API
     * @param {string[]} columns table columns
     * @param {string} tableName the table to be used 
     * @param {string} fileName 
     * @param {{}} foreignKeys  the columns used foreignkey
     */
    static useTable(fileName, tableName, columns, foreignKeys) {
        let o = {}
        if (typeof foreignKeys === "object") {
            const keys = Object.keys(foreignKeys)
            columns.forEach(key => {
                if (typeof foreignKeys[key] !== "undefined") {
                    o[key] = foreignKeys[key]
                }
                else { o[key] = null }
            })
        } else {
            columns.forEach(key => o[key] = null)
        }
        return new leisdata(fileName, tableName, o, { useTable: true })
    }

    /**
    * @param {{}} o the table columns name 
    */
    simpleSave(o) {
        const k = Object.keys(o)
        const values = k.map(key => {
            let m = ""
            if (typeof o[key] === "string" || typeof o[key] === "object") {
                m += `'${String(o[key]).replace(/'/gi, "''")}'`
            } else { m += o[key] }
            return m
        })
        const sql = `INSERT INTO ${this.#table}(${k.toString()}) VALUES(${values.toString()}) `
        this.#query(sql, this.#filename)
    }
    /**
     * add new row data 
     * @param {{}} o colums property value  
     */
    create(o) {
        const keys = Object.keys(this.#columns)
        const _table = this
        const query = this.#query
        const db = this.#filename
        const ld = this

        const j = (list, ob) => {
            let h = 'WHERE '
            const p = []
            for (let i = 1; i < list.length; i++) { p.push("AND") }
            list.forEach((item, i) => h += `${item} = ${ob[i]} ${typeof p[i] !== "undefined" ? `${p[i]} ` : ""}`)
            return h
        }
        return new class leisChildDB {
            #data
            constructor() {
                keys.forEach(key => this[key.replace(/\n/gi, "")] = o[key])
                Object.defineProperty(this, "__clName__", { writable: false, value: "leisChildDB" })
                keys.forEach((item, i) => { if (typeof this[item].__clName__ !== "undefined") this[item][`get_${ld.#table}`] = this })
            }
            getColumns() { return ld.#columns }
            gettable() { return ld.#table }

            /**
             * save data into the database
             */
            save() {
                const k = Object.keys(this)
                let eignKey = false
                let listOb = []
                k.forEach(item => { if (typeof this[item].__clName__ !== "undefined") { eignKey = true; listOb.push(item) } })

                if (eignKey === true) {
                    let values;
                    if (listOb.length === 1) {
                        const ik = listOb[0]
                        const idKey = Object.keys(this[ik].getColumns())
                        idKey.forEach((v, i) => typeof this[ik].getColumns()[v] === "function" ? idKey[i] = this[ik].getColumns()[v]().name : undefined)
                        const idValue = idKey.map(key => `'${this[listOb[0]][key]}'`)
                        values = k.map(key => `${typeof this[key].__clName__ !== "undefined" ? `${`(SELECT id FROM ${this[listOb[0]].gettable()} ${j(idKey, idValue)}`} LIMIT 1)` : `'${this[key].replace(/'/gi, "''")}'`}`)
                        this.#data = [k, values]
                        k[k.indexOf(listOb[0])] = `${this[listOb[0]].gettable()}_id`
                        const sql = `INSERT INTO ${ld.#table}(${k.toString()}) VALUES(${values.toString()}) `
                        query(sql, db)
                    }
                    else {
                        const idIp = {}
                        listOb.forEach((key, index) => {
                            const idKey = Object.keys(this[key].getColumns())
                            idKey.forEach((v, i) => typeof this[key].getColumns()[v] === "function" ? idKey[i] = this[key].getColumns()[v]().name : undefined)
                            idKey.forEach(l => typeof this[key][l] == "undefined" ? idKey.pop() : null)
                            const idValue = idKey.map(k => `'${this[key][k]}'`)
                            idIp[key] = `${`(SELECT id FROM ${this[key].gettable()} ${j(idKey, idValue)}`} LIMIT 1)`
                        })
                        values = k.map(key => `${typeof this[key].__clName__ !== "undefined" ? `${idIp[key]}` : `'${this[key].replace(/'/gi, "''")}'`}`)
                        listOb.forEach(i => k[k.indexOf(i)] = `${this[i].gettable()}_id`)
                        const sql = `INSERT INTO ${ld.#table}(${k.toString()}) VALUES(${values.toString()}) `
                        this.#data = [k, values]
                        query(sql, db)
                    }
                }
                else {
                    const values = k.map(key => `'${this[key]}'`)
                    this.#data = [k, values]
                    const sql = `INSERT INTO ${ld.#table}(${k.toString()}) VALUES(${values.toString()}) `
                    query(sql, db)
                }
            }

            getId() {
                if (typeof this.#data !== "undefined") {
                    const t = ld.#tdf
                    for (let x = 0; x < t; x++) { ld.#get(`SELECT id FROM ${ld.#table} ${j(this.#data[0], this.#data[1])}`) }
                    ld.#tdf *= 2
                    return ld.#get(`SELECT id FROM ${ld.#table} ${j(this.#data[0], this.#data[1])}`)

                } else { return null }

            }
        }
    }

    /**
    * search the id given into the table 
    * @param {number} id the id
    */
    getObj(id) {
        return this.#get(`SELECT*, count(*) num FROM ${this.#table} WHERE id = ${id}`)
    }
    /**
     * remove a row into the table
     * @param {number} id the id
     */

    deleteObj(id) {
        return this.#query(`DELETE FROM ${this.#table} WHERE id = ${id}`, this.#filename)
    }
    /**
     * gets all rows in table
     */
    getAllObject() {
        return this.#get(`SELECT*FROM ${this.#table}`)
    }
    /**
     * returns the number of rows 
     */
    getLen() {
        return this.#get(`SELECT count(*)length FROM ${this.#table}`)
    }
    /**
     * add a new column 
     * @param {{}} colDef 
     */
    addColumn(colDef) {
        this.#query(`ALTER TABLE ${this.#table} ADD COLUMN ${this.#exCol(colDef)}`, this.#filename)
    }
    /**
     * remanes the column name
     * @param {string} colName the old column name 
     * @param {string} newColName the new column name
     */
    renameColumn(colName, newColName) {
        this.#query(`ALTER TABLE ${this.#table} RENAME COLUMN ${colName} to ${newColName}`, this.#filename)
    }
    /**
     * remanes the table name
     * @param {string} newColName the new table name
     */
    selfRename(newColName) {
        try {
            this.#query(`ALTER TABLE ${this.#table} RENAME to ${newColName}`, this.#filename)
            this.#table = newColName
        } catch (error) { console.log(error) }

    }
    async #get(sql) {
        const re = []
        return new Promise((resolve, reject) => {
            this.#query(sql, this.#filename,
                function (err, row) {
                    if (err)
                        reject(err)
                    re.push(row)
                    resolve(re)
                })
        })
    }

    #setObject() {
        const GB = () => {
            let Res;
            const C = this.#param ? this.#param.default ? this.#param.default.useColumn ?
                this.#param.default.useColumn : null : null : null
            const V = this.#param ? this.#param.default ? this.#param.default.values ?
                this.#param.default.values : null : null : null
            if (C !== null && V !== null) {

                let y = ''
                V.forEach(v => {
                    let u = '('
                    v.forEach(item => {
                        if (typeof item === "object" || typeof item === "string") {
                            u += `'${String(item).replace("'", "''")}'`
                        } else { u += `${String(item)}` }
                    })
                    u += "),"
                    y += `${u}`
                })
                const R = `INSERT INTO ${this.#table} (${C.toString()}) VALUES ${y}`
                Res = R.trim().endsWith(",") ? R.trim().slice(0, R.trim().length - 1) : R.trim()
            }
            return Res
        }
        const sql = `CREATE TABLE IF NOT EXISTS 
                    ${this.#table}(id integer primary key,
                    ${this.#exCol(this.#columns)})`
        /**
         * save the default values into the database
         */
        this.setDefault = function () { GB() ? this.#query(`${GB()}`, this.#filename) : undefined }
        try { this.#query(sql, this.#filename) } catch (error) { }
    }
}



module.exports = { leisdata }