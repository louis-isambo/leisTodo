
const express = require("express");
const app = express();
const Server = require("http").Server;
const server = new Server(app)
const path = require("path");
const html = require("../front.js")
const { dataObject } = require("./views.js")

const port = 5000;

server.listen(port, function () {
    console.log("leis server  start at :http://localhost:%s", port);
})


// app.use("/", express.static(getDir() + "/views"));

app.get("/", function (req, res) {
    //res.sendFile(getDir() + "/views/index.html");
    res.send(html.frontContent)
})

app.get("/api/:all", function (req, resp) {
    resp.status(200)
    resp.send(JSON.stringify(dataObject))
})

app.get("/api-update/:dataSend", function (req, resp) {
    resp.status(200)
    console.log(decodeDataSent(req.params.dataSend));

})

function decodeDataSent(data) {
    var splitChuck = data.split("_")
    var resultChuck = ""
    splitChuck.forEach(char => resultChuck += String.fromCharCode(char))
    return JSON.parse(resultChuck)
}
// function getDir() {
//     if (process.pkg) {
//         return path.resolve(process.execPath + "/..")
//     }
//     else {
//         return path.join(require.main ? require.main.path : process.cwd())
//     }
// }

