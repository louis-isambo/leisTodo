module.exports.dataObject = {
    all: [
        { title: "nouvelle tache ", "color": "#ff0000", "comment": "task" },
        { title: "nouvelle tache", "color": "#2200ff", "comment": "task" },
        { title: "nouvelle tache", "color": "#22ff00", "comment": "je suis bien" }
    ]
}