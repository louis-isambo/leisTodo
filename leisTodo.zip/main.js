
import { leistrap } from './front/leistrap1.0/leistrap.js'
import style from "./front/leistrap1.0/static/css/leistrap.main.css"
import { leisMain } from './front/App.js'
import leisR from "./front/leistrap1.0/static/css/resizable.css"
import icons from "./front/leistrap1.0/static/css/font/bs-icons.min.css"

leistrap.addStyle(style)
leistrap.addStyle(leisR)
leistrap.addStyle(icons)
leisMain()
