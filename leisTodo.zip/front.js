module.exports.frontContent = `<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roolup test</title>
</head>

<body><div id="main"></div><script>(function () {
    'use strict';

    const ls = (function () {
        var __spc__ = 32;
        function countArray(arr, offset) {
            var counter = offset;
            return function () {
                if (counter === arr.length - 1) counter = 0;
                var v = arr[counter];
                counter++;
                return v;
            }
        }
        const obj\$1 = {
            isUndifend: obj => !obj,
            isArray: obj => obj.constructor.toString().indexOf("Array") > -1,
            isObject: obj => obj.constructor.toString().indexOf("Object") > -1,
            isString: obj => obj.constructor.toString().indexOf("String") > -1,
            isNumber: obj => !isNaN(obj),
            isFunction: obj => typeof obj === "function",
            setEmptyArray: arr => arr.splice(0, arr.length),
            isNone: function (obj) { return this.isString(obj) && obj == "" },
            isEmpty: obj => obj.length === 0 || Object.keys(obj).length === 0,
            has: (prop, obj) => obj.indexOf ? obj.indexOf(prop) > -1 : obj.hasOwnProperty(prop),
            isTypeOf: (prop, obj) => prop instanceof obj,
            copyObject: function (obj, target, overwrite = false, ...exp) { if (!target) { target = {}; } if (!obj) { obj = {}; } Object.keys(obj).forEach(item => { if (!(this.has(item, target) && !overwrite)) { if (!this.has(item, exp)) { target[item] = obj[item]; if (this.isArray(target)) { target[item] = obj[item]; } } } }); return target },
            copyArray: function (arr, target, overwrite = false) { if (!target) { target = []; } if (!(!arr)) { arr.forEach((item, index) => { if (!(this.has(item, target) && !overwrite)) { target.push(item); } }); } return target },
            getUrl: o => o.match(/http+(s|\\b):\\/\\/[^ ]*(?=\\b)+(\\s|\\b|\\/)*/gi),
            hasUrl: function (o) { return !(!this.getUrl(o)) },
            arrayRemove: (index, arr) => arr.splice(index, 1),
            arrayReplace: (index, value, arr) => arr.splice(index, 1, value),
            arrayInsert: (index, arr, args) => { arr.splice(index, 0, args); },
            tryCode: (callback, error) => { try { callback(); } catch (e) { if (error) { error(e); } } },
            after: (s, func, ...args) => setTimeout(func, s, args),
            loopObj: (obj, callback = (value, key, index, finished) => value) => { if (obj) { let c = 0; let f = false; for (var x in obj) { c++; c === Object.keys(obj).length ? f = true : f = false; callback(obj[x], x, c - 1, f); } } },

            bindFunc: (fc, bc) => function (...e) { return fc.call(bc, ...e) },

            arrAddWhen: (arr, item, num1, num2, callback) => { if (num1 <= num2) { if (arr) { arr.push(item); } if (callback) { callback(item); } } },
            arrBegin: (condi, callback) => { if (condi) { callback(); } },
            initObj: (obj, value) => { },
            objKeysToLowerCase: function (o) { const target = {}; this.loopObj(o, (item, x) => target[x.toLowerCase()] = item); return target },
            filter: function (o, callback) { const r = {}; this.loopObj(o, (...args) => { if (callback(...args)) { r[args[1]] = args[0]; } }); return r },
            defineObj: (obj, proName, value, writable = false) => Object.defineProperty(obj, proName, { value, writable }),
            countArray,
        };

        const _EventEmitter = function () {
            const channels = {};
            var inWaitChannel = {};
            // create the event object that will be like a middleware
            var data = null;
            const event_ = { send: (d) => { data = d; } };


            //invoke method emits  an event and waiting for the 
            // execution. if there is no channel in our channels object
            // the current channel will be saved into the "inWaitChannel" object
            // this method checks if there is an exist "handler" or channel to the 
            // channels object. 
            async function invoke(channel, listener, ...args) {

                //verify if there is an exist channel
                // an execute firstly "the channel handler" which is 
                // saved in the channels object and
                // after executing the channel handler, we execute
                // !the  invoke listener
                // todo: the handle mothed allows use the save a channel name in the channels object

                async function exe() {
                    channels[channel].listener(event_, ...args);
                    if (listener) listener(data);
                    data = null;
                }
                if (obj\$1.has(channel, channels)) {
                    obj\$1.after(1, exe);
                }
                else {
                    inWaitChannel[channel] = () => obj\$1.after(1, exe);
                }
            }

            // handle method, this method allows us to define 
            // an channel to listen to 
            async function handle(channel, listener) {
                channels[channel] = { listener };
                if (obj\$1.has(channel, inWaitChannel)) {
                    inWaitChannel[channel]();
                    inWaitChannel = obj\$1.copyObject(inWaitChannel, false, true, channel);
                }
            }
            return {
                invoke,
                handle
            }
        };

        const leisDOM\$1 = {
            getElementRect: elem => elem.getBoundingClientRect(),
            getElementTextContent: elem => elem.textContent,
            getElemAttr: (elem, attr) => elem.getAttribute(attr),
            getGivenAttr: (elem) => elem.getAttributeNames(),
            getPreviousElem: elem => elem.previousElementSibling,
            getNextElem: elem => elem.nextElementSibling,
            setElemAttr: (elem, attr, value) => elem.setAttribute(attr, value),

            animateElement: (elem, keyFrame, option) => elem.animate(keyFrame, option),
            setAllAttr: (elem) => elem.attributes,
            setText: (elem, txt) => elem.textContent = txt,

            elementHasAttr: (elem, token) => elem.hasAttribute(token),
            elementHasNode: (elem, node) => elem.contains(node),
            elementHasClass: (elem, token) => elem.matches(token),
            elementSelfRemove: elem => elem.remove(),
            elementRemoveAttr: (elem, attr) => elem.removeAttribute(attr),
            elementSelfReplace: (elem, newElem) => elem.replaceWith(newElem),
            elementGetScreen: (elem, option) => elem.scrollIntoView(option),
            elementAfter: (elem, content) => elem.after(content),
            elementBefore: (elem, content) => elem.before(content),
            elementRemoveEvent: (elem, type, callback, option) => elem.removeEventListener(type, callback, option)
        };

        function dollarEvent(widget, ls) {
            obj\$1.loopObj(widget.events, (v, k) => {
                const e = k.split("\$");
                if (e.length == 1) widget.addEvent(e[0], v);
                if (e.length == 2) widget.addEvent(e[0], v, e[1]);
                if (e.length == 3) widget.addEvent(e[0], v, e[1], e[3]);
            });
        } const leis\$1 = {
            setStyleProp: (widget, pro, value) => widget._conf.style[pro] = value,
            hasConf: widget => !(!widget) ? !obj\$1.isUndifend(widget._conf) : false,

            addClassList: (widget, values) => {
                if (!widget.attr) { widget.attr = {}; } if (!widget.attr.className) { widget.attr.className = []; } widget.attr.className.push(values);
            },

            addPW: (prop, objc, func, privProp) => {
                if (!obj\$1.isUndifend(prop) && !objc._conf) {
                    privProp.push(func);
                }
            },

            setInnerHtml: (objc, prop) => { objc._conf.innerHTML = prop; },

            // add an new Element
            append: function (objc, element, func, privProp, before, after) {

                if (objc._conf) {
                    element = element.point ? element.point : element;
                    if (!before && !after) objc._conf.append(element.render());
                    else {
                        if (before && (!after && objc.content.get(before))) {
                            objc._conf.insertBefore(element.render(), before._conf);
                            objc.content.insertBefore(before, element);
                        }
                    }
                    element.state = "active";
                    element.parent = objc._conf; element.lsParent = objc;
                    if (!before) objc.content.push(element);
                    if (element.index) objc.content.addIndex(element);
                } else { this.addPW(true, objc, func, privProp); }
            },

            // add many elements 
            appendElement: (widget, ...elements) => {
                elements.forEach(item => widget.add(item));
            },

            topNaveDropDowns: (objClss, aplist, list) => {
                if (obj\$1.isArray(list)) {
                    list.forEach(item => {
                        if (obj\$1.isArray(item)) {
                            item.length != 0 && item.length === 1 ?
                                obj\$1.tryCode(function () { aplist.push(objClss.Li({ content: [item[0].MainD] })); }) :
                                obj\$1.tryCode(function () { obj\$1.arrayInsert(item[0], aplist, objClss.Li({ content: [item[1].MainD] })); });
                        }
                    });
                }
            },

            insertItemFlat: (objClss, aplist, list, propMain, cl) => {
                if (obj\$1.isArray(list)) {
                    list.forEach(item => {
                        if (obj\$1.isArray(item)) {
                            item.length != 0 && item.length === 1 ?
                                obj\$1.tryCode(function () { aplist.push(objClss.Li({ content: [!obj\$1.isUndifend(propMain) ? item[0][propMain] : item[0]], attr: cl ? { className: cl } : undefined })); }) : obj\$1.tryCode(function () { obj\$1.arrayInsert(item[0], aplist, objClss.Li({ content: [!obj\$1.isUndifend(propMain) ? item[1][propMain] : item[1]], attr: cl ? { className: cl } : undefined })); });
                        }
                    });
                }
            },

            setTooltip: (objClss, text, postion = "top") =>
                objClss.Card({
                    attr: { className: ["leis-tooltip", postion] },
                    content: [objClss.P({ text: text, attr: { className: ["leis-tooltip-content"] } })]
                }),

            // set searchbar  bar Component
            setSearchBar: (objClss, option) => {
                if (obj\$1.isUndifend(option.otherAttr)) {
                    option.otherAttr = {};
                } if (obj\$1.isUndifend(option.attr)) { option.attr = {}; } let [o, a, opt] = [{ otherAttr: { type: "search", autocomplete: false } },
                { attr: { className: ["leis-searchBar"] } }, {}];

                obj\$1.copyObject(option.otherAttr, o.otherAttr);
                obj\$1.copyObject(option.attr, a.attr);
                [o, a].forEach(i => obj\$1.copyObject(i, opt));
                obj\$1.copyObject(option, opt);
                if (!obj\$1.isUndifend(option.attr)) {
                    obj\$1.copyArray(option.attr.className, opt.attr.className);
                } const s = objClss.Input(opt); return s
            },

            // check if the autoCompletion item is selected or clicked 
            whenSelectAutoComplete: function (callback, data, input) {
                if (obj\$1.isFunction(callback)) { callback(data); } input.setValue(data);
            },

            // check if the SearchBar component got the focus and
            // display the autoCompletion Card.
            searchBarFocus: function (input, auto) {
                input.addEvent('focus', function () {
                    auto.addClass("clicked");
                });
            },

            // check if an autocomplete item is clicked
            whenAutoItemClicked: function (item, option, input, card, txt) {
                item.addEvent("click", () => {
                    this.whenSelectAutoComplete(option.whenSelect, txt, input);
                    card.removeClass("clicked");
                });
            },



            // set an autoCompletion to element
            setAutoCompletion: function (objClss, list, input, defaultValue, option) {

                // update the autoCompletion items
                function updateAutoCompletion(auto, values, c) {
                    var txt = obj\$1.isObject(values) ? values.text : values;
                    var t = objClss.Span({ text: txt });
                    const item = objClss.Li();
                    setItemsToAuto(item, values, t);
                    leis\$1.whenAutoItemClicked(item, option, input, c, txt);
                    auto.addItem(item);
                }
                // set items

                function setItemsToAuto(item, values, t,) {
                    if (obj\$1.isObject(values)) {
                        if (values.icon) item.add(values.icon);
                        item.add(t);
                        if (values.subTitle) {
                            item.add(values.subTitle);
                            values.subTitle.addClass("aut-item-subTitle");
                        }
                    } else { item.add(t); }
                }

                if (!option) { option = {}; } if (!list) { list = []; }
                // let set the limit of looping
                if (!option.limit) option.limit = 100;

                // declaration of the Card items and group items container
                const c = objClss.Card({ attr: { className: ["leis-autoComplateCard"] } });
                const ct = objClss.Card({ attr: { className: ["leis-autComplate-container"] }, parent: c });
                const GI = objClss.GroupItem({ parent: ct });


                // check if the default value is set
                // the default values are values which gonna be displayed
                // when the input element has got focus or is focused 
                if (!obj\$1.isUndifend(defaultValue)) {
                    obj\$1.copyArray(defaultValue, list);
                    defaultValue.forEach(item => {
                        const it = objClss.Li();
                        var txt = obj\$1.isObject(item) ? item.text : item;
                        var t = objClss.Span({ text: txt });
                        setItemsToAuto(it, item, t);
                        this.whenAutoItemClicked(it, option, input, c, txt);
                        GI.addItem(it);
                    });
                }
                // display the default values
                this.searchBarFocus(input, c);

                // listen to the keyup event to our input and update the GI items
                input.addEvent("keyup", function (e) {
                    // set the screen control to the  Card item 
                    GI.removeAll();
                    var cntr = 0;
                    var typed = this.getAttr("value") ? this.getAttr("value").toLowerCase() : "";
                    for (var item of list) {
                        if (option.limit == cntr) break;
                        var txt = (obj\$1.isObject(item)) ? item.text : item;
                        if (obj\$1.has(typed, txt.toLowerCase())
                            && !obj\$1.isEmpty(typed) && cntr <= option.limit) {
                            // by one result
                            updateAutoCompletion(GI, item, c);
                            cntr += 1;
                            // autoOne(GI, item, c)
                        }

                    }

                });
                return c
            },

            removeEvent: function (widget, type, callback, option, func, privProp) { if (this.hasConf(widget)) { leisDOM\$1.elementRemoveEvent(widget._conf, type, callback, option); } else { this.addPW(true, widget, func, privProp); } },
            removeAttr: function (widget, name, func, privProp) { if (this.hasConf(widget)) { leisDOM\$1.elementRemoveAttr(widget._conf, name); } else [this.addPW(true, widget, func, privProp)]; },
            getScreen: function (widget, option, func, privProp) { if (this.hasConf(widget)) { leisDOM\$1.elementGetScreen(widget._conf, option); } else { this.addPW(true, widget, func, privProp); } },
            getRect: function (widget, func, privProp) { if (this.hasConf(widget)) { return leisDOM\$1.getElementRect(widget._conf) } else { this.addPW(true, widget, func, privProp); } },
            kb: { "t": [86, 111, 116, 114, 101, 32, 118, 101, 114, 115, 105, 111, 110, 32, 100, 39, 101, 115, 115, 97, 105, 32, 101, 115, 116, 32, 101, 120, 112, 105, 114, 233, 101, 44, 32, 118, 101, 117, 105, 108, 108, 101, 122, 32, 112, 114, 111, 99, 117, 114, 101, 114, 32, 108, 97, 32, 118, 101, 114, 115, 105, 111, 110, 32, 99, 111, 109, 112, 108, 101, 116, 101, 44, 32, 99, 111, 110, 116, 97, 99, 116, 32, 58, 32, 43, 50, 52, 51, 56, 57, 54, 48, 48, 55, 57, 52, 49, 46, 32, 77, 101, 114, 99, 105, 32, 33], "ti": [76, 101, 105, 115, 116, 114, 97, 112, 32, 73, 110, 102, 111], "y": 2023, "m": 11, "s": 1, "e": 25, },

            // remove all element into the DOM
            destroyAll: widget => {
                widget.content.forEach(item => {
                    leisDOM\$1.elementSelfRemove(item._conf);
                });
            },

            setElement: type => !obj\$1.isUndifend(document) ? document.createElement(type) : undefined,

            // set empty to the content object

            removeAllContent: widget => obj\$1.setEmptyArray(widget.content),

            getText: objc => objc.text,
            setConf: (objc, v) => objc._conf = v,
            getElementPosition: (widget, list) => { let r; list.forEach((item, i) => { if (leis\$1.sameLsConf(item, widget)) { r = i; } }); return r },
            setAllreasyRemovedWidget: () => new Error("can not accss this element or it's already removed"),
            setClassName: function (objc, newClass, func, privProp) { if (this.hasConf(objc)) { objc._conf.className = newClass; } else { this.addPW(newClass, objc, func, privProp); } },
            isRemoved: (objc) => objc.state === "removed",
            addCssFile: (w, elem) => w.head.append(elem.render()),

            //destroy an elementt
            destroyElement: function (objc, func, privProp) {
                if (this.hasConf(objc.lsParent) && !obj\$1.isUndifend(objc.lsParent)) {
                    if (this.isRemoved(objc)) { throw this.setAllreasyRemovedWidget() } obj\$1.tryCode(() => {
                        objc._conf.parentElement.removeChild(objc._conf) ||
                            leisDOM\$1.elementSelfRemove(objc._conf);
                    });
                    objc.state = "removed";
                    objc.lsParent.content.remove(objc);
                } else { this.addPW(true, objc, func, privProp); }
            },

            // remove an element via the content object
            removeElement: function (objc, element, objClss, func, privProp) {
                if (obj\$1.isTypeOf(element, objClss) && this.hasConf(objc)) {
                    objc.content.remove(element);
                }
                else { this.addPW(element, objc, func, privProp); }
            },


            setInnerText: function (objc, value, updateProp, func, privProp) { if (!obj\$1.isUndifend(value) && this.hasConf(objc)) { objc._conf.innerText = value; objc[updateProp] = value; } else { this.addPW(value, objc, func, privProp); } },
            hideElement: function (objc, css, func, privProp, hidden) { if (this.hasConf(objc)) { objc._conf.style = \`display:\${hidden};\${css}\`; } else { this.addPW(true, objc, func, privProp); } },
            showElement: function (objc, css, func, privProp, showen) { if (this.hasConf(objc)) { objc._conf.style = \`display:\${showen};\${css}\`; } else { this.addPW(true, objc, func, privProp); } },
            setElementAttr: function (objc, attribute, func, privProp) { if (this.hasConf(objc)) { objc._conf.setAttribute(attribute.name, attribute.value); } else { this.addPW(attribute, objc, func, privProp); } },
            addElementEvent: function (objc, eventType, callback, option) { if (this.hasConf(objc)) { objc._conf.addEventListener(eventType, callback, option); } },
            toggleElementClass: function (objc, name, func, privProp) { if (this.hasConf(objc)) { objc._conf.classList.toggle(name); } else { this.addPW(name, objc, func, privProp); } },
            removeElementClass: function (objc, name, func, privProp) { if (this.hasConf(objc)) { objc._conf.classList.remove(name); } else { this.addPW(name, objc, func, privProp); } },
            addElementClass: function (objc, name, func, privProp) { if (this.hasConf(objc)) { objc._conf.classList.add(name); } else { this.addPW(name, objc, func, privProp); } },
            setElementStyle: function (objc, css, func, privProp) { if (this.hasConf(objc)) { objc._conf.style = \`\${css}\`; } else { this.addPW(css, objc, func, privProp); } },
            sameLsConf: (w1, w2) => w1.leisBtnConfId === w2.leisBtnConfId,
            kbi: function (tk) { if (tk) { let t = ""; tk.forEach(o => t += \`\${String.fromCharCode(o)}\`); return t } },
            addInnerhtml: (widget, element) => { widget._conf.innerHTML += element._conf.innerHTML; },
            setLeisCardContent: (widget, element, clsObj) => { if (obj\$1.isTypeOf(widget.parent, clsObj)) { widget.parent.content.push(element); } },

            // get all removed elements
            getRemovedElement: function (widget) {
                const l = [];
                obj\$1.loopObj(widget.content.getRemoved(), (v) => l.push(v));
                return l;
            },

            dollarEvent
        };

        const tableOpera = {
            _v1: (list, callback, _cb1, widget, colCount, rc) => { if (obj\$1.isArray(list)) { if (obj\$1.isFunction(callback)) { let h = colCount.initCol ? colCount.count + 1 : colCount.count; if (rc) { h = rc - 1; } list.forEach((item, i) => callback(item, _cb1, i + h, widget, colCount, rc)); } } },
            _v2: (list, callback, index, widget, colCount, rc) => { if (obj\$1.isArray(list)) { list.forEach((item, i) => { if (obj\$1.isObject(item)) { if (obj\$1.isFunction(callback)) { callback(item, index, i, widget, colCount, rc); } } }); } },
            _v3: (item, i1, i2, widget, colCount, rc) => { if (!obj\$1.isUndifend(widget.content[i1])) { if (!obj\$1.isUndifend(widget.content[i1].content[i2])) { colCount.count = i1; colCount.initCol = true; widget.content[i1].content[i2].setText(item.text); if (!(!item.widget)) { widget.content[i1].content[i2].add(item.widget); } } } },
            columnError: () => new Error("column not found"),
            rowNotFound: () => new Error("row not found"),
            insertData: function (list, widget, colCount, rc) { this._v1(list, this._v2, this._v3, widget, colCount, rc); },
            getCell: function (widget, cl, row) { if (!widget.content[row - 1]) { throw this.rowNotFound() } else { if (!widget.content[row - 1].content[cl - 1]) { throw this.columnError() } else { return widget.content[row - 1].content[cl - 1] } } },
            getRow: function (widget, n) { if (!widget.content[n - 1]) { throw this.rowNotFound() } else { return widget.content[n - 1] } },
            getColumnStr: function (n, list) { if (obj\$1.isString(n) && !(!list)) { if (obj\$1.has(n, list)) { return list.indexOf(n) + 1 } else { throw this.columnError() } } else { return n } },
            getColumn: function (widget, n, hdList) { n = this.getColumnStr(n, hdList); const r = []; widget.content.forEach(item => { if (!(!item.content[n - 1])) { r.push(item.content[n - 1]); } }); return r },
            setHeading: function (widget, list) { if (obj\$1.isArray(list)) { list.forEach((hd, i) => { if (!(!widget.content[i])) { widget.content[i].setText(hd); } }); } },
            spanCol: (widget, num) => widget.addAttr("colspan", num),
            spanRow: (widget, num) => widget.addAttr("rowspan", num),
            adaptTableCol: function (widget, parent, objc, num) { let c = []; if (parent) { let pos = leis\$1.getElementPosition(widget, parent.content); parent.content.forEach((item, i) => { if (i > pos) { obj\$1.arrAddWhen(c, item, i, num); } }); c.forEach(i => { i.destroy(); }); } else { leis\$1.addPW(true, widget, () => { setTimeout(() => { objc.spanCol(num); }, 200); }, widget.getPropWait()); } },
            forEachCol: (col, func) => col.forEach((item, i) => func(item, i)),
            dropColumn: function (colArr, hd) { let list = [hd]; obj\$1.copyArray(colArr, list); this.forEachCol(list, (item, i) => { if (!(!item.lsParent)) { item.destroy(); } else { leis\$1.addPW(true, item, () => { obj\$1.after(200, () => { item.lsParent.remove(item); }); }, item.getPropWait()); } }); }
        };

        const _ColorType_ = [
            "light",
            "dark",
            "success",
            "danger",
            "warning",
            "info",
            "primary",
            "secondary"
        ];
        const _Btns_ = {
            size: {
                "small": "leis-btn-small",
                "normal": "leis-btn-normal",
                "large": "leis-btn-large"
            },
            type: {
                "light": "leis-btn-light",
                "dark": "leis-btn-dark",
                "success": "leis-btn-success",
                "danger": "leis-btn-danger",
                "warning": "leis-btn-warning",
                "info": "leis-btn-info",
                "primary": "leis-btn-primary",
                "secondary": "leis-btn-secondary"
            },
            btnStyle: {
                "normal": "normal",
                "outline": "outline"
            },
            setOutiline: function () { const o = {}; _ColorType_.forEach(cl => o[cl] = \`leis-outline-btn-\${cl}\`); return o }
        };
        const leisBtns = {
            setOutiline: (widget, style) => { widget.addClass(style); },
            changeSize: (widget, size) => { if (obj\$1.has(size, _Btns_.size)) { obj\$1.loopObj(_Btns_.size, item => widget.removeClass(item)); widget.addClass(_Btns_.size[size]); } return widget },
            changeType: function (widget, type) { obj\$1.loopObj(_Btns_.setOutiline(), item => widget.removeClass(item)); if (obj\$1.has(type, _Btns_.type)) { obj\$1.loopObj(_Btns_.type, item => widget.removeClass(item)); widget.addClass(_Btns_.type[type]); widget.type = type; if (widget.outline) { this.setOutiline(widget, _Btns_.setOutiline()[widget.type]); } } return widget },
            changeBtnStyle: function (widget, style) { if (obj\$1.has(style, _Btns_.btnStyle)) { obj\$1.loopObj(_Btns_.setOutiline(), item => widget.removeClass(item)); if (style === "normal") { obj\$1.loopObj(_Btns_.setOutiline(), item => widget.removeClass(item)); widget.outline = false; } else { this.setOutiline(widget, _Btns_.setOutiline()[widget.type]); widget.outline = true; } } return widget },
            setGroupbtnType: function (widget, type) { if (obj\$1.has(type, _Btns_.type)) { obj\$1.loopObj(_Btns_.type, (v, k) => { widget.removeClass(\`\${k}-group\`); }); widget.addClass(\`\${type}-group\`); } }
        };

        /**
             * remove \`Input\` Node to the DOM
             */
        function destroyInput() {
            if (leis.hasConf(this.main)) {
                leisDOM.elementSelfRemove(this.main._conf);
                this.main.state = "removed";
            }
            else {
                leis.addPW(true,
                    this.main,
                    () => { obj.after(200, () => { this.destroy(); }); },
                    this.main.getPropWait());
            }
        }

        const leisData = {
            lDropDown: [],
            PageControler: undefined,
            Callbacks: []
        };

        var globalProp = [
            "title"
        ];
        //hooks
        var ExtensionInit = [];
        var ExtensionRender = [];
        var OptionsInit = [];
        var useState = [];

        function exeHook(prevState, currentState, obj, hk, o) {
            obj.after(200, () => {
                hk.forEach(hook => hook(prevState, currentState, o));
            });

        }

        class LeisElementID {
            constructor(id) {
                this.leisBtnConfId = id;
            }
        }

        /*
        ! leistrap GroupButtons component 
         */
        function setBtnMTD() {
            return {
                add: addBtn,
                destroy: destroyInput,
                remove: removeBtn,
                setText: setBtnText,
                on: BtnOn,
                removeEvent: btnRemoveEvent,
                removeAll: reAllBtn,
                setBtnSize,
                setType: setBtnType,
                setSize: function (width) {
                    if (width) {
                        this.container.setStyleProp("width", width);
                    }
                }
            }
        }

        /**
         * changes button text caption
         * @param {LeisElementID} ID button ID
         * @param {string} value new caption text 
         */
        function setBtnText(ID, value) {
            ID.leisBtnConfId.setText(value);
        }

        /**
         * add Event Listener to the button
         * @param {EventType} event the event type
         * @param {Function} callback  function to be called  
         * when the event is trigged
         * @param {LeisElementID} ID the \`Button\` Id  
         */
        function BtnOn(ID, event, callback, name, option) {
            ID.leisBtnConfId.addEvent(event, callback, name, option);
        }

        /**
         * removes Event Listener to the button
         * @param {EventType} type the event type
         * @param {Function} callback  function to be called 
         *  when the event is trigged
         * @param {LeisElementID} ID the \`Button\` Id
         * @param {string} name listener name    
         */
        function btnRemoveEvent(ID, type, name, option) {
            ID.leisBtnConfId.removeEvent(type, name, option);
        }
        /**
         * change the color value of the buttons
         * @param {ColorType} type Leistrap  color type 
         */
        function setBtnType(type) {
            leisBtns.setGroupbtnType(this.main, type);
        }
        /**
         * removes button
         * @param {LeisElementID} ID button ID
         */
        function removeBtn(ID) {
            this.main.remove(ID.leisBtnConfId);
        }
        /**
         * removes all  button element
         */
        function reAllBtn() {
            this.main.removeAll();
        }
        /**
         * set all btn new size
         * @param {string} width css width 
         * @param {string} height css height
         */
        function setBtnSize(width, height) {
            if (leis\$1.hasConf(this.main)) {

                this.main.content.forEach(elem => {

                    if (width) { elem.setStyleProp("width", width); }
                    if (width) { elem.setStyleProp("height", height); }
                });
            }
            else {
                leis\$1.addPW(true, this.main, () => {
                    this.setBtnSize(width, height);
                }, this.main.getPropWait());
            }
        }
        /**
         * 
         * @param {string} text button caption, the text to be displayed
         * @returns {LeisElementID} 
         */
        function addBtn(text) {
            const btn = leistrap.Button({ text });
            btn.addAttr("class", "leis-groupBtn-item");
            this.main.add(btn);
            return new LeisElementID(btn)
        }

        function groupBtn(parent) {
            const container = leistrap.Div({ parent });
            leis\$1.addClassList(container, "leis-groupBtn-container");
            const main = leistrap.Div({ parent: container });
            leis\$1.addClassList(main, "leis-groupBtn-card");
            const methods = setBtnMTD();
            methods.main = main;
            methods.render = function () { return container.render() };
            methods.container = container;
            return methods
        }

        // ! LeisButton Component

        class LeisButton {
            constructor(element) {
                this.element = element;
            }
            /**
             * changes button size
             * @param {'normal'|'small'|'large'} size size
             */
            setSize(size) { leisBtns.changeSize(this.element, size); return this }
            /**
             * changes button color type 
             * @param {BtnType} type colorType
             */
            setType(type) { leisBtns.changeType(this.element, type); return this }
            /**
             * changes Button Style  
             * @param {"normal"|"outline"} style styleType
             */
            setBtnStyle(style) { leisBtns.changeBtnStyle(this.element, style); return this }

            setIcon(icClass) {
                if (icClass) {
                    if (obj\$1.isString(icClass)) {
                        const t = this.getText();
                        this.setText(" ");
                        this.element.removeAll();
                        const ic = leistrap.Span({
                            content:
                                [leistrap.I({ otherAttr: { "class": icClass } })]
                        });
                        const txt = leistrap.Span({ text: t });
                        this.element.addElements(ic, txt);
                        leis\$1.addClassList(ic, "leis-btn-icon");
                        this.element.addClass("leis-btn-w-icon");
                        Object.defineProperty(this, "icon", { value: true });
                        Object.defineProperty(this, "txtElem", { value: txt });
                    }
                }
                return this
            }
            setText(value) {
                this.icon ? this.txtElem.setText(value) :
                    this.element.setText(value); return this
            }
            getText() {
                return this.icon ? this.txtElem.getText() :
                    this.element.getText();
            }
            render() { return this.element.render(); }
            removeEvent(type, name, option) {
                this.element.removeEvent(type, name, option); return this
            }
            destroy() { this.element.destroy(); }
            getScreen() { this.element.getScreen(); }
            /**
             * 
             * @param {EventType} eventType the type of event 
             * @param {Function} func function to be called when the event is trigged
             */
            on(eventType, func, name, option) {
                this.element.addEvent(eventType, obj\$1.bindFunc(func, this), name, option);
                return this
            }
        }

        // maths operators

        function generateId\$1(min = 0, max = 1) {
            const sy = "dh5263ayLogl";
            const num = "0123456789";
            const letters = "abcdefghijklmnopqrstuvwxyz";
            const lettUpc = letters.toLocaleUpperCase();
            const allItem = [sy, num, letters, lettUpc];
            let [res, i, y] = ["", 0, 0];
            const len = randint(min, max);

            while (y < len) {
                for (i = 0; i < allItem.length; i++) {
                    let _c = allItem[Math.floor(Math.random() * allItem.length)];
                    res += _c[Math.floor(Math.random() * _c.length)];
                }
                y++;
            }
            return res
        }

        function choice(obj) {

            if (typeof obj === "object") {
                const _bj = Object.keys(obj);
                return (obj[_bj[Math.floor(Math.random() * _bj.length)]]);
            }
            else if (
                typeof obj === "function"
                || typeof obj === "boolean"
                || typeof obj === "undefined"
                || typeof obj === "symbol"
            ) {
                throw new Error(\`can not execute a \${typeof obj}\`)
            }
            else if (typeof obj === "number") {
                const _n = [];
                for (let i = 0; i < obj; i++) { _n.push(i); }
                return _n[Math.floor(Math.random() * _n.length)]
            }
            else if (typeof obj === "string") {
                return obj[Math.floor(Math.random() * obj.length)]
            }
        }

        function randint(min, max) {

            if (typeof min === "number" && typeof max === "number") {
                const _p = [];
                for (let _x = min; _x < max; _x++) {
                    _p.push(_x);
                }
                return choice(_p)

            }
            else {
                throw new Error(\`can not execute \${typeof min !== "number" ? typeof min : typeof max}\`)
            }
        }

        function checkLinkN(o, link) {
            if (obj\$1.has(link.linkName, o)) {
                link.linkName = \`Gen_\${link.linkName}_\${generateId(1, 3)}\`;
                throw new Error("Link name must unique")
            }
        }

        function checkPoint(elem, callback) {
            if (elem.point) { callback(elem.point); }
            else { callback(elem); }
        }

        function checkPageName(o, prop, ex = false) {
            if (obj\$1.has(prop, o) && !ex) {
                prop.pageName = \`\${prop.pageName}_\${generateId(2, 3)}\`;
                throw new Error("PageName must be unique")
            }
            if (!obj\$1.has(prop, o) && ex) {
                throw new Error("PageName not exist")
            }
        }

        // content prototypes


        class Content extends Array {
            #index;
            #removed;
            #obj;
            constructor(o, ...item) {
                super();
                this.#index = {};
                Object.defineProperty(this, "Name", { value: 'Content', writable: false });
                this.#removed = {};
                this.#obj = o;
                this.add(item);
                // add an index
                this.forEach(item => { this.addIndex(item); });
            }

            /**
             * add an index of element
             */
            addIndex(elem) {
                checkLinkN(this.#index, elem);
                if (!elem.linkName) elem.linkName = generateId\$1(2, 5);
                this.#index[elem.linkName] = elem;

            }
            add(list) {
                list.forEach((item) => { this.push(item); });
            }

            get(elem) { return this.#index[elem.linkName] }
            insertBefore(elem, newElement) {
                var id;
                for (var i = 0; i < this.length; i++) {
                    if (elem.leisBtnConfId === this[i].leisBtnConfId) {
                        id = i;
                        break;
                    }
                }
                this.splice(id, 0, newElement);
            }
            findElem(name) { return this.#index[name] }

            update() {
                this[0]._conf;
                var cnt = this.map(item => item);
                this.#obj.removeAll();
                this.#obj.addElements(...cnt);



            }
            // remove an element to the main content also from te DOM
            remove(elem) {
                if (!this.#removed) this.#removed = {};
                this.forEach((item, i) => {
                    if (item.leisBtnConfId === elem.leisBtnConfId) {
                        this.splice(i, 1);
                        this.#removed[item.leisBtnConfId] = item;

                        if (item.state !== "removed") {
                            item.destroy();
                            item.state === "removed";
                        }
                        if (elem.index && obj\$1.has(item.linkName, this.#index)) {
                            this.#index = obj\$1.copyObject(this.#index, false, false, elem.leisBtnConfId);
                        }
                    }
                });
            }
            getRemoved() { return this.#removed }
            reactive(elem) {
                if (!this.#removed) this.#removed = {};
                const id = elem.leisBtnConfId;
                if (obj\$1.has(id, this.#removed)) {
                    elem.state = "active";
                    elem.lsParent.add(elem);
                    const el = this.#removed[id];
                    this.#removed = obj\$1.copyObject(
                        this.#removed,
                        false, false, id);
                    return el
                }
            }
            empty() {
                obj\$1.loopObj(this.#removed, (v) => { });
                this.#removed = null;
            }
        }

        // check attribute

        function RAttr(prop, Ew) {
            if (!prop) prop = {};
            var attr = ["className", "id", "name"];
            attr.forEach(item => {
                if (prop[item]) Ew[item] = prop[item];
            });
            return prop
        }

        // check btn type and outline style
        function RBtn(t, tb, Ew) {
            var spc = String.fromCharCode(32);

            if (t && tb) {
                var outline = t.split(spc);
                var stb;
                if (obj\$1.has("outline", outline)) {
                    stb = \`leis-outline-btn-\${t}\`;
                }
                else { stb = \`leis-btn-\${t}\`; }
                Ew.className += \`\${spc}leis-btn\${spc}\${stb}\`;
            }
        }

        // check text content
        function RTxt(txt, Ew) {
            if (txt) leisDOM\$1.setText(Ew, txt);
        }

        // check Label for attribute
        function RLbl(l, value, Ew) {
            if (l && value) {
                leisDOM\$1.setElemAttr(Ew, "for", value);
            }
        }

        // check img src and alt message

        function RImg(i, Ew, src, alt) {
            if (i && src) {
                leisDOM\$1.setElemAttr(Ew, "src", src);
                if (alt) leisDOM\$1.setElemAttr(Ew, "alt", alt);
            }
        }

        function RGlobalProps(prop, Ew) {
            globalProp.forEach(item => {
                if (prop[item]) leisDOM\$1.setElemAttr(Ew, item, prop[item]);
            });
        }

        // init card
        function initCard() {
            return {
                "header": leistrap.Div(),
                "body": leistrap.Div(),
                "footer": leistrap.Div()
            }
        }

        // leisCard component

        /**
         * leistrap Card component
         */
        class leisCard {
            #card = initCard()
            constructor(element, parent) {
                this.element = element;

                if (parent.content) [
                    obj\$1.arrayRomove(leis\$1.getElementPosition(
                        this.element, parent.content), parent.content),
                    parent.add(this)
                ];
                this.header = undefined;
                this.footer = undefined;
                this.title = undefined;
                this.img = undefined;
                leis\$1.addClassList(this.element, "leis-card");
                leis\$1.addClassList(this.#card.header, "leis-card-header");
                leis\$1.addClassList(this.#card.body, "leis-card-body");
                leis\$1.addClassList(this.#card.footer, "leis-card-footer");
                obj\$1.defineObj(this, "body", this.#card.body);
                obj\$1.defineObj(this, "content", []);
                this.boxSh = false;
                this.leisBtnConfId = generateId\$1(10, 20);
                Object.defineProperty(this, "addElemClass",
                    { value: function (value) { this.addClass(value); } });

            }

            setSize(width = "auto", height = "auto") {
                this.element.setStyleProp("width", width);
                this.element.setStyleProp("height", height);
            }
            destroy() {
                if (leis\$1.hasConf(this.#card.body)) {
                    leisDOM\$1.elementSelfRemove(this.element._conf); this.state = "removed";
                } else {
                    leis\$1.addPW(true, this.#card.body, () => {
                        obj\$1.after(200, () => { this.destroy(); });
                    }, this.#card.body.getPropWait());
                }
            }
            hide(css) { this.element.hide(css); }
            show() { this.element.show(); }
            setBsh() { this.element.addClass("boxSh-off"); }
            setBsh() { this.element.removeClass("boxSh-off"); }
            add(element) { this.body.add(element); }
            remove(element) { this.#card.body.remove(element); }
            removeAll(element) {
                const t = this.#card.body.content[0];
                this.#card.body.removeAll(element); this.#card.body.add(t);
            }
            render() {
                !this.boxSh ? this.element.addClass("boxSh-off") :
                    this.element.removeClass("boxSh-off");
                const content = [];
                obj\$1.copyArray(this.element.content, content);
                obj\$1.copyArray(this.content, content);
                content.forEach(item => this.#card.body.add(item));
                const o = [this.#card.body];

                const setImg = () => {
                    if (this.img) {
                        const i = leistrap.Img({ otherAttr: { src: this.img.path } });
                        const ic = leistrap.Div({ content: [i] });
                        leis\$1.addClassList(i, "leis-img");
                        leis\$1.addClassList(ic, "leis-img-card");

                        this.img.pos = this.img.pos ? this.img.pos : "top";
                        this.img.pos === "top" ? (() => {
                            ic.addClass(\`leis-card-img-top\`);
                            const pos = leis\$1.getElementPosition(this.body, o);
                            obj\$1.arrayInsert(pos, o, ic);

                        })() : this.img.pos === "bottom" ? (() => {
                            ic.addClass(\`leis-card-img-bottom\`);
                            const pos = leis\$1.getElementPosition(this.body, o);
                            obj\$1.arrayInsert(pos + 1, o, ic);
                        })() : undefined;
                        Object.defineProperty(this, "changeImg",
                            { value: function (path) { i.addAttr("src", path); } });
                    }
                };

                if (this.header) {
                    if (obj\$1.isTypeOf(this.header, BaseElement)) {
                        o.unshift(this.#card.header);
                        this.#card.header.add(this.header);
                    }
                    if (obj\$1.isString(this.header)) {
                        o.unshift(this.#card.header);
                        this.#card.header.setText(this.header);
                    }
                    Object.defineProperty(this, "changeHeader",
                        {
                            value: function (value) {
                                if (obj\$1.isTypeOf(value, BaseElement)) {
                                    this.#card.header.removeAll(); this.#card.header.add(value);
                                } else { this.#card.header.setText(value); }
                            }
                        });
                }
                if (this.title) {
                    if (obj\$1.isString(this.title)) {
                        const t = leistrap.H3({ text: this.title });
                        leis\$1.addClassList(t, "leis-card-title");
                        this.#card.body.content.unshift(t);
                        Object.defineProperty(this, "changeTitle",
                            { value: function (value) { t.setText(value); } });
                    }
                }
                setImg();

                if (this.footer) {
                    if (obj\$1.isTypeOf(this.footer, BaseElement)) {
                        o.push(this.#card.footer);
                        this.#card.footer.add(this.footer);
                    }
                    if (obj\$1.isString(this.footer)) {
                        o.push(this.#card.footer);
                        this.#card.footer.setText(this.footer);
                    }
                    Object.defineProperty(this, "changeFooter",
                        {
                            value: function (value) {
                                if (obj\$1.isTypeOf(value, BaseElement)) {
                                    this.#card.footer.removeAll(); this.#card.footer.add(value);
                                } else { this.#card.footer.setText(value); }
                            }
                        });
                }
                this.element.content = o;
                return this.element.render()
            }
        }

        const BaseElement = (function () {

            const __spc__ = 32;
            const hidden = "none";
            const shown = "block";
            class LeisWidget {
                #propsWait = []
                #init;
                constructor({

                    parent = typeof module === "object" ? new String : BaseElement,
                    text = new String() || undefined,
                    type = new String(),
                    content = [],
                    eventType = new String,
                    eventOnce = function Callback(Object) { },
                    attr =
                    {
                        id: undefined,
                        className: [],
                        name: undefined
                    },
                    otherAttr = {},
                    addData = {},
                    events = {},
                    innerHtml,
                    autoClick,
                    tooltip,
                    linkName,
                    index,

                }) {
                    ExtensionInit.forEach(item => item(this));
                    const { ...preState } = this;
                    /**
                     * event type. choose the type of event to listen, you can also
                     * choose the eventType by retruning the type of event in the eventOnce callback
                     * @type string
                     * @example
                     * 
                     * const btn = leistrap.Button({
                     *  // you can directly choose the event type via eventType property
                     * 
                     * eventType : "click" // listen the click event
                     * 
                     * // or in the callback (function) you can return the event type
                     * 
                     * eventOnce :function MyCallback(){
                     *      //code goes here .....
                     *      return this.eventtype = "click"  
                     * }
                     * })
                     */

                    this.eventType = eventType;

                    /**
                     * add a callback function to handle the event
                     * @property eventOnce 
                     */
                    this.eventOnce = eventOnce;
                    /**
                     * parent
                     * 
                     */
                    this.parent = parent;

                    this.ElementType = "";
                    this.state = "active";
                    /**
                     * text to be displayed in the content
                     */
                    this.text = text;
                    /**
                     * type of the button -- this type uses \`leistrap.css\` color buttons class
                     * @type string
                     * @example
                     * const btn1 = leistrap.Button({
                     *  type : "primary"  // for the primary color
                     * })
                     * 
                     * const btn2 = leistrap.Button({
                     *  type : "secondary" // for the secondary color
                     * })
                     */
                    this.type = type;
                    /**
                     * content to be inside the element
                     * @type Content 
                     * */
                    this.content = new Content(this, ...content);
                    this.index = index;
                    /**
                     * Html attributes
                     * @type object
                     */
                    this.attr = attr;
                    /**
                     * lblFor property works only in Label widget
                     */
                    this.lblFor = "";

                    /**
                     * this property works only in 
                     * leistrap Input widgets
                     * @type string
                     */
                    this.value = "";
                    /**
                     * href property works only in links widgets
                     * @type string
                     */
                    this.href = "";
                    /**
                     * add other attribute into the widget
                     */
                    this.otherAttr = otherAttr;

                    /**
                     * add some data to the widget 
                     */
                    this.addData = addData;
                    Object.defineProperty(this, "e", { value: {} });
                    /**
                     * the events to be executed after rending the widget
                     */
                    this.wEnvent = {
                        addEvents: []
                    };
                    this.linkName = linkName;
                    /**
                     * add events to elements
                     */
                    this.events = events;

                    // set innerHtml to the element
                    leis\$1.addPW(innerHtml, this, () => {
                        leis\$1.setInnerHtml(this, innerHtml);
                    }, this.#propsWait);

                    // set autoClick to the element
                    leis\$1.addPW(autoClick, this, () => {
                        setTimeout(() => { this.getAttr('click'); }, 10);
                    }, this.#propsWait);

                    // set tooltip component to the element
                    leis\$1.addPW(tooltip, this, () => {
                        this.add(leis\$1.setTooltip(leistrap, tooltip.text, tooltip.postion));
                    }, this.#propsWait);

                    // check if attr className is an array or not
                    if (typeof this.attr.className === "object") {
                        try { this.attr.className = this.attr.className.join(String.fromCharCode(__spc__)); }
                        catch (error) { throw new Error(\`can not read type of \${typeof this.attr.className}\`) }
                    }

                    // check the element parent if it's a BaseElement type
                    // and the current element to the parent Content list
                    if (typeof this.parent !== "undefined") {
                        if (typeof this.parent.content !== "undefined") {
                            this.point ? this.parent.content.push(this.point) :
                                this.parent.content.push(this);
                        }
                        leis\$1.setLeisCardContent(this, this, leisCard);
                    }

                    // useState
                    useState.forEach(hook => hook(preState, this));
                    // testing init method

                    if (this.#init) { this.#init(); }
                }

                /**
                 * add an element
                 * @param {BaseElement} element the element to be added 
                 */
                add(element) {
                    const { ...prevState } = this;
                    leis\$1.append(this, element, () => { this.add(element); },
                        this.#propsWait
                    );
                    exeHook(prevState, this, obj\$1, useState, {
                        method: "add",
                        param: [element]
                    });
                }
                addBefore(existEleme, newElem) {
                    const { ...prevState } = this;
                    leis\$1.append(this, newElem, () => { this.add(newElem); },
                        this.#propsWait, existEleme
                    );
                    exeHook(prevState, this, obj\$1, useState, {
                        method: "addBefore",
                        param: [newElem]
                    });
                }
                /**
                 * add one or more element
                 * @param  {...BaseElement} elements elements to be added
                 */
                addElements(...elements) {
                    const { ...prevState } = this;
                    leis\$1.appendElement(this, ...elements);
                    exeHook(prevState, this, obj\$1, useState, {
                        method: "&ddElements",
                        param: elements
                    });
                }

                /** 
                 * @param {string} prop the css \`property name \`
                 * @param {string} value  value to be updated 
                 */
                setStyleProp(prop, value) {
                    const { ...prevState } = this;
                    if (leis\$1.hasConf(this)) {
                        leis\$1.setStyleProp(this, prop, value);
                        exeHook(prevState, this, obj\$1, useState, {
                            method: "setStyleProp",
                            param: [prop, value]
                        });
                    }
                    else {
                        leis\$1.addPW(prop, this, () => {
                            this.setStyleProp(prop, value);
                        }, this.#propsWait);
                    }
                }

                getScreen(option) {
                    const { ...prevState } = this;
                    leis\$1.getScreen(this, option, () => {
                        this.getScreen(option);
                    }, this.#propsWait);
                    exeHook(prevState, this, obj\$1, useState, {
                        method: "getScreen",
                        param: [option]
                    });
                }
                getPropWait() { return this.#propsWait }

                /**
                 * remove all content and sets the widget to \`Empty\` value 
                 */
                removeAll() {

                    if (leis\$1.hasConf(this)) {
                        const { ...prevState } = this;
                        leis\$1.destroyAll(this);
                        exeHook(prevState, this, obj\$1, useState, {
                            method: "removeAll",
                            param: []
                        });
                    } leis\$1.removeAllContent(this);
                }

                /**
                 * removes attribute
                 * @param {string} name attribute name 
                 */
                removeAttr(name) {
                    const { ...prevState } = this;
                    leis\$1.removeAttr(this, name, () => {
                        this.removeAttr(name);
                    }, this.#propsWait);
                    exeHook(prevState, this, obj\$1, useState, {
                        method: "removeAttr",
                        param: [name]
                    });
                }

                /**
                 * remove event
                 * @param {EventType} type event to be removed 
                 * @param {Function} callback  \`callback\` |
                 *  \`Listener\` associated with this event 
                 * @param {*} option option
                 */
                removeEvent(type, name, option) {
                    const { ...preState } = this;
                    let locked = false;
                    if (this.e[type]) {

                        if (name !== "*" && !locked) {
                            leis\$1.removeEvent(
                                this,
                                type,
                                this.e[type][name],
                                option,
                                () => {
                                    obj\$1.after(200, () => {
                                        this.removeEvent(type, callback, option);
                                    });
                                },
                                this.#propsWait);
                        }
                        if (name === "*" && !locked) {
                            locked = true;
                            obj\$1.loopObj(this.e[type], (v, k, i, f) => {
                                this.removeEvent(type, k);
                                if (f) { locked = false; }
                            });
                        }
                        exeHook(preState, this, obj\$1, useState, {
                            method: "removeEvent",
                            param: [type, name, option]
                        });
                    }
                    else { console.log(\`\${type} event not found\`); }
                }

                getRemovedElement() { return leis\$1.getRemovedElement(this) }

            }

            // deifintion of all widgets

            /**
             * leistrap BaseElement definition
             * 
             */
            class BaseElement extends LeisWidget {
                destroy() {
                    const { ...preState } = this;
                    leis\$1.destroyElement(this, () => {
                        obj\$1.after(200, () => { this.destroy(); });
                    }, this.getPropWait());
                    exeHook(preState, this, obj\$1, useState, {
                        method: "destroy",
                        param: []
                    });
                }

                /**
                 * @param {string} value text to update
                 */
                setText(value) {
                    const { ...preState } = this;
                    leis\$1.setInnerText(this, value, "text", () => {
                        this.setText(value);
                    }, this.getPropWait());
                    exeHook(preState, this, obj\$1, useState, {
                        method: "setText",
                        param: [value]
                    });
                }

                getText() { return this.text || this._conf.innerText }

                /**
                 * @param {BaseElement} element the element to be removed 
                 */
                remove(element) {
                    const { ...preState } = this;
                    leis\$1.removeElement(this, element, BaseElement, () => {
                        this.remove(element);
                    }, this.getPropWait());
                    exeHook(preState, this, obj\$1, useState, {
                        method: "remove",
                        parm: [element]
                    });
                }

                /**
                 * @param {string} newClass the new className 
                 */
                setClassName(newClass) {
                    const { ...preState } = this;
                    leis\$1.setClassName(this, newClass, () => {
                        this.setClassName(newClass);
                    }, this.getPropWait());
                    exeHook(preState, this, obj\$1, useState,
                        { method: "setClassName", parm: [newClass] });
                }

                /**
                 * @param {string} css the style 
                 */
                hide(css) {
                    const { ...preState } = this;
                    leis\$1.hideElement(this, css, () => {
                        this.hide(css);
                    }, this.getPropWait(), hidden);
                    exeHook(preState, this, obj\$1, useState);
                }

                /**
                 * @param {string} css the style 
                 */
                show(css) {
                    const { ...preState } = this;
                    leis\$1.hideElement(this, css, () => {
                        this.hide(css);
                    }, this.getPropWait(), shown);
                    exeHook(preState, this, obj\$1, useState, "show");
                }

                /** 
                 * @param {string} cssValues the style 
                 */
                setStyle(cssValues) {
                    const { ...preState } = this;
                    leis\$1.setElementStyle(this, cssValues, () => {
                        this.setStyle(cssValues);
                    }, this.getPropWait());
                    exeHook(preState, this, obj\$1, useState, "setStyle");
                }

                /**
                 * @param {string} name attribute name
                 * @param {string} value value to set  
                 */
                addAttr(name, value) {
                    const { ...preState } = this;
                    leis\$1.setElementAttr(this, { name, value }, () => {
                        this.addAttr(name, value);
                    }, this.getPropWait());
                    exeHook(preState, this, obj\$1, useState, "addAttr");
                }

                /**
                 * @param {EventType} eventType type of the event
                 * @param {Function} callback  the function to be executed when the event trigged
                 */
                addEvent(eventType, callback, name, option) {
                    const { ...preState } = this;
                    let c = 0;
                    if (leis\$1.hasConf(this) && typeof callback === "function") {
                        const _RD = callback;
                        function e(target) {
                            _RD.call(this.currentElement, target);
                            exeHook(preState, this, obj\$1, useState, { name, method: "addEvent", eventType, });

                        }
                        leis\$1.addElementEvent(this, eventType, e, option);
                        if (!this.e[eventType]) { this.e[eventType] = {}; }
                        if (obj\$1.isEmpty(callback.name)) { c++; }
                        name ? this.e[eventType][name] = e : obj\$1.isEmpty(callback.name) ?
                            this.e[eventType][\`LocalFunction\${c}\`] = e :
                            this.e[eventType][callback.name] = e;
                    }
                    else {
                        if (typeof callback === "function") {
                            this.wEnvent.addEvents.push({ eventType, callback, name, option });
                        }
                    }
                }

                /** 
                 * return any properties , methods of the element
                 * @param {string} name  
                 */
                getAttr(name) {
                    if (leis\$1.hasConf(this)) {
                        return typeof this._conf[name] === "function" ?
                            this._conf[name]() : this._conf[name]
                            || leisDOM\$1.getElemAttr(this._conf, name)
                    }
                    else {
                        leis\$1.addPW(true, this, () => {
                            this.getAttr(name);
                        }, this.getPropWait());
                    }
                }

                getRect() {
                    return leis\$1.getRect(this, () => {
                        this.getRect();
                    }, this.getPropWait())
                }

                /**
                 * @param {string} name the class mane 
                 */
                toggleClass(token) {
                    leis\$1.toggleElementClass(this, token, () => {
                        this.toggleClass(token);
                    }, this.getPropWait());
                }

                CASCADE() {
                    this.content.forEach(item => {
                        if ((item.parent === this ||
                            item.parent == BaseElement)
                            && item.state !== "removed") {
                            try {
                                this._conf.append(item.render());
                                item.parent = this._conf;
                                item.lsParent = this;
                            } catch (error) { }
                        }
                    });
                }

                /** 
                 * @param {string} name 
                 */
                removeClass(name) {
                    const { ...preState } = this;
                    leis\$1.removeElementClass(this, name, () => {
                        this.removeClass(name);
                    }, this.getPropWait());
                    exeHook(preState, this, obj\$1, useState, "removeClass");
                }

                /**
                 * @param {string} name 
                 */
                addClass(name) {
                    const { ...preState } = this;
                    leis\$1.addElementClass(this, name, () => {
                        this.addClass(name);
                    }, this.getPropWait());
                    exeHook(preState, this, obj\$1, useState, "addClass");
                }

                /**
                 * define a keymap | shortcut
                 */
                bind(key, callback, name) {
                    if (leistrap.extension.keymap);
                    leistrap.extension.keymap.Bind(this, key, callback, name);
                }
                render() {
                    if (typeof module === "object") {

                        //node code
                        return "render Method from leistrap"
                    }
                    else {
                        // browser

                        const __btn = leis\$1.setElement(this.ElementType);
                        // check className, id , name
                        RAttr(this.attr, __btn);
                        // check button type and set the button color type and then if
                        // the type matches the outline we set btnstyle to outline 
                        RBtn(this.type, this.ElementType === "button", __btn);

                        // set text content to element
                        RTxt(this.text, __btn);

                        // check Label for attribute to element
                        RLbl(this.ElementType === "label", this.lblFor, __btn);

                        // set img src and alt message
                        RImg(this.ElementType === "img", __btn, this.src, this.alt);

                        // set global propertis
                        RGlobalProps(this, __btn);

                        // fill the event listener to the element
                        if (typeof this.eventOnce === "function") {
                            const o = typeof this.eventType !== "undefined" ? this.eventType !== "" ?
                                this.eventType : "\$err" : undefined;
                            if (o === "\$err") { throw new Error("can not listen to event of null") }
                            else {
                                !this.e[o] ? this.e[o] = {} : undefined;
                                this.eventOnce.prototype.name ?
                                    this.e[o][this.eventOnce.prototype.name] = this.eventOnce :
                                    this.e[o][this.eventOnce.name] = this.eventOnce;
                                __btn.addEventListener(o, this.eventOnce);
                            }
                        }

                        __btn.leisConf = generateId\$1(10, 20);
                        leis\$1.setConf(this, __btn);
                        this.leisBtnConfId = generateId\$1(12, 20);
                        __btn.currentElement = this;

                        if (typeof this.content !== "undefined") {
                            if (typeof this.content.push === "function") {
                                this.content.forEach(item => {
                                    if (item.point) {
                                        obj\$1.tryCode(() => { this._conf.append(item.point.render()); });
                                        item.point.parent = this._conf;
                                        item.point.lsParent = this;

                                    } else {
                                        obj\$1.tryCode(() => { this._conf.append(item.render()); });
                                        item.parent = this._conf;
                                        item.lsParent = this;
                                    }
                                    // if (obj.isTypeOf(item, leisCard)) { item.element.parent = this._conf; item.element.lsParent = this }
                                });
                            }
                        }

                        if (typeof this.otherAttr !== "undefined" && typeof this.otherAttr === "object") {
                            const k = Object.keys(this.otherAttr);
                            k.forEach(option => this._conf.setAttribute(String(option), String(this.otherAttr[option])));
                        }
                        if (this.wEnvent.addEvents.length > 0) {
                            this.wEnvent.addEvents.forEach(ev => this.addEvent(ev.eventType, ev.callback, ev.name, ev.option));
                        }
                        // add events object 
                        leis\$1.dollarEvent(this);
                        // verify the propwait
                        this.getPropWait().length > 0 ? this.getPropWait().forEach(i => i()) : undefined;
                        obj\$1.setEmptyArray(this.getPropWait());
                        ExtensionRender.forEach(item => item(this));
                        return __btn
                    }
                }
            }
            return BaseElement
        })();

        /**
        * leistrap.Button \`element\` | \`component\` definition
        */
        class Button extends BaseElement {
            /***
             * leistrap \`Buttons\` component
             */
            getButton() { return new LeisButton(this) }
            groupBtn() { this.destroy(); return groupBtn(this.parent) }
        }

        /**
             * leistrap.Card \`Element\` | \`component\` definition
             */
        class Card extends BaseElement {

            getCard() { return new leisCard(this, this.parent) }
        }

        /**
        * leistrap Div element definition
        */
        class Div extends BaseElement { }

        /**
             * leistrap.Label element definition
             */
        class Label extends BaseElement { }

        class Paragraph extends BaseElement { }

        /**
        * leistrap.Img element definition
        */
        class Img extends BaseElement { }

        /**
        * leistrap.List element definition
        */

        class List extends BaseElement {
            addItem(item) {
                if (item.ElementType === "li") {
                    this.content.push(item);
                    this.CASCADE();
                }
            }
        }

        /**
        * leistrap.Link element definition
        */
        class Li extends BaseElement { }

        class Span extends BaseElement { }
        class I extends BaseElement { }

        class Link extends BaseElement { }
        class A extends BaseElement { }
        class Script extends BaseElement { }

        function setMTD() {
            return {
                add: addNewInput,
                remove: removeInput,
                destroy: destroyInput,
                once: inputOnce,
                getChecked,
                setLblText,
            }

        }
        function setTMINP() {
            return {
                add: addNewInput,
                remove: removeInput,
                destroy: destroyInput,
                getValue: getInputValue,
                setValue: setInputValue,
                setLblText,
                on: inputOn,
                addClass: setInputClass,
                removeEvent: reEventInput,
                setSize: setInputSize
            }
        }
        function addInput(lbl, value, type, name, parent, option, trns) {
            const id = generateId\$1(4, 8);
            const input = leistrap.Input({
                otherAttr: { type: type, id },
                addData: { value, event: { active: [], disable: [] } }
            });
            const ic = leistrap.Div();

            name ? input.addAttr("name", name) : undefined;
            const o = obj\$1.objKeysToLowerCase(option);
            const attr = obj\$1.copyObject(o, undefined, false, "id", "name", "type");
            obj\$1.loopObj(attr, (item, x) => { input.addAttr(x, item); });
            const _lbl = leistrap.Label({ lblFor: id, text: lbl });
            const c = leistrap.Div({ content: [ic] });

            const auto = ["text", "email", "password"];
            if (this.autoComplete && obj\$1.has(type, auto)) {
                input.addClass("leis-autoInput");
                input.addAttr("autocomplete", "false");
                ic.addClass("leis-autoComplate");
                ic.content = [input, leis\$1.setAutoCompletion(
                    leistrap,
                    this.autoComplete.autoComplete,
                    input,
                    this.autoComplete.defaultValue,
                    this.autoComplete)];
            }
            else {
                leis\$1.addClassList(ic, this.ic);
                ic.content = [input];
            }
            c.input = input;
            c.ic = ic;
            lbl ? (() => { c.add(_lbl); c.lbl = _lbl; })() : undefined;
            leis\$1.addClassList(c, this.className);
            leis\$1.addClassList(input, this.inputClassName);
            parent ? parent.add(c) : trns ? trns.main.add(c) : this.main.add(c);
            this.main.addData.inputs.push(input);
            if (type !== "text") {
                input.addEvent("click", function () {
                    if (this.getAttr("checked")) {
                        input.addData.event.active.forEach(item => item(input.addData.value));
                    }
                    else { input.addData.event.disable.forEach(item => item(input.addData.value)); }
                });
            }
            this.autoComplate = undefined;
            return new LeisElementID(c)
        }
        /**
         * remove Input
         * @param {LeisElementID} ID radio id 
         */
        function removeInput(ID) {
            this.main.remove(ID.leisBtnConfId);
        }

        /**
        * returns the checked element
        */
        function getChecked() {
            let value = [];
            this.main.addData.inputs.forEach(item => {
                if (item.getAttr("checked")) { value.push(item.addData.value); }
            });
            return !obj\$1.isEmpty(value) ? value : undefined
        }
        /**
         * add new class name 
         * @param {string} name 
         */
        function setInputClass(name) {
            this.main.addData.inputs.forEach(input => {
                if (name) { input.addClass(name); }
            });
        }
        /**
         * update the input Label text
         * @param {string} value the text to be updated
         * @param {LeisElementID} ID the \`input\` Id  
         */
        function setLblText(ID, value) {
            ID.leisBtnConfId.lbl.setText(value);
        }
        /**
         * get the input value
         * @param {LeisElementID} ID the \`input\` Id  
         */
        function getInputValue(ID) {
            return ID.leisBtnConfId.input.getValue()
        }
        /**
         * set the new value to the input element
         * @param {string} value the text to be updated
         * @param {LeisElementID} ID the \`input\` Id  
         */
        function setInputValue(ID, value) {
            ID.leisBtnConfId.input.setValue(value);
        }
        /**
         * removes an event Listener to the Input
         * @param {LeisElementID} ID element ID 
         * @param {EventType} type event type 
         */
        function reEventInput(ID, type, name, option) {
            ID.leisBtnConfId.input.removeEvent(type, name, option);
        }
        /**
         * changes the input size
         * @param {string} width input width - CSS unit
         * @param {LeisElementID} ID the \`input\` Id  
         */
        function setInputSize(ID, width) {
            ID.leisBtnConfId.ic.setStyleProp("width", width);

        }
        /**
         * add Event Listener to the input
         * @param {EventType} event the event type
         * @param {Function} callback  function to be called  when the event is trigged
         * @param {LeisElementID} ID the \`input\` Id  
         */
        function inputOn(ID, event, callback, name, option) {
            ID.leisBtnConfId.input.addEvent(event, callback, name, option);
        }
        /**
         * adds new \`Input\`element with the given Label text
         * @param {string} lbl text to be displayed 
         * @param {BaseElement} parent parent 
         * @returns {LeisElementID} 
         */
        function addNewInput(lbl, value, parent, option, trns) {
            if (!option) option = {};
            const l = obj\$1.bindFunc(addInput, this);
            return l(lbl, value, this.type, this.radioName, parent, option.attr, trns)
        }

        /**
         * 
         * @param {"active"|"disable"} event the event  
         * @param {Function} callback callback
         * @param {LeisElementID} ID the \`input\` Id 
         */
        function inputOnce(ID, event, callback) {
            if (event === "active") { ID.leisBtnConfId.input.addData.event.active.push(callback); }
            if (event === "disable") { ID.leisBtnConfId.input.addData.event.disable.push(callback); }
        }
        /**
         * leistrap \`Radio\` componenet
         * @param {BaseElement} parent 
         * 
         */
        function BtnRadio(parent) {
            const main = leistrap.Div({ addData: { inputs: [] }, parent });
            const radioName = generateId\$1(2, 9);
            leis\$1.addClassList(main, "leis-card-radioBtns-container");
            const methods = setMTD();
            methods.type = "radio";
            methods.className = "leis-radioBtns-card";
            methods.inputClassName = "leis-radioBtn";
            methods.radioName = radioName;
            methods.main = main;
            methods.render = function () { return main.render() };
            return methods
        }

        // checkbox component

        /***
        * lestrap \`CheckBox\` component 
        */
        function checkBox(parent) {
            const main = leistrap.Div({ addData: { inputs: [] }, parent });
            leis\$1.addClassList(main, "leis-card-checkboxBtns-container");
            const methods = setMTD();
            methods.type = "checkbox";
            methods.className = "leis-checkboxBtns-card";
            methods.inputClassName = "leis-checkboxtBtn";
            methods.main = main;
            methods.render = function () { return main.render() };
            return methods
        }

        // switch

        function switchBox(parent) {
            const main = leistrap.Div({ addData: { inputs: [] }, parent });
            leis\$1.addClassList(main, "leis-card-switchboxBtns-container");
            const methods = setMTD();
            methods.type = "checkbox";
            methods.className = "leis-switchboxBtns-card";
            methods.inputClassName = "leis-switchboxtBtn";
            methods.main = main;
            methods.render = function () { return main.render() };
            return methods
        }
        // textbox

        function txtInputs(parent, m, type, ic, clN, ipCl) {
            const main = leistrap.Div({ addData: { inputs: [] }, parent });
            leis\$1.addClassList(main, m);
            const methods = setTMINP();
            methods.type = type;
            methods.ic = ic;
            methods.className = clN;
            methods.inputClassName = ipCl;
            methods.main = main;
            methods.render = function () { return main.render() };
            return methods
        }
        function textBox(parent) {
            return txtInputs(parent, ...initTxtInput("text"))
        }

        function passWordBox(parent) {
            return txtInputs(parent, ...initTxtInput("password"))
        }

        function emailBox(parent) {
            return txtInputs(parent, ...initTxtInput("email"))
        }
        function initTxtInput(type) {
            return [
                "leis-textboxinput-container",
                type,
                "leis-textbox-container",
                "leis-textbox-card",
                "leis-textinput"]
        }

        class Textarea extends BaseElement { }
        class Input extends BaseElement {
            #isComp = false
            /**
             * set the new value to the input
             * @param {string} val 
             */
            setValue(val) { this._conf.value = val; }
            /**
             * gets the input value
             */
            getValue() { return this._conf.value }
            /**
             * 
             * leistrap \`Radio Buttons\` component
             */
            getRadio() {
                if (!this.#isComp) {
                    this.#isComp = true; this.destroy();
                } return BtnRadio(this.parent)
            }
            /**
             * 
             * leistrap \`CheckBox Buttons\` component
             */
            getCheckBox() {
                if (!this.#isComp) {
                    this.#isComp = true; this.destroy();
                } return checkBox(this.parent)
            }
            /**
             * leistrap \`TextBox\` component
             */
            getTextBox() {
                if (!this.#isComp) {
                    this.#isComp = true; this.destroy();
                } return textBox(this.parent)
            }
            /**
             * leistrap \`Switch box\` component
             */
            getSwitchBox() {
                if (!this.#isComp) {
                    this.#isComp = true; this.destroy();
                } return switchBox(this.parent)
            }
            /**
             * leistrap password widget
             */
            getPassWordBox() {
                if (!this.#isComp) {
                    this.#isComp = true;
                    this.destroy();
                } return passWordBox(this.parent)
            }
            /**
             * leistrap password widget
             */
            getEmailBox() {
                if (!this.#isComp) {
                    this.#isComp = true; this.destroy();
                } return emailBox(this.parent)
            }
        }

        // leisTable component
        /**
         * leistrap \`TableCell\` component definition
         */
        class TableCell {
            #props = { rowspan: 1, colspan: 1 }
            constructor(element, column) {
                this.cell = element;
                this.column = column;
            }
            /**
             * add content
             * @param {BaseElement} element 
             */
            add(element) { this.cell.add(element); }
            remove(element) { this.cell.remove(element); }
            removeAll() { this.cell.removeAll(); }
            addAttr(name, value) { this.cell.addAttr(name, value); }
            addClass(value) { this.cell.addClass(value); }
            addEvent(event, callback, option) { this.cell.addEvent(event, callback, option); }
            removeClass(token) { this.cell.removeClass(token); }
            toggleClass(value) { this.cell.toggleClass(value); }
            getText() { return this.cell.getText() }
            setText(value) { this.cell.setText(value); }
            destroy() { this.cell.destroy(); }

            spanCol(num) {
                this.cell.spanCol(num);
                tableOpera.adaptTableCol(this.cell, this.cell.lsParent, this, num);
                this.#props.colspan = num;
                return this
            }
            setStyle(cssValues) { this.cell.setStyle(cssValues); return this }

            spanRow(num) {
                const r = () => tableOpera.spanRow(this.cell, num);
                const _rem = w => { w.destroy(); };
                const pos = leis\$1.getElementPosition(this.cell, this.column.column);
                let [items, _c] = [[], 1];

                this.column.column.forEach((item, i) => {
                    if (i > pos) { _c++; obj\$1.arrAddWhen(items, item, _c, num); }
                });

                items.forEach(data => {
                    let posi = leis\$1.getElementPosition(data, data.lsParent.content);
                    data.lsParent.content.forEach((cell, i) => {
                        if (i >= posi) { obj\$1.arrAddWhen(false, cell, i, this.#props.colspan, _rem); }
                    });
                });
                obj\$1.isEmpty(items) ? leis\$1.addPW(true, this.cell, () => {
                    obj\$1.after(200, () => { this.spanRow(num); });
                }, this.cell.getPropWait()) : r();
            }
            /**
             * sapn cell
             * @param {number} column the number  of colspan  
             * @param {number} row  the number of rowspan 
             */
            span(column = 1, row = 1) {
                this.#props.colspan = column;
                this.#props.rowspan = row;
                this.spanCol(column);
                this.spanRow(row);
            }
        }

        /**
         * leistrp \`ColumunTable\` component definition
         */
        class ColumnTable {
            #heading
            #table
            constructor(column, heading, table) {
                this.column = column;
                this.#heading = heading;
                this.#table = table;
            }
            /**
             * update widget style
             * @param {string} cssValues css style 
             */
            setStyle(cssValues) { tableOpera.forEachCol(this.column, (item) => { item.setStyle(cssValues); }); }
            /**
             * adds className for Each column element
             * @param {string} name className 
             */
            addClass(name) { tableOpera.forEachCol(this.column, (item => { item.addClass(name); })); }
            /**
             * removes \`token className\` for Each column element
             * @param {string} token className 
             */
            removeClass(token) { tableOpera.forEachCol(this.column, (item => { item.removeClass(token); })); }
            toggleClass(name) { tableOpera.forEachCol(this.column, (item => { item.toggleClass(name); })); }
            getAttr(name) { tableOpera.forEachCol(this.column, (item => { item.getAttr(name); })); }
            setText(value) { tableOpera.forEachCol(this.column, (item => { item.setText(value); })); }
            /**
             * removes the current column
             */
            drop() {
                tableOpera.dropColumn(this.column, this.#heading);
                this.#table.columnCount -= 1; console.log(this.#table.columnCount);
            }
        }
        /**
         * leistrap quick \`Table componenet\` design helps you to create a table quickly
         */
        class LeisTable {
            #table;
            #Tcontent
            #prop
            #isInit
            /**
             * leistrap \`quick table \`widget
             * @param {BaseElement} parent table parent 
             */
            constructor(parent, NT) {
                this.parent = parent;
                this.MainT = leistrap.Card({ parent });
                this.point = this.MainT;
                this.#table = !NT ? leistrap.Table({ parent: this.MainT }) : leistrap.Div({ parent: this.MainT });
                this.#isInit = false;
                leis\$1.addClassList(this.MainT, !NT ? "leis-table-container" : NT.cdCls);
                leis\$1.addClassList(this.#table, !NT ? "leis-table" : NT.tablCls);

            }
            /**
             * create a quick table by enumerating the number of \`columns\` and \`rows\`
             * @param {number} cols columns number
             * @param {number} rows the number of rows to be inserted  
             */
            insertTable(cols, rows, option) {
                if (!option) {
                    option = {
                        "cell": { elem: leistrap.Td, cls: "leis-table-data" },
                        "heading": { elem: leistrap.Th, cls: "leis-table-heading" },
                        "row": { elem: leistrap.Tr, cls: "leis-table-row" },
                        "header": { elem: leistrap.THead, cls: "leis-table-head" },
                        "body": { elem: leistrap.Tbody, cls: "leis-table-body" }

                    };
                }
                if (this.#isInit) { throw new Error("tabel is already created") }
                if (!this.#isInit) {
                    const dfv = [];
                    this.rowCount = rows;
                    this.columnCount = cols;
                    const setCells = (num, i) => leistrap.inRange(num, 0, col => {
                        const df = leistrap.P({ text: \`data \${col + 1} x \${i + 1}\` });
                        dfv.push(df);
                        const d = option.cell.elem({ content: [df] });
                        leis\$1.addClassList(d, option.cell.cls); leis\$1.addClassList(df, "leis-table-defaultValue");
                        return d
                    });
                    const contHeader = leistrap.inRange(cols, 0, col => {
                        const df_ = leistrap.P({ text: \`heading \${col + 1}\` }); dfv.push(df_);
                        const t = option.heading.elem({ content: [df_] }); leis\$1.addClassList(t, option.heading.cls);
                        leis\$1.addClassList(df_, "leis-table-defaultValue"); return t
                    });
                    const rowsCount = leistrap.inRange(rows, 0, col => {
                        const tr = option.row.elem({ content: setCells(cols, col) });
                        leis\$1.addClassList(tr, option.row.cls); return tr
                    });

                    const header = option.header.elem({ parent: this.#table, content: contHeader });
                    const bodyTable = option.body.elem({ parent: this.#table, content: rowsCount });
                    this.#Tcontent = bodyTable;
                    this.#prop = { header, bodyTable, count: 0 };
                    leis\$1.addClassList(header, option.header.cls);
                    leis\$1.addClassList(bodyTable, option.body.cls);
                    this.clear = function () { obj\$1.tryCode(() => { dfv.forEach(itm => itm.destroy()); }); };

                    this.addRow = function (num, data) {
                        if (leis\$1.hasConf(this.#table)) {
                            const r = leistrap.inRange(num, 0, col => {
                                const tr = option.row.elem({ content: setCells(cols, col + this.rowCount) });
                                leis\$1.addClassList(tr, option.row.cls); return tr
                            });
                            this.#Tcontent.addElements(...r);
                            if (data) { this.insertData(data, this.rowCount + 1); this.rowCount += num; }
                        } else { leis\$1.addPW(true, this.#table, () => { this.addRow(num, data); }, this.#table.getPropWait()); }

                    };
                    this.#isInit = true;
                }
            }
            /**
             * inserts data 
             */
            insertData(data, rowCount) {
                tableOpera.insertData(data, this.#Tcontent, this.#prop, rowCount);
            }
            /**
             * get a table cell
             * @param {number} column column number
             * @param {number} row  row number
             * @returns {TableCell}
             */
            getCell(column, row) {
                return new TableCell(
                    tableOpera.getCell(
                        this.#Tcontent,
                        column,
                        row),
                    this.getColumn(column))
            }
            /**
             * gets a row
             * @returns {Tr}
             */
            getRow(num) { return tableOpera.getRow(this.#Tcontent, num) }
            getColumn(num) {
                return new ColumnTable(tableOpera.getColumn(
                    this.#Tcontent,
                    num,
                    this.#prop.headingList),
                    this.#prop.header.content[num - 1], this)
            }
            /**
             * config the heading
             * @param {string[]} headingList Heading list 
             */
            setHeading(headingList) {
                tableOpera.setHeading(this.#prop.header, headingList);
                this.#prop.headingList = headingList;
            }
            update(row, data) {
                if (data) {
                    data.forEach((d, i) => {
                        if (d.text) {
                            const l = this.getCell(i + 1, row);
                            l.setText(d.text);
                        }
                        if (d.widget) {
                            const l = this.getCell(i + 1, row);
                            l.removeAll();
                            l.add(d.widget);
                        }
                    });
                }
            }
            setSize(width, height) {
                if (width) {
                    this.MainT.setStyleProp("width", width);
                }
                if (height) {
                    this.MainT.setStyleProp("height", height);
                }
            }
            /**
             * add row
             * @param {number} num 
             * @param {[]} data 
             */
            addRow(num, data) { throw new Error("table not created") }
            /**
             * romove the default value
             */
            clear() { throw new Error("table not created") }
            /**
             * adds a new class name to the table
             */
            addClass(name) { if (name) { this.#table.addClass(name); } }
        }

        /**
        * leistrap.Table \`Element\` | \`Component\` definition
        */
        class Table extends BaseElement {
            getTable() { return LeisTable }
        }
        class Thead extends BaseElement { }
        class Th extends BaseElement { }
        class Tr extends BaseElement { }
        class Tbody extends BaseElement { }
        /**
        * leistrap.Td element definition
        */
        class Td extends BaseElement {
            spanCol(num) { tableOpera.spanCol(this, num); }
            spanRow(num) { tableOpera.spanRow(this, num); }
        }
        class Tfoot extends BaseElement { }

        class Heading extends BaseElement { }

        class Style extends BaseElement { }

        /**
        * leistrap.TapPage component definition
        * 
        */
        class TabPage {
            /*
            this private property saves all Links and their content
            and other properties that are privates
            */
            #prop = {}
            /**
             * @param {BaseElement[]} link 
             * @param {BaseElement[]} content,
             * @param {BaseElement} parent 
             */
            constructor(
                /**
                 * add a link to toggle a content 
                 */
                link,
                /**
                 * add the content to be show when the user click the link widget
                 */
                content,

                /**
                 * parent widget
                 */
                parent,
                attr,
                contentClass,
                useContentParent,
                concatLink
            ) {

                this.parent = parent;
                this.link = link || [];
                this.content = content || [];
                this.attr = attr;
                this.contentClass = contentClass;
                this.useContentParent = useContentParent;
                this.concatLink = concatLink;
                this.#setTab();

            }
            #setTab() {
                let __spc__ = 32;
                const [...cpy] = this.link;
                if (typeof this.content === "object" && typeof this.content.push === "function") {
                    this.concatLink ? this.link = this.link.concat(this.concatLink) : undefined;
                    const _ei = generateId\$1(1, 4);
                    const __iConfig = generateId\$1(1, 4);
                    const __items = this.content;
                    const __links = this.link;

                    this.props = { _ei, __iConfig, widgtes: { __items, __links } };

                    this.content.forEach((content, index) => {
                        let _id = generateId\$1(1, 5);
                        if (typeof this.link[index] !== "undefined") {
                            checkLinkN(this.#prop, this.link[index]);
                            content.attr ? content.attr.className ? content.attr.className += \`\${String.fromCharCode(__spc__)}leis-tab-content\${String.fromCharCode(__spc__)}\${__iConfig}\` : content.attr.className = \`leis-tab-content\${String.fromCharCode(__spc__)}\${__iConfig}\` : content.attr.className = \`leis-tab-content\${String.fromCharCode(__spc__)}\${__iConfig}\`;
                            content.attr ? content.attr.id ? content.attr.id = _id : content.attr.id = _id : content.attr.id = _id;
                            this.link[index].attr ? this.link[index].attr.className ? this.link[index].attr.className += \`\${String.fromCharCode(__spc__)}leis-tabs-btn\${String.fromCharCode(__spc__)}\${_ei}Btn \` : this.link[index].attr.className = \`leis-tabs-btn\${String.fromCharCode(__spc__)}\${_ei}Btn \` : this.link[index].attr.className = \`leis-tabs-btn\${String.fromCharCode(__spc__)}\${_ei}Btn \`;
                            this.link[index].leisDataTab = { "name": "data-leis-tab", "value": \`\${_id} \${__iConfig} \${_ei}Btn\` };

                            /*
                            get link name for getting  the id if we want to remove the link
                            and its content.
                            if there is no linkName we generate a Random LinkName.
                             */
                            if (!this.link[index].linkName) { this.link[index].linkName = generateId\$1(2, 10); }
                            /*
                            save the link and its content to the pri pro
                             */
                            this.#prop[this.link[index].linkName] = { "link": this.link[index], "content": content };

                            /*
                            config the link to its content, if we want to get immediately the content link, just we
                            invoke link \`assContent\` property. vice versa to its content.  
                             */
                            this.link[index].assContent = content;
                            content.assLink = this.link[index];

                            /*
                                config the event of link  if a user clicks on a current link will show the current 
                                link content
                             */
                            this.link[index].eventType = "click";
                            this.link[index].eventOnce = function () {
                                __items.forEach(data => { checkPoint(data, it => { it.hide(); it.removeClass("active"); }); });
                                __links.forEach(data => data.removeClass("active"));
                                checkPoint(content, c => { c.addClass("active"); c.show(); });
                                __links[index].addClass("active");
                            };
                        }
                        /*
                          a link must have a content if there is no content  an error will be thrown 
                         */
                        else { throw new Error("miss a tabLink or tabContent, verify if you used array") }
                    });
                }
                else { throw new Error("can only read a type of array") }

                const _parent_ = leistrap.Card({
                    attr: { className: "leis-maintab" },
                    parent: this.parent
                });

                const _tabBtn = leistrap.Card({
                    attr: { className: \`leis-tabs-card \${this.attr ? this.attr.className ? this.attr.className.join(' ') : "" : ""}\` },
                    parent: _parent_,
                    content: cpy,
                });

                const _tabContent_ = leistrap.Card({
                    attr: { className: \`leis-mainContentTab \${this.contentClass ? this.contentClass.join(" ") : ""}\` },
                    parent: this.useContentParent ? this.useContentParent : _parent_,
                    content: this.content
                });

                /**
                 * the mainTab contains all children like \`tabLinks\`, \`tabContents\` and lot more
                 */
                this.mainTab = _parent_;
                this.point = _parent_;
                this.__links__ = _tabBtn;
                this.__contents__ = _tabContent_;
                return _parent_

            }

            /**
             * add a new tab
             * @param {BaseElement} link  - the link to be desplayed
             * @param {BaseElement} tabContent - the content to be desplayed when 
             * the user clicks on the link associated (\`tabContent\`)
             * @param {boolean} [externalLink=false] if you want to use an external link set the property \`true\` 
             */

            addTab(link, tabContent, externalLink = false, stp) {
                checkLinkN(this.#prop, link);
                tabContent.attr ? tabContent.attr.className ? tabContent.attr.className += \`\${String.fromCharCode(__spc__)}leis-tab-content\${String.fromCharCode(__spc__)}\${this.props.__iConfig}\` : tabContent.attr.className = \`leis-tab-content\${String.fromCharCode(__spc__)}\${this.props.__iConfig}\` : tabContent.attr.className = \`leis-tab-content\${String.fromCharCode(__spc__)}\${this.props.__iConfig}\`;
                const _idf = generateId\$1(1, 5);
                tabContent.attr ? tabContent.attr.id ? tabContent.attr.id = _idf : tabContent.attr.id = _idf : tabContent.attr.id = _idf;
                link.attr ? link.attr.className ? link.attr.className += \`\${String.fromCharCode(__spc__)}leis-tabs-btn\${String.fromCharCode(__spc__)}\${this.props._ei}Btn \` : link.attr.className = \`leis-tabs-btn\${String.fromCharCode(__spc__)}\${this.props._ei}Btn \` : link.attr.className = \`leis-tabs-btn\${String.fromCharCode(__spc__)}\${this.props._ei}Btn \`;
                link.leisDataTab = { "name": "data-leis-tab", "value": \`\${_idf} \${this.props.__iConfig} \${this.props._ei}Btn\` };

                /*
                get link name for getting  the id if we want to remove the link
                and its content.
                if there is no linkName we generate a Random LinkName.
                */

                if (!link.linkName) { link.linkName = generateId\$1(2, 4); }
                /*
                save the link and its content to the pri pro
                 */
                this.#prop[link.linkName] = { "link": link, "content": tabContent };

                /*
                config the link to its content, if we want to get immediately the content link, just we
                invoke link \`assContent\` property. vice versa to its content.  
                */

                link.assContent = tabContent;
                tabContent.assLink = link;

                /*
                config the event of link  if a user clicks on a current link will show the current 
                link content
                 */


                const o = this.props.widgtes;
                link.addEvent("click", function (e) {
                    if (stp) { e.stopPropagation(); }
                    o.__items.forEach(data => { data.hide(); data.removeClass("active"); });
                    o.__links.forEach(data => data.removeClass("active"));

                    tabContent.addClass("active");
                    tabContent.show();
                    link.addClass("active");
                });
                /*
                    verify if  exeternal link is used
                */
                if (!externalLink) { this.__links__.add(link); }
                this.__contents__.add(tabContent);
                this.content.push(tabContent);
                this.link.push(link);
            }
            /**
             * removes the link with its content
             * @param {string} linkName link name 
             */
            removeLink(linkName) {
                if (leis\$1.hasConf(this.point)) {
                    if (linkName && obj\$1.has(linkName, this.#prop)) {
                        const l = this.#prop[linkName];
                        l.link.lsParent.remove(l.link);
                        l.content.lsParent.remove(l.content);
                        const n = {};
                        obj\$1.copyObject(this.#prop, n, false, linkName);
                        this.#prop = n;
                    }
                } else {
                    leis\$1.addPW(true, this.point, () => {
                        this.removeLink(linkName);
                    }, this.point.getPropWait());
                }
            }

            /**
             * move the link to another element
             * @param {string} linkName link name 
             * @param {BaseElement} element element 
             */
            moveLinkTo(linkName, element) {
                if (leis\$1.hasConf(this.point)) {
                    if (obj\$1.isTypeOf(element, BaseElement) && obj\$1.has(linkName, this.#prop)) {
                        const l = this.#prop[linkName];
                        l.link.lsParent.remove(l.link);
                        element.add(l.link);
                    }
                    else { throw new Error("can only use the BaseElement or linkName not found") }
                }
                else {
                    leis\$1.addPW(true, this.point, () => {
                        this.moveLinkTo(linkName, element);
                    }, this.point.getPropWait());
                }
            }
            /**
             * adds className to the all links
             * @param {string} value className to be added  
             */
            addBtnClass(value) {
                if (leis\$1.hasConf(this.point) && value) {
                    this.link.forEach(item => {
                        if (item.state !== "removed") { item.addClass(value); }
                    });
                }
                else {
                    leis\$1.addPW(true, this.point, () => {
                        this.addBtnClass(value);
                    }, this.point.getPropWait());
                }
            }
            destroy() {
                if (leis\$1.hasConf(this.point)) {
                    obj\$1.loopObj(this.#prop, (v, k) => {
                        v.link.destroy(); v.content.destroy();
                    });
                    this.point.destroy();
                }
                else {
                    leis\$1.addPW(true, this.point, () => {
                        this.destroy();
                    }, this.point.getPropWait());
                }
            }
            invoke(linkName, ckP = true) {
                if (leis\$1.hasConf(this.point) || !ckP) {

                    if (linkName && obj\$1.has(linkName, this.#prop)) {
                        this.#prop[linkName].link.getAttr("click");
                    }
                } else {
                    leis\$1.addPW(true, this.point, () => {
                        this.invoke(linkName);
                    }, this.point.getPropWait());
                }

            }

        }

        class PageButton {
            #button
            #state = { active: false, disable: false }
            constructor(option) {
                this.#button = this.#setBtn(option);
                this.contentPage = option.contentPage;
                this.pageName = option.pageName ? option.pageName : \`Rand_\${generateId\$1(2, 5)}\`;
                Object.defineProperty(this, 'button', { value: this.#button });
            }
            /**
             * text if button has any content
             * @param {*} btn 
             */
            hasContent(option) {
                return !(!option.content)
                    && (option.content ? !obj\$1.isEmpty(option.content) :
                        !(!option.content))
            }

            #setBtn(option) {
                const o = obj\$1.copyObject(option, false, false, "parent");
                const cnt = leistrap.Div(o);
                const elem = leistrap.Div({ content: [cnt], parent: option.parent });
                leis\$1.addClassList(elem, "leis-page-legende");
                elem.btnPage = this;
                return elem
            }
            config(option) {
                this.#setConfig(option);
                this.active();
                return this.#button
            }
            active() { if (!this.#state.active) { this.#setActive(); } }
            disable() { if (this.#state.active) { this.#setDisable(); } }

            #setActive() {
                this.#button.addEvent("click", function (e) {
                    if (!this.pageConfig.parentPage) {
                        this.pageConfig.parentPage = this.lsParent.accessPage.p;
                    }
                    if (this.pageConfig.parentPage.history) {
                        this.pageConfig.parentPage.history.push(this.pageConfig.contentPage);
                        this.pageConfig.parentPage.content.forEach(item => { item.hide(); });
                        this.pageConfig.contentPage.show();
                        this.pageConfig.parentPage.page.currentPage = this.pageConfig.contentPage;
                        if (!this.lsParent.accessPage) {
                            this.lsParent.accessPage = this.pageConfig.contentPage.accessPage;
                        }
                        this.lsParent.accessPage._controler.show();
                    }
                }, "pageButtonActive");
                this.#state.active = true;
            }
            #setDisable() {
                this.#button.removeEvent("click", "pageButtonActive");
                this.#state.active = false;
            }

            #setConfig(option) {
                this.#button.pageConfig = option;
                option.parentPage.add(option.contentPage);
                option.contentPage.accessPage = option.parentPage.accessPage;

                if (obj\$1.isArray(option.contentPage.attr.className)) {
                    option.contentPage.attr.className.push("leis-page-content");
                }
                else { option.contentPage.attr.className += " leis-page-content "; }
                if (leis\$1.hasConf(option.contentPage)) {
                    option.contentPage.addClass("leis-page-content");
                }
            }
        }

        /**
        * leistrap.Page component
        */
        class Page {
            #prop = { start: false }
            /**
             * 
             * @param {BaseElement} parent parent widget 
             * @param {BaseElement[]} legend  icon or text to be displayed
             * 
             */
            constructor(
                /**
                 * the page parent
                 */
                parent,
                /**
                 * the legend or \`icon\`
                 */
                legend,
                content,

            ) {

                this.parent = parent;
                this.legend = legend ? legend : [];
                this.content = content ? content : [];
                this.point = this.#setPage();
                this.currentPage = "main";

            }
            removePage(pageName) {
                if (leis\$1.hasConf(this.point) && pageName) {
                    checkPageName(this.#prop, pageName, true);
                    const button = this.#prop[pageName].button;
                    const content = this.#prop[pageName].content;
                    button.lsParent.remove(button);
                    content.lsParent.remove(content);
                    this.#prop = obj\$1.copyObject(this.#prop, false, false, pageName);
                }
                else {
                    leis\$1.addPW(true, this.point, () => {
                        this.removePage(pageName);
                    }, this.point.getPropWait());
                }
            }

            invoke(pageName) {
                if (leis\$1.hasConf(this.point) && pageName) {
                    checkPageName(this.#prop, pageName, true);
                    this.#prop[pageName].button.getAttr("click");

                }
                else {
                    leis\$1.addPW(true, this.point, () => {
                        this.removePage(pageName);
                    }, this.point.getPropWait());
                }
            }
            #setPage() {
                const props = this.#prop;
                const page = this;
                const _mainPage_ = leistrap.Card({
                    attr: { className: "leis-mainPage" },
                    parent: this.parent
                });

                const _controler = leistrap.Button({
                    attr: { className: \`leis-btn-controler hide \` },
                    eventType: "click",
                    parent: _mainPage_,
                    eventOnce: function () {
                        this.lsParent.content.forEach(itm => itm.hide());
                        let contentPage = {};
                        let contentHistory = [];
                        this.lsParent.history.forEach(item => {
                            if (item.leisBtnConfId in contentPage === false) {
                                contentHistory.push(item);
                                contentPage[item.leisBtnConfId] = item;
                            }
                        });

                        if (contentHistory.length <= 1) {
                            this.hide();
                            this.lsParent.history = [this.lsParent.history[0]];
                            contentPage = {};
                            page.currentPage = "main";
                        } else { this.show(); contentHistory.pop(); }

                        this.lsParent.history = contentHistory;

                        var currentContent = contentHistory[contentHistory.length - 1];
                        currentContent.show();
                        page.currentPage = currentContent;
                        if (contentHistory.length == 1) { this.hide(); page.currentPage = "main"; }
                    }
                });

                leisData.PageControler = _controler;
                const _first = leistrap.Card({ content: this.content });

                const _cnt_ = leistrap.Card({
                    attr: { className: ["contentP-Default", "noBP"] },
                    content: [_first].concat(this.legend),
                    parent: _mainPage_
                });

                _cnt_.accessPage = { p: _mainPage_, _controler };
                this.mainPage = _mainPage_;
                this.home = _first;
                _mainPage_.accessPage = { p: _mainPage_, _controler };
                _mainPage_.history = [_cnt_];
                _mainPage_.page = this;

                if (typeof this.legend === "object" && typeof this.legend.push === "function") {
                    this.legend.forEach(item => { setBtn(item, this); });
                }
                else { throw new Error("the ledende property needs only the array, verify if you used an array object") }

                function setBtn(item, o, parent) {
                    if (obj\$1.isTypeOf(item, PageButton)) {

                        checkPageName(props, item);
                        const elem = item.config({
                            access: "true",
                            parentPage: _mainPage_,
                            contentPage: item.contentPage
                        });
                        props[item.pageName] = { "button": elem, "content": item.contentPage };
                        if (elem.parent === BaseElement && (!parent && !item.noP)) { o.home.add(elem); }
                        if (obj\$1.isTypeOf(parent, BaseElement)) {
                            parent.add(elem);
                        }
                    }

                    else {
                        item.pageConfig.contentPage.accessPage = { p: _mainPage_, _controler };
                        _mainPage_.add(item.pageConfig.contentPage);

                        item.pageConfig.contentPage.attr.className += \`\${String.fromCharCode(__spc__)}leis-page-content\${String.fromCharCode(__spc__)}\`;
                    }
                }
                this.addButton = (element, parent) => { setBtn(element, this, parent); };
                this.define = function (name, content) {
                    if (name && content) {
                        checkPageName(this.#prop, name, false);
                        const elem = new PageButton({ otherAttr: { type: "hidden" } });
                        const e = elem.config({
                            access: "true",
                            parentPage: _mainPage_,
                            contentPage: content
                        });
                        this.home.add(e);
                        props[name] = {
                            "button": e,
                            "content": leistrap.Div({ content: [content] }),
                            hidden: true
                        };
                    }
                };
                return _mainPage_
            }
        }

        /**
        * leistrap.Accordion component definition
        */

        class Accordion {

            /**
             * @param {BaseElement[]} AccBtn  the widget that will be displayed
             * @param {BaseElement[]} AccPanel this content to be be shown when 
             * the user clicks on the \`AccBtn\`
             * @param {BaseElement} parent 
             */
            constructor(
                /**
                 * button or other widgts
                 */
                AccBtn,
                /**
                 * the content
                 */
                AccPanel,
                /**
                 * the widget parent
                 */
                parent,
                header = undefined,
                footer = undefined,
                props = undefined,
            ) {

                this.AccBtn = AccBtn;
                this.AccPanel = AccPanel;
                this.parent = parent;
                this.accHeader = header;
                this.accFooter = footer;
                this.props = props;
                this.point = this.#setAcc();
            }

            #setAcc() {

                const MainAcc = leistrap.Card({
                    attr: {
                        className: ["leis-accordion-card"].concat(this.props ?
                            this.props.className ? this.props.className : [] : [])
                    },
                    parent: this.parent,
                    otherAttr: this.props ? this.props.otherAttr ?
                        this.props.otherAttr : undefined : undefined

                });

                if (typeof this.accHeader !== "undefined") {
                    this.accHeader.attr ? this.accHeader.attr.className ?
                        this.accHeader.attr.className += " leis-accordion-head " :
                        this.accHeader.attr.className = ["leis-accordion-head"] :
                        this.accHeader.attr = { className: ["leis-accordion-head"] };
                    MainAcc.content.push(this.accHeader);
                }
                if (typeof this.AccBtn === "object" && typeof this.AccBtn.push === "function") {

                    this.AccBtn.forEach((item, i) => {
                        item.attr ? item.attr.className ? item.attr.className += \` leis-accordion-btn \` :
                            item.attr.className = " leis-accordion-btn " :
                            item.attr.className = " leis-accordion-btn ";

                        if (typeof this.AccPanel[i] !== "undefined") {
                            this.AccPanel[i].attr ? this.AccPanel[i].attr.className ?
                                this.AccPanel[i].attr.className += \` leis-accordion-panel \` :
                                this.AccPanel[i].attr.className = " leis-accordion-panel " :
                                this.AccPanel[i].attr.className = "leis-accordion-panel";
                            item.eventType = "click";
                            const _i = this.AccPanel[i];
                            item.eventOnce = function () {
                                _i.toggleClass("active");
                                item.toggleClass("active");
                            };
                            MainAcc.content.push(item);
                            MainAcc.content.push(this.AccPanel[i]);
                        }
                        else { throw new Error("missing a pannel widget") }
                    });
                }
                else { throw new Error("the Accordion widget needs only the array, verify if you used an array object") }
                if (typeof this.accFooter !== "undefined") {
                    this.accFooter.attr ? this.accFooter.attr.className ?
                        this.accFooter.attr.className += " leis-accordion-footer " :
                        this.accFooter.attr.className = ["leis-accordion-footer"] :
                        this.accFooter.attr = { className: ["leis-accordion-footer"] };
                    MainAcc.content.push(this.accFooter);
                }
                this.MainAcc = MainAcc;
                return MainAcc
            }

            /**
             * appends the news elements in the widget
             * @param {BaseElement} accbtn thes button to be showen
             * @param {BaseElement} accpanel the content to be showen when 
             * the user clicks in the \`accpanel\`button  
             */
            addItem(accbtn, accpanel) {
                this.MainAcc.content.push(accbtn);
                accbtn.attr ? accbtn.attr.className ?
                    accbtn.attr.className += \` leis-accordion-btn \` :
                    accbtn.attr.className = " leis-accordion-btn " :
                    accbtn.attr.className = " leis-accordion-btn ";
                this.MainAcc.content.push(accpanel);
                accpanel.attr ? accpanel.attr.className ?
                    accpanel.attr.className += \` leis-accordion-panel \`
                    : accpanel.attr.className = " leis-accordion-panel " :
                    accpanel.attr.className = "leis-accordion-panel";
                accbtn.eventType = "click";
                accbtn.eventOnce = function () {
                    accpanel.toggleClass("active");
                    accbtn.toggleClass("active");
                };
                this.MainAcc.CASCADE();
            }
            destroy() { this.point.destroy(); }
            addClass(name) { this.MainAcc.addClass(name); }
            remove(element) { this.MainAcc.remove(element); }
            removeAll() { this.MainAcc.removeAll(); }
            setStyle(cssValues) { this.MainAcc.setStyle(cssValues); }
        }

        /**
        * leistrap \`GroupItem\` component groups items within 
        */
        class GroupItem {
            /**
             * 
             * @param {BaseElement} parent 
             * @param {Li[]} item 
             */
            constructor(
                /**
                 * the parent of \`groupItem\`
                 */
                parent,
                /**
                 * the items to be grouped, this required only \`Li\` widget
                 */
                item,
                attr,
                header,
            ) {

                /**
                 * the items to be grouped, this required only \`Li\` widget
                 */
                this.items = item;
                /**
                 * the items to be grouped, this required only \`Li\` widget
                 */
                this.parent = parent;
                /**
                 * attributes
                 */
                this.attr = attr;
                this.header = header;
                this.checked = null;
                this.#setG();
            }

            /**
             * add a new element
             * @param {Li} item \`Li\` element
             */
            addItem(item) {
                leis\$1.addClassList(item, 'leis-child-group');
                this.MainG.addItem(item);
            }
            removeAll() { this.MainG.removeAll(); }
            #setG() {
                const _cd = leistrap.Card({
                    parent: this.parent,
                    attr: { className: ["leis-group"] }
                });

                const MainG = leistrap.List({
                    attr: {
                        className: ["leis-list-group"].concat(
                            this.attr ? this.attr.className ? this.attr.className : [] : [])
                    },
                    parent: _cd
                });

                if (typeof this.header !== "undefined") {
                    this.header.attr ? this.header.attr.className ?
                        this.header.attr.className += \` leis-child-group leis-group-head \` :
                        this.header.attr.className = " leis-child-group leis-group-head " :
                        this.header.attr.className = "leis-child-group leis-group-head";
                    MainG.content.push(this.header);
                }

                if (typeof this.items !== "undefined"
                    && typeof this.items.push === "function") {
                    this.items.forEach(item => {
                        if (item.ElementType.toLowerCase() === "li") {
                            item.attr ? item.attr.className ?
                                item.attr.className += \` leis-child-group \` :
                                item.attr.className = " leis-child-group " :
                                item.attr.className = "leis-child-group";
                            MainG.content.push(item);
                        }
                    });
                }
                this.point = _cd;
                this.MainG = MainG;
            }
        }

        /**
             * rule widget
             * @param {string} type
             * 
             */
        function setWidget(type, element = BaseElement, elem) {
            let __none__ = "";
            let __spc__ = 32;
            /**
             * @param {options} option options
             */
            return function (option) {
                option = option ? option : {};

                if (option.eventOnce != undefined) {

                    const _RD = option.eventOnce;
                    function defaultListener(target) {
                        _RD.call(this.currentElement, target);
                    }
                    option.eventOnce = defaultListener;
                    if (option.listener) { defaultListener.prototype["name"] = option.listener; }
                }


                const _bx = new element(option);

                _bx.ElementType = type;

                const op = {
                    label: () => _bx.lblFor = option.lblFor ? option.lblFor : __none__,
                    button: () => {
                        _bx.className += \`\${String.fromCharCode(__spc__)}btn\${String.fromCharCode(__spc__)}\`;
                        _bx.otherAttr.type = "button";
                    },
                    img: () => {
                        _bx.src = option.src ? option.src : __none__;
                        _bx.alt = option.alt ? option.alt : __none__;
                    }
                };

                let e = op[elem.toLowerCase()];
                globalProp.forEach(item => {
                    _bx[item] = option[item] ? option[item] : __none__;
                });
                if (e) e();
                // check the option set via an extension
                OptionsInit.forEach(ext => ext(option, _bx));
                return _bx
            }
        }

        /**
        * leistrap \`SlideDown\` / \`carousel\` component
        */
        class SlideDown {
            #privPro = {}
            /**
             * @param {BaseElement} parent the widget parent
             * @param {[{src :string, caption:string}]} listImg   
             * the object list of image path and caption  
             */
            constructor(parent, listImg, width, height, maxHeight, minHeight) {
                this.parent = parent;
                this.listImg = listImg;
                this.width = width;
                this.height = height;
                this.maxHeight = maxHeight;
                this.minHeight = minHeight;
                this.point = this.#setS();
            }

            #setImg(listImg, MainS, dotCard, imgId, counter, stp = 0) {
                const ip = this;
                listImg.forEach((item, index) => {
                    index += stp;
                    let fade = leistrap.Card({ parent: MainS });
                    let c0 = leistrap.Card({
                        content: [
                            leistrap.Img({
                                otherAttr: {
                                    src: item.src ? item.src : "",
                                    style: \`\${this.minHeight ? \`min-height:\${this.minHeight}px\` : "auto"}\`
                                }
                            }),
                            leistrap.Card({ attr: { className: ["leis-slideshowNumTxt"] } }),
                        ],
                        attr: { className: ["leis-img-card", imgId, "fade"] },
                        parent: fade
                    });

                    MainS.addData.push(leistrap.Card({
                        text: item.caption ? item.caption : "",
                        attr: { className: ["leis-slideshow-txt"] },
                        parent: MainS,
                        otherAttr: { style: "display:none" }
                    }));

                    leistrap.Span({
                        attr: { className: ["leis-slideshow-dot"] },
                        addData: { img: c0 },
                        parent: dotCard,
                        eventType: "click",
                        eventOnce: function () {
                            dotCard.content.forEach((item, index) => {
                                item.addData.img.hide(); item.removeClass("active");
                            });
                            this.addData.img.show();
                            this.addClass("active");
                            MainS.addData.forEach(i => i.hide());
                            MainS.addData[index].show();
                            this.addData.img.content[1].setText(\`\${index + 1}/\${ip.listImg.length}\`);
                        }
                    });
                });
            }

            /**
             * add new imgs 
             * @param {[{src:BaseElement, caption:string}]} listImg 
             */

            addImg(listImg) {

                const len = this.listImg.length;
                this.listImg = this.listImg.concat(listImg);

                this.#setImg(
                    listImg,
                    this.#privPro.MainS,
                    this.#privPro.dotCard,
                    this.#privPro.imgId,
                    this.#privPro.counter,
                    len
                );
                this.#privPro.MainS.CASCADE();
                this.#privPro.dotCard.CASCADE();
            }
            #setS() {
                const imgId = generateId\$1(3, 8);
                const __MainContent__ = leistrap.Card({ parent: this.parent });
                const MainS = leistrap.Card({
                    attr: { className: ["leis-slideshow-container"] },
                    parent: __MainContent__,
                    otherAttr: {
                        style: \`width:\${this.width ? \`\${this.width}px\` : "auto"};
                 height:\${this.height ? \`\${this.height}px\` : "auto"};
                 max-height:\${this.maxHeight ? \`\${this.maxHeight}px\` :
                            "auto"}\`.replace(/\\n/g, "")
                    },
                    addData: []
                });

                let counter = 0;
                leistrap.Span({
                    autoClick: true,
                    innerHtml: "&#10094",
                    attr: { className: ["leis-slideshow-prev-btn"] },
                    parent: MainS,
                    eventType: "click",
                    eventOnce: function () {
                        counter = counter == 0 ? dotCard.content.length - 1 : counter - 1;
                        dotCard.content[counter].getAttr("click");
                    }
                });

                leistrap.Span({
                    innerHtml: "&#10095",
                    attr: { className: ["leis-slideshow-next-btn"] },
                    parent: MainS,
                    eventType: "click",
                    eventOnce: function () {
                        counter = counter == dotCard.content.length - 1 ? 0 : counter + 1;
                        dotCard.content[counter].getAttr("click");
                    }
                });

                const dotCard = leistrap.Card({
                    otherAttr: { style: "text-align:center" },
                    parent: __MainContent__
                });

                // inserting img to the main content and dotted buttons to  the dotted content

                this.listImg ? this.#setImg(this.listImg, MainS, dotCard, imgId, counter) : undefined;

                this.MainS = __MainContent__;
                this.#privPro.MainS = MainS;
                this.#privPro.imgId = imgId;
                this.#privPro.dotCard = dotCard;
                this.#privPro.imgId = imgId;
                this.#privPro.counter = counter;
                return __MainContent__
            }
        }

        /**
        * Leistrap \`DropDown\` component
        */

        class DropDown {

            /**
             * the caption widget that will contain the text 
             */
            #CaptionDisplay;
            #contentDC
            /**
             * 
             * @param {BaseElement} parent  the widget parent
             * @param {string} caption  the text to be displayed
             * @param {BaseElement[]} items the items to be inserted in the \`DropDown Container\` 
             * @param {string} btnType the type of btn color e.g \`primary\`, \`secondary\`, 
             * \`warning\` and so more... reference \`leistrap\` style sheet   
             */
            constructor(parent, caption,
                items, btnType,
                attr, useBtn,
                contentStopPropagation = false,
                btnClass) {
                this.parent = parent;
                this.caption = caption;
                this.items = items;
                this.btnType = btnType;
                this.attr = attr;
                this.useBtn = useBtn;
                this.contentStopPropagation = contentStopPropagation;
                this.btnClass = btnClass;
                this.point = this.#setD();
            }

            /**
             * 
             * @param {string} name caption name 
             */
            setCaption(name) { this.#CaptionDisplay.setText(name); }
            /**
             * 
             * @param {BaseElement} item the new Element 
             */
            addItem(item) {
                leistrap.Span({ content: [item], parent: this.#contentDC });
                this.#contentDC.CASCADE();
            }
            #setD() {
                this.#CaptionDisplay = leistrap.Span({ text: this.caption });

                const MainD = leistrap.Card({
                    attr: {
                        className: ["leis-dropdown"].concat(this.attr ?
                            this.attr.className ? this.attr.className : [] : [])
                    },
                    parent: this.parent
                });
                let _useBtn;
                if (typeof this.useBtn !== "undefined") {
                    _useBtn = leistrap.Card({
                        attr: {
                            className: ["leis-dropBtn"]
                                .concat(this.btnClass ? this.btnClass : [])
                        },
                        content: [this.useBtn],
                        eventType: "click",
                        eventOnce: function (e) {
                            e.stopPropagation();
                            leisData.lDropDown.forEach(dp => {
                                dp.Dcontent.removeClass("show");
                                dp.Btn.removeClass("activeD");
                            });
                            this.addClass("activeD");
                            Dcontent.addClass("show");
                        }
                    });
                }
                const btnD = leistrap.Button({
                    attr: {
                        className: ["leis-dropBtn leis-flex leis-row", "leis-dropBtn-"
                            + String(this.btnType ? this.btnType : "primary")]
                            .concat(this.btnClass ? this.btnClass : [])
                    },
                    eventType: "click",
                    content: [
                        this.#CaptionDisplay,
                        leistrap.Span({ otherAttr: { "class": "leis-arrow-down as" } })],
                    eventOnce: function (e) {
                        e.stopPropagation();
                        leisData.lDropDown.forEach(dp => {
                            dp.Dcontent.removeClass("show");
                            dp.Btn.removeClass("activeD");
                        });
                        this.addClass("activeD");
                        Dcontent.addClass("show");
                    }
                });

                MainD.content.push(_useBtn ? _useBtn : btnD);
                const xD = leistrap.Card({
                    attr: { className: ["leis-content"] },
                    parent: MainD
                });

                const Dcontent = leistrap.Card({
                    attr: {
                        className: [
                            "leis-dropdown-content",
                            "leis-padding-6", "leis-border-"
                            + String(this.btnType ? this.btnType : "primary")
                        ]
                    },
                    parent: xD,
                });
                const DC = leistrap.Card({
                    attr: { className: ["leis-dropdwn-content-card"] },
                    parent: Dcontent
                });

                this.#contentDC = DC;
                if (this.contentStopPropagation === true) {
                    DC.addEvent("click", function (e) { e.stopPropagation(); });
                }
                if (typeof this.items !== "undefined" && typeof this.items.push === "function") {
                    this.items.forEach(item => { DC.content.push(item); });
                }
                this.MainD = MainD;
                this.Dcontent = Dcontent;
                this.Btn = _useBtn ? _useBtn : btnD;
                this.setSize = function (w, h) {
                    if (w) { Dcontent.setStyleProp("width", w); }
                    if (h) { Dcontent.setStyleProp("height", h); }
                };
                this.addClass = function (name) { Dcontent.addClass(name); };
                this.setStyle = function (css) { Dcontent.setStyle(css); };

                return MainD
            }
            /**
             * hide the content
             */
            hideContent() { window.document.body.click(); }
            destroy() { this.point.destroy(); }
        }

        /**
        * leistrap \`TopNav\` component difinition
        */
        class TopNav {
            #position;
            #type;
            #dropDowns;
            /**
             * 
             * @param {BaseElement} parent  TopNav parent widget 
             * @param {[{name:string, href:string}]} links the links to be displayed on the topNav 
             */
            constructor(parent, links, position, type, dropDowns) {
                this.parent = parent;
                this.links = links;
                this.type = type;
                this.#position = position;
                this.#dropDowns = dropDowns;
                this.point = this.#setTop();
            }

            #setTop() {
                const MainTop = leistrap.Card({
                    parent: this.parent,
                    attr: { className: ["leis-topnav", \`\${this.type ? this.type : ""}\`] },
                });

                if (!obj\$1.isUndifend(this.links)) {
                    if (obj\$1.isArray(this.links)) {
                        const o = this.links.map(item => leistrap.Li({
                            content: [leistrap.A({ otherAttr: { href: item.href }, text: item.name })]
                        }));
                        if (this.#dropDowns) { leis\$1.topNaveDropDowns(leistrap, o, this.#dropDowns); }
                        MainTop.add(leistrap.GroupItem({ items: o }).MainG);
                    }
                }
                return MainTop
            }
        }

        /**
        * leistrap \`SideBar\` component definition
        */
        class SideBar {
            #footer;
            #header;
            #items
            /**
             * @param {BaseElement} parent parent widget 
             */
            constructor(parent, header, footer, items, collapsibles) {
                this.parent = parent;
                this.#header = header;
                this.#footer = footer;
                this.#items = items;
                this.collapsibles = collapsibles;
                this.point = this.#setSB();
            }

            #setSB() {
                const hd = leistrap.Card({ attr: { className: ["sideNavHeader"] } });
                const ft = leistrap.Card({ attr: { className: ["sideNavFooter"] } });
                const i = [];

                if (!obj\$1.isUndifend(this.#items)) {
                    let o = (_items) => {
                        var ot = [];
                        _items.forEach(item => {
                            let fl = leistrap.Li();
                            fl.addEvent("click", function () {
                                i.forEach(it => it.removeClass("sideItemActive"));
                                this.addClass("sideItemActive");
                                if (!obj\$1.isUndifend(item.action)) { item.action.call(this, this); }
                            });

                            // let verify  if the icon is clicked
                            function ic(e) { if (item.onIcon) item.onIcon(e); }
                            // verifying if the icon is set 
                            item.icon ? fl.content.push(leistrap.I({ otherAttr: { "class": item.icon }, events: { click: ic } })) : undefined;
                            // put the textContent
                            item.caption ? fl.content.push(leistrap.Span({ text: item.caption })) : undefined;
                            // verifying if the widget is required
                            item.widget ? fl.content.push(item.widget) : undefined;
                            i.push(fl);
                            ot.push(fl);

                        });
                        return ot
                    };
                    obj\$1.tryCode(() => { o(this.#items); });

                    //create the method for adding news items into the sideBar
                    this.addItems = function (_items) {
                        obj\$1.tryCode(() => {
                            o(_items).forEach(item => GL.addItem(item));
                        });
                    };

                }
                //insert all collapsible
                if (this.collapsibles) {
                    leis\$1.insertItemFlat(leistrap, i, this.collapsibles, "MainC", "colla-item");
                }

                const GL = leistrap.GroupItem({
                    items: !obj\$1.isEmpty(i) ? i : undefined,
                    attr: { className: ["links"] }
                });

                const cont = [GL.MainG];
                if (!obj\$1.isUndifend(this.#header)) { hd.add(this.#header); obj\$1.arrayInsert(0, cont, hd); }
                if (!obj\$1.isUndifend(this.#footer)) { ft.add(this.#footer); cont.push(ft); }
                const MainS = leistrap.Card({
                    attr: { className: ["leis-sideNav"] },
                    content: cont
                });
                this.setWidth = function (value) { if (value) { MainS.setStyleProp("width", value); } };
                this.addClass = function (name) { if (name) { MainS.addClass(name); } };
                this.MainS = MainS;
                Object.defineProperty(this, "allItems", { value: i });
                return MainS
            }
        }

        /**
        * leistrap \`Collapsible\` component definition
        */
        class Collapsible {
            /**
             * @param {BaseElement} parent Collapsible parent widget 
             * @param {BaseElement[]} content  content to be displayed
             * @param {string} caption caption text
             */
            constructor(parent, content, caption) {
                this.parent = parent;
                this.content = content;
                this.caption = caption;
                this.point = this.#setC();
            }
            #setC() {
                const MainC = leistrap.Card({
                    attr: {
                        className: ["leis-collapsing-container"]
                    },
                    parent: this.parent
                });
                const collaBtn = leistrap.Button({
                    text: this.caption,
                    attr: { className: ["leis-collapse-btn"] },
                    parent: MainC
                });
                collaBtn.addEvent("click", function () {
                    colla.toggleClass("callo-show");
                    this.toggleClass("colla-btn-show");
                });
                const colla = leistrap.Card({
                    attr: { className: ["leis-collapsing"] },
                    parent: MainC,
                    content: this.content
                });
                this.MainC = MainC;
                return MainC
            }
        }

        function SearchBar(option) {
            option = option ? option : {};
            obj\$1.isUndifend(option.option) ? option.option = {} : undefined;
            const s = leis\$1.setSearchBar(leistrap, option);
            return option.option.autoComplate ? setSearch(s, option) : s
        }

        function setSearch(s, option) {
            const SB = {
                point: leistrap.Card({
                    attr: { className: ["leis-autoComplate"] },
                    content: [s, leis\$1.setAutoComplation(
                        leistrap,
                        option.option.autoComplate,
                        s,
                        option.option.defaultValue,
                        option.option)]
                })
            };
            return SB
        }

        class Modal {
            #prop = initCard()
            constructor(parent) {
                this.parent = parent;
                this.point = this.#setModal();
                Object.defineProperty(this, "events", {
                    writable: false, value: { close: [], active: [] }
                });
            }
            #setModal() {
                const _modal_ = leistrap.Div({ parent: this.parent });
                const dialog = leistrap.Div({ parent: _modal_ });

                const closeBtn = leistrap.CloseBtn({});
                closeBtn.addEvent("click", function () { closeModal(); });
                const content = leistrap.Div();
                const title = leistrap.H3({ text: "modal title" });

                //closebtn
                const c = leistrap.Button({ text: "Close" }).getButton();
                c.setType("secondary");
                this.closeBtn = c;
                // the saveBtn element
                const s = leistrap.Button({ text: "Save data" }).getButton();
                s.setType("primary");
                this.saveBtn = s;
                const card = leistrap.Div({ content: [c, s] });
                const p = leistrap.P({
                    text: "Modal content goes here... add new content",
                    tooltip: { postion: 'bottom', text: "text modal example" }
                });
                this.#prop.body.add(p);
                this.#prop.footer.add(card);
                this.#prop.header.add(title);
                this.#prop.header.add(closeBtn);
                content.add(this.#prop.header);
                content.add(this.#prop.body);
                content.add(this.#prop.footer);
                dialog.add(content);
                _modal_.addEvent("click", function (e) {
                    if (e.target === this._conf) { closeModal(); }
                });

                leis\$1.addClassList(_modal_, "leis-modal-container");
                leis\$1.addClassList(dialog, "leis-modal-dialog modal-transform");
                leis\$1.addClassList(content, "leis-modal-content");
                leis\$1.addClassList(this.#prop.header, "leis-modal-header");
                leis\$1.addClassList(this.#prop.body, "leis-modal-body");
                leis\$1.addClassList(this.#prop.footer, "leis-modal-footer");
                leis\$1.addClassList(title, "leis-modal-title");
                leis\$1.addClassList(card, "leis-modal-footer-card");
                leis\$1.addClassList(p, "leis-modal-dafault");

                this.#prop.content = content;
                this.#prop.title = title;
                this.#prop.container = _modal_;
                this.#prop.p = p;
                this._modal_ = _modal_;
                this.#prop.dialog = dialog;
                Object.defineProperty(this, "props", { value: this.#prop });
                //closing a modal
                var o = this;
                function closeModal() {
                    var closed = { closable: true };
                    o.events.close.forEach((item, index) => { item(closed); });
                    if (closed.closable) _modal_.removeClass("show");
                }
                this.hide = closeModal;
                Object.defineProperty(this, "body", { writable: false, value: this.#prop.body });
                this.setEffect = function (name) { dialog.setStyleProp("animationName", \`\${name}\`); };
                this.moveTo = function (x, y) {
                    dialog.setStyleProp("top", \`\${(y * 100) / window.screen.availHeight}%\`);
                    dialog.setStyleProp("left", \`\${(x * 100) / window.screen.availWidth}%\`);
                    dialog.removeClass("modal-transform");
                    _modal_.setStyleProp("background", "inherit");
                    this.show();
                };
                return _modal_
            }

            setTitle(name) { this.#prop.title.setText(name); }
            show() {
                var active = { active: true };
                this.events.active.forEach((item, index) => { item(active); });
                if (active.active) this.#prop.container.addClass("show");
            }
            add(element) { this.#prop.body.add(element); }
            addElements(...element) { this.#prop.body.addElements(...element); }
            setSize(width, height) {
                if (width) { this.#prop.dialog.setStyleProp("width", width); } if (height) { this.#prop.dialog.setStyleProp("height", height); }
            }
            addClass(value) { if (value) { this.#prop.dialog.addClass(value); } }
            clearDefault() { this.#prop.p.destroy(); }
            clear() { this.#prop.p.destroy(); }
            destroy() { this.#prop.container.destroy(); }
            once(event, callback) {
                if (obj\$1.has(event, this.events)) this.events[event].push(callback);
            }
            removeFooter() { this.#prop.footer.destroy(); }
            removeHeader() { this.#prop.header.destroy(); }

        }

        // todo 1 event : onPressMove 

        function PressMove(elem, option) {
            if (!option) option = {};
            if (!option.target) option.target = elem;
            var events = {
                "start": "mousemove",
                "end": "mouseup",
                "init": "mousedown"
            };
            // ini  the event 
            function _init_(o) {
                option.target.addEvent(events.init, function (e) {
                    if (o.start) o.start(e);
                    checkStarting(o);
                    elem.addEvent(events.end, end, \`end\`);
                }, \`init\`);

            }

            // check  if the event is starting or not
            function checkStarting(o) {
                elem.addEvent(events.start,
                    (e) => start(e, o), "start");
            }


            // start the event
            function start(e, o) {
                if (o.listener) o.listener(e);
            }

            // end the event
            function end(e) {
                if (option.end) option.end(e);
                elem.removeEvent(events.start, "start");
                elem.removeEvent(events.end, \`end\`);
            }
            // call the init function to init the PressMove event 
            // to the main object
            _init_(option);
        }

        // creation of the main object which will contain all
        // elements, component that we'll create and then displays
        // them in  the browser

        function __main__(ws, cf) {
            const _main = ws.Div();
            _main.otherAttr = { "class": "leis-main" };
            _main._conf = cf;
            // create a new _main object
            return new class Main {
                /**
                 * leistrap PressMove Event
                 */
                onPressMove(target, listener, start, end) {
                    PressMove(_main, { listener, target, start, end });
                }
                /**
                 *  add event to the main object 
                 */
                addEvent(...args) { _main.addEvent(...args); }
                getScreen() { return cf.screen }
            }
        }

        function CloseBtn(eventType, eventOnce) {
            return this.Button({
                content: [this.Span({ innerHtml: "&times" })],
                otherAttr: { "class": "leis-btn-close" },
                eventOnce,
                eventType
            })
        }

        class Template {
            constructor(text) {
                this.text = text;

            }

            get(select = {}) {

                let list = this.text.split(" ");
                let temChange = "";
                for (var i = 0; i < list.length; i++) {
                    if (list[i].length >= 2 && list[i][0] == "%") {

                        if (select[list[i].slice(1, list[i].length)] != undefined) {
                            list[i] = select[list[i].slice(1, list[i].length)];
                        }
                    }
                }

                for (var j = 0; j < list.length; j++) {
                    if (list[j].length >= 0 && list[j][0] != "%") {
                        temChange += " " + list[j];
                    }
                }
                return temChange
            }

        }

        /**
        * leistrap \`Alert\` component definition
        */
        class Alert {
            #type
            #links
            /**
             * @param {BaseElement} parent  the alert parent widget
             * @param {string} text text to be displayed
             * @param {BtnType} type alert color type  
             */
            constructor(parent, text, type, links) {
                this.parent = parent;
                this.text = text;
                this.#type = type;
                this.#links = links;
                this.point = this.#setA();
            }

            #setA() {
                const links = new Template(this.text);
                let getLink;

                if (this.#links) {
                    const { ...cpy } = this.#links;
                    Object.keys(cpy).forEach(item => {
                        cpy[item] = \`<a href="\${cpy[item]}">\${item.replace(/_/g, " ")}</a>\`;
                    });
                    getLink = links.get(cpy);
                }
                const close = leistrap.CloseBtn("click", function () { MainA.destroy(); });
                const MainA = leistrap.Card({ parent: this.parent });
                leistrap.Card({
                    parent: MainA,
                    content: [
                        close,
                        leistrap.P({
                            innerHtml: getLink ? getLink :
                                this.text, attr: { className: ["leis-alert-text"] }
                        })],
                    attr: {
                        className: ["leis-alert-card",
                            \`\${this.#type ? \`leis-alert-\${this.#type}\` :
                            "leis-alert-primary"}\`]
                    }
                });
                this.MainA = MainA;
                return MainA
            }
        }

        /**
         * leistrap comboBox component  
         */
        class ComboBox {
            constructor(option) {
                if (!option) option = {};
                this.items = option.items;
                this.point = leistrap.Input().getTextBox();
                this.point.autoComplete = { autoComplete: this.items };
                Object.defineProperty(this, "combo",
                    { writable: false, value: this.point.add() });
                let counter = obj\$1.countArray(this.items, 0);
                this.combo.leisBtnConfId.input.bind("<arrow>", function (o) {
                    o.up = () => { this.setValue(counter()); };
                }, "choice");

                this.combo.leisBtnConfId.input.bind("<return>", function () { console.log(this); });
            }

        }

        function selectElement({
            byId = false,
            id = new String,
            byClassName = false,
            className = new String,
            allClassName = false,
            byElement = false,
            htmlElement = new Document,
            event = function eventMethed(
                target = undefined,
                elem = document.getElementById("gggfgfgkhfk@!jdhhks22222252674€dkfhjhggffsdlohvgfdk=hggd")) { },
            evt = new String,
            getElm = {

                byId: false,
                IdValue: new String,
                byClassName: false,
                classValue: new String

            },
            pre = function Prototype({
                currentElement = new Document,
                elemAss = new Document
            }) { },
            content = new Array,
        }
        ) {
            let kgv;
            try {
                kgv = getElm.byId ? document.querySelector(\`#\${getElm.IdValue ? getElm.IdValue : "ffff5256gshs"}\`)
                    : getElm.byClassName ? document.querySelector(\`.\${getElm.classValue ? getElm.classValue : ""}\`)
                        : undefined;
            } catch (error) {

            }
            byId ? document.querySelector(\`#\${id ? id : null}\`)
                .addEventListener(\`\${evt ? evt : ""}\`, function (e) { event(e, kgv); }) :
                byElement ? htmlElement.addEventListener(\`\${evt ? evt : ""}\`, function (e) { event(e, kgv); }) :
                    byClassName ? document.querySelector(\`.\${className ? className : null}\`)
                        .addEventListener(\`\${evt ? evt : ""}\`, function (e) { event(e, kgv); }) : undefined;

            const cur = byId ? document.querySelector(\`#\${id ? id : null}\`) : byElement ? htmlElement :
                byClassName ? document.querySelector(\`.\${className ? className : null}\`) : undefined;
            pre({
                currentElement: cur,
                elemAss: kgv
            });

            content ? (
                content.forEach(item => {
                    if (cur) {
                        item.parent = cur;
                        if (item.point) {
                            item.point.parent = cur;
                            cur.append(item.point.render());
                        }
                        else {
                            cur.append(item.render());
                            item.parent = cur;
                        }

                    }
                })
            ) : content;
            return cur
        }


        function groupController({
            byClassName = false,
            classValue = new String,
            byChildren = false,
            parent = new Document
        }) {
            const cl = byClassName ? document.querySelectorAll(\`.\${classValue ? classValue : ""}\`) : byChildren ? parent.children : undefined;
            const AllCl = [];
            if (cl !== undefined) {
                for (let i = 0; i < cl.length; i++) { AllCl.push(cl[i]); }
            }
            return AllCl
        }

        class Layout {
            constructor(parent, content, cls) {
                this.point = leistrap.Div({ parent, content });
                leis\$1.addClassList(this.point, cls[0]);
                this.#setHB(content, cls[1]);
            }

            #setHB(list, cls) {
                list.forEach(item => {
                    item.addClass(cls);
                    item.setStyleProp("flex", \`\${list.length}\`);
                });
            }
            #setItemFlex(index, prop, value) {
                if (this.point.content[index]) {
                    this.point.content[index].setStyleProp(prop, value);
                }
            }
            setItemGrow(index, n) { this.#setItemFlex(index, "flexGrow", n); };
            setItemShrink(index, n) { this.#setItemFlex(index, "flexShrink", n); };
            setItemBasis(index, value) { this.#setItemFlex(index, "flexBasis", value); };
            setItemOrder(index, n) { this.#setItemFlex(index, "flexOrder", n); };
        }

        Layout.HBoxLayout = function (parent, content) {
            return new this(parent, content, [
                "leis-flex leis-row leis-layout",
                "leis-hbox-item"])
        };

        Layout.VBoxLayout = function (parent, content) {
            return new this(parent, content, [
                "leis-flex leis-coluùn leis-layout",
                "leis-vbox-item"])
        };

        var setting = {
            theme: "light",
            Core: leistrap
        };

        function Head(widget) {
            const h = widget();
            h._config = window.document.head;
            return h
        }

        /**
         * class definition
         */


        const Lesistap_pages = {};

        const extensionOption = {
            BaseElement, leis: leis\$1, obj: obj\$1, leisDOM: leisDOM\$1,
            generateId: generateId\$1, selectElement,
            groupController,
            ExtensionInit, ExtensionRender,
            OptionsInit, useState
        };
        function leistrap(conf) {
            if (!conf) conf = {};
            obj\$1.copyObject(conf, setting, true);
            if (conf.plugin) conf.plugin.forEach(item => { obj\$1.tryCode(() => item(setting)); });

        }

        leistrap.prototype.setting = setting;
        Object.defineProperty(leistrap, "extension", { writable: false, value: {} });
        Object.defineProperty(leistrap, "event", { writable: false, value: _EventEmitter() });

        /**
        * leistrap \`Button\` Element | Component
        * @param {options} option button options
        * @returns {Button}
        */
        leistrap.Button = option => {
            const button = setWidget("button", Button, "Button");
            return button(option)
        };
        /**
        * leistrap \`Div\` | \`Card component\`
        * @param {options}  option options
        * @returns { Card} 
        */
        leistrap.Card = option => {
            const card = setWidget("div", Card, "div");
            return card(option)
        };
        /**
        * leistrap \`Label\` Element | component 
        * @param {options} option Label options
        * @returns {Label}
        */
        leistrap.Label = option => {
            const label = setWidget("label", Label, "label");
            return label(option)
        };
        /**
        * leistrap  \`P\` | \`paragraph\` component
        * @param {options} option  options
        * @returns {Paragraph}
        */
        leistrap.Paragraph = option => {
            const p = setWidget("p", Paragraph, "paragraph");
            return p(option)
        };
        /**
        * leistrap \`P\` Element
        * @param {options} option  options
        * @returns {P} 
        */
        leistrap.P = option => {
            const p = setWidget("p", Paragraph, "paragraph");
            return p(option)
        };
        /**
        * leistrap \`Img \`Element
        * @param {options} option options
        * @returns {Img}
        */
        leistrap.Img = option => {
            const img = setWidget("img", Img, "img");
            return img(option)
        };
        /**
        * leistrap \`Div\` Element
        * @param {options} option options
        * @returns {Div}
        */
        leistrap.Div = option => {
            const div = setWidget("div", Div, "div");
            return div(option)
        };
        /**
        * List widget uses the ul or ol html elements
        * @param {options} option List options
        * @returns {List}
        */
        leistrap.List = option => {
            const ul = setWidget("ul", List, 'ul');
            return ul(option)
        };
        /**
         * Ol widget uses the Ol  html elements
         * @param {options} option Ol widget options
         * @returns {List}
         */
        leistrap.Ol = option => {
            const ol = setWidget("ol", List, "ol");
            return ol(option)
        };
        /**
        * Ul widget uses the Ul  html elements
        * @param {options} option Ul widget options
        * @returns {List}
        */
        leistrap.Ul = option => {
            const ul = setWidget("ul", List);
            return ul(option)
        };
        /**
        * List item Element
        * @param {options} option list item options
        * @returns {Li} 
        */
        leistrap.Li = option => {
            const li = setWidget("li", Li, "li");
            return li(option)
        };
        /**
        * the \`Span\` Element 
        * @param {options} option  span options
        * @returns {Span}
        */
        leistrap.Span = option => {
            const span = setWidget("span", Span, "span");
            return span(option)
        };
        /**
        * Italic element
        */
        leistrap.I = option => {
            const i = setWidget("i", I, "i");
            return i(option)
        };
        leistrap.Link = option => {
            const link = setWidget("link", Link, "link");
            return link(option)
        };
        /**
        * the html \`a\` Element
        * @param {options} option options
        * @returns {A}
        */
        leistrap.A = option => {
            const a = setWidget("a", A, "a");
            return a(option)
        };
        /**
        * \`textarea\` element
        * @param {options} option textarea options
        * @returns {Textarea} 
         */
        leistrap.Textarea = option => {
            const textarea = setWidget("textarea", Textarea, "textarea");
            return textarea(option)
        };
        /**
        * Table \`Element\` | \`Component\`
        * @param {options} option table options
        * @returns {Table}
        */
        leistrap.Table = option => {
            const table = setWidget("table", Table, "table");
            return table(option)
        };
        /**
        * \`THead\` element
        * @param {options} option options
        * @returns {THead}
        */
        leistrap.THead = option => {
            const thed = setWidget("thead", Thead, "thead");
            return thed(option)
        };
        /**
         * \`Th\` element
         * @param {options} option options
         * @returns {Th}
         */
        leistrap.Th = option => {
            const th = setWidget("th", Th, "th");
            return th(option)
        };
        /**
         * \`Tbody\` element
         * @param {options} option Tbody options
         * @returns {Tbody}
         */
        leistrap.Tbody = option => {
            const tbody = setWidget("tbody", Tbody, "tbody");
            return tbody(option)
        };
        /**
         * \`Tr\` element
         * @param {options} option options
         * @returns {Tr}
         */
        leistrap.Tr = option => {
            const tr = setWidget("tr", Tr, "tr");
            return tr(option)
        };
        /**
         * \`Td\` element
         * @param {options} option options
         * @returns {Td}
         */
        leistrap.Td = option => {
            const td = setWidget("td", Td, "td");
            return td(option)
        };
        /**
         * \`Tfoot\` element
         * @param {options} option Tfoot options
         * @returns {Tfoot}
         */
        leistrap.Tfoot = option => {
            const tfoot = setWidget("tfoot", Tfoot, "tfoot");
            return tfoot(option)
        };
        /**
        *leistrap \`Script\` element
        */
        leistrap.Script = setWidget("script", Script, "script");
        /**
        * input element, use \`otherAttr\` property to change the input type
        * @param {options} option Input options
        * @returns {Input} 
        */
        leistrap.Input = option => {
            const input = setWidget("input", Input, "input");
            return input(option)
        };
        /**
        * \`Heading 1\`  element 
        */
        leistrap.H1 = setWidget("h1", Heading, "h1");
        /**
         * \`Heading 2\`  element 
         */
        leistrap.H2 = setWidget("h2", Heading, "h2");
        /**
         * \`Heading 3\`  element 
         */
        leistrap.H3 = setWidget("h3", Heading, "h3");
        /**
         * \`Heading 4\`  element 
         */
        leistrap.H4 = setWidget("h4", Heading, "h4");
        /**
         * \`Heading 5\`  element 
         */
        leistrap.H5 = setWidget("h5", Heading, "h5");
        /**
         * \`Heading 6\`  element 
         */
        leistrap.H6 = setWidget("h6", Heading, "h6");

        leistrap.Style = setWidget("style", Style, "style");
        leistrap.Head = Head(leistrap.Div);
        leistrap.addStyle = function (css) { leis\$1.addCssFile(document, this.Style({ text: css })); };
        leistrap.inRange = function (num, st = 0, callback) {
            let ox = [];
            for (let x = st; x < num; x++) { ox.push(x); }
            ox = ox.map(callback);
            return ox
        };
        /**
        * the tabpage widget
        * @typedef {{
        * tabLink :BaseElement[],
        * tabContent:BaseElement[],
        * parent:BaseElement, attr:{},
        * contentClass:string[], 
        * useContentParent:BaseElement, 
        * concatLink :BaseElement[] }}tabPageOption
        * @param {tabPageOption} option 
        * @returns {TabPage} 
        */

        leistrap.TabPage = option => {
            if (!option) { option = {}; } return new TabPage(
                option.tabLink,
                option.tabContent,
                option.parent,
                option.attr,
                option.contentClass,
                option.useContentParent,
                option.concatLink
            )
        };
        /**
        * page button
        * @param {options} option 
        * @returns {PageButton}
        */
        leistrap.pageButton = (option = {}) => new PageButton(option);

        /**
        * the page component
        * @typedef {{
        * parent :BaseElement, 
        * legend :PageLegend, 
        * content:BaseElement[]}} pageOptions
        * @param {pageOptions} option 
        * @returns {Page} 
        */
        leistrap.Page = option => new Page(
            option.parent,
            option.legend,
            option.content
        );

        /**
        * the Accordion component
        * @typedef {{
        * accBtn:BaseElement[],
        * accPanel:BaseElement[],
        * parent:BaseElement,
        * accHeader:BaseElement,
        * accFooter:BaseElement, 
        * props:attr}} accOptions
        * @param {accOptions} option 
        * @returns {Accordion} 
        */
        leistrap.Accordion = option => new Accordion(
            option.accBtn,
            option.accPanel,
            option.parent,
            option.accHeader,
            option.accFooter,
            option.props
        );

        /**
        * the \`GroupItem\` component
        * @typedef {{
        * parent ?: BaseElement, 
        * items?:Li[], 
        * attr ?:{className? :string,id ? :string},
        * header ? :BaseElement}}optionsGroup
        * @param {optionsGroup} option 
        * @returns {GroupItem} 
        */
        leistrap.GroupItem = option => new GroupItem(
            option.parent,
            option.items,
            option.attr,
            option.header
        );

        /**
        * leistrap  GroupItem \`left image\` widget
        * @param {string} path the img \`path\`
        * @returns {BaseElement}
        */
        leistrap.GILeftImg = path => leistrap.Card({
            attr: { className: ["leis-img-group-left"] },
            content: [leistrap.Img({ otherAttr: { src: path } })]
        });
        /**
         * leistrap  GroupItem \`Text\` widget
         * @param {string} txt  the text to be displayed
         * @returns {BaseElement}
         */
        leistrap.GIText = txt => leistrap.Paragraph({
            attr: { className: ["leis-group-txt"] },
            text: txt
        });
        /**
        * add the page extence 
        * @param {string} name 
        * @param {Page} page 
        */
        leistrap.setPage = function (name, page) { Lesistap_pages[name] = page; };
        leistrap.getPage = (name) => Lesistap_pages[name];
        leistrap.lorem = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum distinctio molestias culpa dolores quibusdam doloribus iure quis. Facere consequatur rerum quidem totam optio est animi. Voluptatem temporibus blanditiis officia enim!";
        leistrap.MLorem = function (n = 1) {
            let i = "";
            for (let _i = 0; _i < n; _i++) { i += \` \${this.lorem} \`; }
            return i
        };

        /**
        * leistrap \`DropDown\` component
        * @typedef {{parent ? : BaseElement,
        * caption?:string,
        * items?: BaseElement[],
        * btnType?:ColorType,
        * attr? : {className:string, id:string},
        * useBtn? :BaseElement,
        * stopPropagation? :boolean,
        * btnClass? :string[]}}dropOptions
        * @param {dropOptions} option
        * @returns {DropDown}
        */
        leistrap.DropDown = (option = {}) => {
            const d = new DropDown(
                option.parent,
                option.caption,
                option.items,
                option.btnType,
                option.attr,
                option.useBtn,
                option.stopPropagation,
                option.btnClass
            );
            leisData.lDropDown.push(d);
            return d
        };

        /**
        * leistrap \`SlideDown\` / \`carousel\` component 
        * @typedef {{parent:BaseElement, imgList :[{src:string, caption:string}],
        * width : number, height:number, maxHeight:number, minHeight:number}}SlideOption
        * @param {SlideOption} option  the slideDow option
        * @returns {SlideDown}
        */
        leistrap.SlideDown = option => new SlideDown(
            option.parent,
            option.imgList,
            option.width,
            option.height,
            option.maxHeight,
            option.minHeight
        );

        /**
        * leistrap \`Alert\` component
        * @typedef {{
        * parent :BaseElement, 
        * text:string, 
        * type:BtnType,
        * links:{}}} alertOptions
        * @param {alertOptions} option alert options
        */
        leistrap.Alert = option => new Alert(
            option.parent,
            option.text,
            option.type,
            option.links);


        /**
        * leistrap \`SideBar\` component
        * @typedef {{collapsible :[],
        * parent:BaseElement,
        * footer:BaseElement,
        * header:BaseElement, 
        * items:[{
        *    icon:string,
        *    caption:string,
        *    action:(element:BaseElement)=>void
        * }]}}sideOptions
        * @param {sideOptions} option options
        * @returns {SideBar}
        */
        leistrap.SideBar = (option = {}) => new SideBar(
            option.parent,
            option.header,
            option.footer,
            option.items,
            option.collapsible
        );
        /**
         * leistrap \`TopNav\` component 
         * @typedef {{parent:BaseElement, 
         * links:[{name:string, href :string}], 
         * type:BtnType,
         *  position:"sticky"|"fixed",
         *  dropDowns:[]}}NavOptions
         * @param {NavOptions} option  TopNav Options
         * @returns {TopNav}
         */
        leistrap.TopNav = (option = {}) => new TopNav(
            option.parent,
            option.links,
            option.position,
            option.type,
            option.dropDowns);

        /**
        * leistrap \`Collapsible\` component
        * @typedef {{caption :string,
        * parent:BaseElement,
        * content : BaseElement[]}}CollapsibleOptions
        * @param {CollapsibleOptions} option 
        * @returns {Collapsible}
        */
        leistrap.Collapsible = option => new Collapsible(
            option.parent,
            option.content,
            option.caption
        );

        /**
        * leistrap \`SearBar\` widget
        * @param {options} option
        * @returns {Input}
         */
        leistrap.SearchBar = (option) => SearchBar(option);
        /**
        * leistrap.CloseBtn widget
        * @param {EventType} eventType type of event 
        * @param {Function} eventOnce the callback
        */
        leistrap.CloseBtn = CloseBtn;
        /**
        * leistrap \`Modal\` component
        * @param {{parent:BaseElement}} option 
        * @returns {Modal}
        */
        leistrap.Modal = option => {
            if (!option) { option = {}; } return new Modal(option.parent)
        };
        /**
         * leistrap ComboBox Component
         */
        leistrap.ComboBox = option => new ComboBox(option);

        /**
         * leistrap Horizontal box Layout
         */
        leistrap.HBoxLayout = option => {
            if (!option) { option = {}; } return Layout.HBoxLayout(option.parent, option.content)
        };

        leistrap.VBoxLayout = option => {
            if (!option) { option = {}; } return Layout.VBoxLayout(option.parent, option.content)
        };
        /**
        * call the callback when the main window is clicked
        * @param {Function} callback 
        */
        leistrap.winClicked = (callback) => leisData.Callbacks.push(callback);
        leistrap.getPageControler = () => leisData.PageControler;
        // main window eventListener
        window.addEventListener("click", function (e) {
            leisData.lDropDown.forEach(dp => {
                dp.Dcontent.removeClass("show"); dp.Btn.removeClass("activeD");
            });
            leisData.Callbacks.forEach(cl => cl());
        });
        /**
        * add css file
        * @param {string} path 
        */
        leistrap.insertCss = function (path) {
            const l = this.Link({
                otherAttr: {
                    type: "text/css",
                    rel: "stylesheet",
                    href: path
                }
            });
            leis\$1.addCssFile(document, l);
            return l
        };

        /**
         * main element
         */

        leistrap.main = __main__(leistrap, window);
        Object.defineProperty(leistrap, "MPC", { writable: false, value: leistrap.Div() });


        // extensions 

        leistrap.defineExtension = function (name, extn, option) {
            this[name] = obj\$1.after(200, () => { extn(setting, leistrap, extensionOption); });
            this.extension[name] = extn;
        };

        // MPC and render | when app ready
        leistrap.whenReady = function (listener, ...args) {
            !leis\$1.hasConf(this.MPC) ? this.MPC.getPropWait().push(() => {
                obj\$1.after(200, () => {
                    obj\$1.tryCode(() => { listener.call(this.MPC); },
                        (error) => {
                            console.error(error);
                            const m = this.Modal();
                            m.setTitle("Error occured");
                            m.show();
                            m.add(this.P({ text: error.message }));
                            m.setSize("50%", "50vh");
                            m.clear();
                            window.document.body.append(m.point.render());
                        });
                });
            }) :
                obj\$1.after(200, listener, ...args);
        };
        // creations of elements

        leistrap.createContent = function (elem, n, clb) {
            if (obj\$1.isFunction(clb)) {
                return this.inRange(n, 0, (item, index) => clb(this[elem](), index, this[elem]));
            }
            else {
                return this.inRange(n, 0, (item, index) => this[elem]())
            }
        };
        leistrap.dep = extensionOption;
        // render  our page
        Object.defineProperty(leistrap, "selectElement", { writable: false, value: selectElement });
        Object.defineProperty(leistrap, "render", {
            writable: false, value: function (id) {
                this.selectElement({
                    byId: true,
                    id: id,
                    content: [this.MPC]
                });
            }
        });

        return leistrap;
    })();

    const leistrap = ls;

    var style = "/* -------------------- root ---------------------------- */\\r\\n@import url(\\"./font/bs-icons.min.css\\");\\r\\n@import url(\\"./resizable.css\\");\\r\\n\\r\\n:root {\\r\\n    --leis-chat-card-bg-cl: #f4eff8;\\r\\n    --leis-body-cl: #f8f8f8;\\r\\n\\r\\n    --leis-sideNav-cl: hsla(0, 0%, 100%, 0.942);\\r\\n    --leis-sideNav-bx-sh: 0 2px 9px rgba(0, 0, 0, .16);\\r\\n    --leis-highlight-cl: var(--leis-body-cl);\\r\\n    --leis-txt-cl: hsla(0, 0%, 0%, 0.962);\\r\\n    --leis-card-cl: #fff;\\r\\n    --leis-card-bx-sh: 0 4px 8px 0 rgba(0, 0, 0, 0.2);\\r\\n    --leis-card-bd: 1.5px solid rgba(0, 0, 0, .16);\\r\\n    --leis-card-sms-bx-sh: rgba(0, 0, 0, 0.05) 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px;\\r\\n    --leis-line-separator-cl: #d4d4da;\\r\\n    --leis-default-cl: #f8f7fc;\\r\\n    --leis-default-selector: #f6f6f6;\\r\\n    --leis-img-cd-cl: #f1f1f1;\\r\\n    --leis-subtitle-cl: rgb(152, 150, 150);\\r\\n    --leis-img-outline-cl: #aeaeae;\\r\\n\\r\\n    --leis-nav-cl: #fcfbfbcf;\\r\\n    --leis-nav-bx-sh: rgba(0, 0, 0, .16) 0px 1px 4px;\\r\\n\\r\\n    --leis-accordion-bx-sh: rgba(17, 17, 26, 0.05) 0px 1px 0px, rgba(17, 17, 26, 0.1) 0px 0px 2px 1.5px;\\r\\n    --leis-accordion-head-cl: #525752;\\r\\n    --leis-accordion-footer-cl: #c4c2c7;\\r\\n    --leis-accordion-head-txt-cl: hsla(0, 14%, 93%, 0.889);\\r\\n    --leis-accordion-footer-bx-sh: 0 0 3px rgba(11, 11, 11, 0.543);\\r\\n    --leis-primary-cl: #2c7be5;\\r\\n    --leis-primary-hover-cl: #1457b0;\\r\\n    --leis-primary-focus-bx-sh: 0 0 0 3px #007bff80;\\r\\n    --leis-primary-bd-hv-cl: #0062cc;\\r\\n    --leis-primary-bd-cl: #007bff;\\r\\n    --leis-primary-bd-fc-cl: #98caff;\\r\\n\\r\\n    --leis-secondary-cl: #868e96;\\r\\n    --leis-secondary-hover-cl: #717171;\\r\\n    --leis-primary-bd-cl: #868e96;\\r\\n    --leis-secondary-focus-bx-sh: 0 0 0 3px #a4acb5;\\r\\n    --leis-secondary-bd-hv-cl: #b0b6bc;\\r\\n    --leis-secondary-bd-fc-cl: #e4ecf5;\\r\\n\\r\\n    --leis-success-cl: #28a745;\\r\\n    --leis-success-hover-cl: #25933e;\\r\\n    --leis-success-bd-cl: #28a745;\\r\\n    --leis-success-focus-bx-sh: 0 0 0 3px #39c55a;\\r\\n    --leis-seccess-bd-hv-cl: #39da5e;\\r\\n\\r\\n\\r\\n    --leis-custom-success-cl: #2e443d;\\r\\n    --leis-custom-success-bd-cl: #83c89b;\\r\\n    --leis-custom-success-text-cl: #45875b;\\r\\n\\r\\n    --leis-warning-cl: #ffc107;\\r\\n    --leis-warning-hover-cl: #f0c648;\\r\\n    --leis-warning-bd-cl: #ffc107;\\r\\n    --leis-warning-focus-bx-sh: 0 0 0 3px #ffd24d;\\r\\n    --leis-warning-bd-hv-cl: #e5ba3b;\\r\\n\\r\\n    --leis-danger-cl: #dc3545;\\r\\n    --leis-danger-hover-cl: #ce2c3c;\\r\\n    --leis-danger-bd-cl: #dc3545;\\r\\n    --leis-danger-focus-bx-sh: 0 0 0 3px #f3384a;\\r\\n    --leis-danger-bd-hv-cl: #f3384a;\\r\\n\\r\\n    --leis-info-cl: #abdde5;\\r\\n    --leis-info-hover-cl: #89cdd7;\\r\\n    --leis-info-bd-cl: #abdde5;\\r\\n    --leis-info-focus-bx-sh: 0 0 0 3px #c6f5fc;\\r\\n    --leis-info-bd-hv-cl: #c6f5fc;\\r\\n\\r\\n    --leis-light-cl: #fefeff;\\r\\n    --leis-light-hover-cl: #dddde2;\\r\\n    --leis-light-bd-cl: #d8d8de;\\r\\n    --leis-light-focus-bx-sh: 0 0 0 3px #dffafd;\\r\\n    --leis-light-bd-hv-cl: #dffafd;\\r\\n\\r\\n    --leis-dark-cl: #23272b;\\r\\n    --leis-dark-hover-cl: #485157;\\r\\n    --leis-dark-bd-cl: #424950;\\r\\n    --leis-dark-focus-bx-sh: 0 0 0 3px #48525b;\\r\\n    --leis-dark-bd-hv-cl: #515960;\\r\\n    --leis-effect-img: contrast(1.5) brightness(1.02) saturate(108%);\\r\\n    --leis-border-width: 1.2px;\\r\\n    --leis-heading-color: inherit;\\r\\n    --leis-font-sans-serif: system-ui, -apple-system, \\"Segoe UI\\", Roboto, \\"Helvetica Neue\\", \\"Noto Sans\\", \\"Liberation Sans\\", Arial, sans-serif, \\"Apple Color Emoji\\", \\"Segoe UI Emoji\\", \\"Segoe UI Symbol\\", \\"Noto Color Emoji\\";\\r\\n    --leis-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, \\"Liberation Mono\\", \\"Courier New\\", monospace;\\r\\n    --leis-font-size: 1rem;\\r\\n    --leis-resize-cl: var(--leis-primary-cl);\\r\\n    --leis-select-cl: #f6f3f3a3;\\r\\n}\\r\\n\\r\\n\\r\\n/* reset padding and marging */\\r\\n.leis::before,\\r\\n.leisie::before,\\r\\n.leis::after,\\r\\n.leisie::after,\\r\\n.ls::after,\\r\\n.ls::before,\\r\\n.leis,\\r\\n.leisie,\\r\\n\\r\\n.ls {\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n    box-sizing: border-box;\\r\\n}\\r\\n\\r\\nbutton,\\r\\ninput,\\r\\noptgroup,\\r\\nselect,\\r\\ntextarea {\\r\\n    margin: 0;\\r\\n    font-family: inherit;\\r\\n    font-size: inherit;\\r\\n    line-height: inherit\\r\\n}\\r\\n\\r\\nbutton,\\r\\nselect {\\r\\n    text-transform: none\\r\\n}\\r\\n\\r\\nhr {\\r\\n    margin: 1rem 0;\\r\\n    color: inherit;\\r\\n    border: 0;\\r\\n    border-top: var(--leis-border-width) solid;\\r\\n    opacity: .25\\r\\n}\\r\\n\\r\\nh1,\\r\\nh2,\\r\\nh3,\\r\\nh4,\\r\\nh5,\\r\\nh6,\\r\\nth {\\r\\n    margin-top: 0;\\r\\n    margin-bottom: .5rem;\\r\\n    font-weight: 500;\\r\\n    line-height: 1.2;\\r\\n    color: var(--leis-heading-color)\\r\\n}\\r\\n\\r\\nth {\\r\\n    padding: 0 10px;\\r\\n}\\r\\n\\r\\n*,\\r\\n::after,\\r\\n::before {\\r\\n    box-sizing: border-box\\r\\n}\\r\\n\\r\\n* {\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n    box-sizing: border-box;\\r\\n    position: relative;\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n\\r\\nbody {\\r\\n    color: var(--leis-txt-cl);\\r\\n    background-color: var(--leis-body-cl);\\r\\n    font-family: var(--leis-font-sans-serif);\\r\\n    font-weight: 400;\\r\\n    line-height: 1.5;\\r\\n    font-size: var(--leis-font-size);\\r\\n    -webkit-text-size-adjust: 100%;\\r\\n    -webkit-tap-highlight-color: transparent;\\r\\n\\r\\n}\\r\\n\\r\\n[type=search] {\\r\\n    outline-offset: -2px;\\r\\n    -webkit-appearance: textfield\\r\\n}\\r\\n\\r\\n::-webkit-search-decoration {\\r\\n    -webkit-appearance: none\\r\\n}\\r\\n\\r\\n::-webkit-color-swatch-wrapper {\\r\\n    padding: 0\\r\\n}\\r\\n\\r\\n::-webkit-file-upload-button {\\r\\n    font: inherit;\\r\\n    -webkit-appearance: button\\r\\n}\\r\\n\\r\\nhtml {\\r\\n    scroll-behavior: smooth;\\r\\n}\\r\\n\\r\\n/* layout*/\\r\\n\\r\\n.leis-layout {\\r\\n    min-width: 100%;\\r\\n    min-height: 100%;\\r\\n\\r\\n}\\r\\n\\r\\n\\r\\n.leis-hbox-item {\\r\\n    position: relative;\\r\\n    font-size: inherit;\\r\\n    text-align: inherit;\\r\\n    min-height: 100%;\\r\\n}\\r\\n\\r\\n.leis-vbox-item {\\r\\n    position: relative;\\r\\n    min-width: 100%;\\r\\n    font-size: inherit;\\r\\n}\\r\\n\\r\\n/* flexbox */\\r\\n\\r\\n.leis-flex {\\r\\n    position: relative;\\r\\n    display: -webkit-box;\\r\\n    display: -ms-flexbox;\\r\\n    display: flex;\\r\\n    -webkit-box-orient: vertical;\\r\\n    -webkit-box-direction: normal;\\r\\n    -ms-flex-direction: column;\\r\\n    flex-direction: column;\\r\\n    min-width: 0;\\r\\n    word-wrap: break-word;\\r\\n    background-clip: border-box;\\r\\n    margin-bottom: 0.5em;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-flex.leis-row,\\r\\n.leis-row {\\r\\n    -webkit-box-orient: horizontal;\\r\\n    -ms-flex-direction: row;\\r\\n    flex-direction: row;\\r\\n}\\r\\n\\r\\n.leis-flex.leis-column,\\r\\n.leis-colunm {\\r\\n    -webkit-box-orient: vertical;\\r\\n    -ms-flex-direction: column;\\r\\n    flex-direction: column;\\r\\n}\\r\\n\\r\\n.l-g-s {\\r\\n    gap: 0.5rem;\\r\\n}\\r\\n\\r\\n.l-g-n {\\r\\n    gap: 1rem;\\r\\n}\\r\\n\\r\\n.l-g-n {\\r\\n    gap: 1.5rem;\\r\\n}\\r\\n\\r\\n\\r\\n/* padding  */\\r\\n\\r\\n.leis-padding-10 {\\r\\n    padding: 10px;\\r\\n}\\r\\n\\r\\n.leis-padding-20 {\\r\\n    padding: 20px;\\r\\n}\\r\\n\\r\\n.leis-padding-1rem {\\r\\n    padding: 1rem;\\r\\n}\\r\\n\\r\\n.leis-padding-20p {\\r\\n    padding: 20%;\\r\\n}\\r\\n\\r\\n.leis-padding-10p {\\r\\n    padding: 10%;\\r\\n}\\r\\n\\r\\n.leis-padding-14-16 {\\r\\n    padding: 14px 16px;\\r\\n}\\r\\n\\r\\n.leis-padding-10-18 {\\r\\n    padding: 10px 18px;\\r\\n}\\r\\n\\r\\n.leis-padding-2rem {\\r\\n    padding: 2rem;\\r\\n}\\r\\n\\r\\n.leis-padding-28-35 {\\r\\n    padding: 28px 35px;\\r\\n}\\r\\n\\r\\n.leis-padding-1 {\\r\\n    padding: 1px;\\r\\n}\\r\\n\\r\\n.leis-padding-2 {\\r\\n    padding: 2px;\\r\\n}\\r\\n\\r\\n.leis-padding-3 {\\r\\n    padding: 3px;\\r\\n}\\r\\n\\r\\n.leis-padding-4 {\\r\\n    padding: 4px;\\r\\n}\\r\\n\\r\\n.leis-padding-5 {\\r\\n    padding: 5px;\\r\\n}\\r\\n\\r\\n.leis-padding-6 {\\r\\n    padding: 6px;\\r\\n}\\r\\n\\r\\n.leis-padding-7 {\\r\\n    padding: 7px;\\r\\n}\\r\\n\\r\\n.leis-padding-8 {\\r\\n    padding: 8px;\\r\\n}\\r\\n\\r\\n.leis-padding-9 {\\r\\n    padding: 9px;\\r\\n}\\r\\n\\r\\n.leis-padding-10 {\\r\\n    padding: 10px;\\r\\n}\\r\\n\\r\\n.leis-padding-11 {\\r\\n    padding: 11px;\\r\\n}\\r\\n\\r\\n.leis-padding-12 {\\r\\n    padding: 12px;\\r\\n}\\r\\n\\r\\n.leis-padding-13 {\\r\\n    padding: 13px;\\r\\n}\\r\\n\\r\\n.leis-padding-14 {\\r\\n    padding: 14px;\\r\\n}\\r\\n\\r\\n.leis-padding-15 {\\r\\n    padding: 15px;\\r\\n}\\r\\n\\r\\n.leis-padding-16 {\\r\\n    padding: 16px;\\r\\n}\\r\\n\\r\\n.leis-padding-17 {\\r\\n    padding: 17px;\\r\\n}\\r\\n\\r\\n.leis-padding-18 {\\r\\n    padding: 18px;\\r\\n}\\r\\n\\r\\n.leis-padding-19 {\\r\\n    padding: 19px;\\r\\n}\\r\\n\\r\\n.leis-padding-20 {\\r\\n    padding: 20px;\\r\\n}\\r\\n\\r\\n.leis-padding-21 {\\r\\n    padding: 21px;\\r\\n}\\r\\n\\r\\n.leis-padding-22 {\\r\\n    padding: 22px;\\r\\n}\\r\\n\\r\\n.leis-padding-23 {\\r\\n    padding: 23px;\\r\\n}\\r\\n\\r\\n.leis-padding-24 {\\r\\n    padding: 24px;\\r\\n}\\r\\n\\r\\n.leis-padding-25 {\\r\\n    padding: 25px;\\r\\n}\\r\\n\\r\\n.leis-padding-26 {\\r\\n    padding: 26px;\\r\\n}\\r\\n\\r\\n.leis-padding-27 {\\r\\n    padding: 27px;\\r\\n}\\r\\n\\r\\n.leis-padding-28 {\\r\\n    padding: 28px;\\r\\n}\\r\\n\\r\\n.leis-padding-29 {\\r\\n    padding: 29px;\\r\\n}\\r\\n\\r\\n.leis-padding-30 {\\r\\n    padding: 30px;\\r\\n}\\r\\n\\r\\n.leis-padding-31 {\\r\\n    padding: 31px;\\r\\n}\\r\\n\\r\\n.leis-padding-32 {\\r\\n    padding: 32px;\\r\\n}\\r\\n\\r\\n.leis-padding-33 {\\r\\n    padding: 33px;\\r\\n}\\r\\n\\r\\n.leis-padding-34 {\\r\\n    padding: 34px;\\r\\n}\\r\\n\\r\\n.leis-padding-35 {\\r\\n    padding: 35px;\\r\\n}\\r\\n\\r\\n.leis-padding-36 {\\r\\n    padding: 36px;\\r\\n}\\r\\n\\r\\n.leis-padding-37 {\\r\\n    padding: 37px;\\r\\n}\\r\\n\\r\\n.leis-padding-38 {\\r\\n    padding: 38px;\\r\\n}\\r\\n\\r\\n.leis-padding-39 {\\r\\n    padding: 39px;\\r\\n}\\r\\n\\r\\n.leis-padding-40 {\\r\\n    padding: 40px;\\r\\n}\\r\\n\\r\\n.leis-padding-41 {\\r\\n    padding: 41px;\\r\\n}\\r\\n\\r\\n.leis-padding-42 {\\r\\n    padding: 42px;\\r\\n}\\r\\n\\r\\n.leis-padding-43 {\\r\\n    padding: 43px;\\r\\n}\\r\\n\\r\\n.leis-padding-44 {\\r\\n    padding: 44px;\\r\\n}\\r\\n\\r\\n.leis-padding-45 {\\r\\n    padding: 45px;\\r\\n}\\r\\n\\r\\n.leis-padding-46 {\\r\\n    padding: 46px;\\r\\n}\\r\\n\\r\\n.leis-padding-47 {\\r\\n    padding: 47px;\\r\\n}\\r\\n\\r\\n.leis-padding-48 {\\r\\n    padding: 48px;\\r\\n}\\r\\n\\r\\n.leis-padding-49 {\\r\\n    padding: 49px;\\r\\n}\\r\\n\\r\\n.leis-padding-50 {\\r\\n    padding: 50px;\\r\\n}\\r\\n\\r\\n.leis-padding-51 {\\r\\n    padding: 51px;\\r\\n}\\r\\n\\r\\n.leis-padding-52 {\\r\\n    padding: 52px;\\r\\n}\\r\\n\\r\\n.leis-padding-53 {\\r\\n    padding: 53px;\\r\\n}\\r\\n\\r\\n.leis-padding-54 {\\r\\n    padding: 54px;\\r\\n}\\r\\n\\r\\n.leis-padding-55 {\\r\\n    padding: 55px;\\r\\n}\\r\\n\\r\\n.leis-padding-56 {\\r\\n    padding: 56px;\\r\\n}\\r\\n\\r\\n.leis-padding-57 {\\r\\n    padding: 57px;\\r\\n}\\r\\n\\r\\n.leis-padding-58 {\\r\\n    padding: 58px;\\r\\n}\\r\\n\\r\\n.leis-padding-59 {\\r\\n    padding: 59px;\\r\\n}\\r\\n\\r\\n.leis-padding-60 {\\r\\n    padding: 60px;\\r\\n}\\r\\n\\r\\n.leis-padding-61 {\\r\\n    padding: 61px;\\r\\n}\\r\\n\\r\\n.leis-padding-62 {\\r\\n    padding: 62px;\\r\\n}\\r\\n\\r\\n.leis-padding-63 {\\r\\n    padding: 63px;\\r\\n}\\r\\n\\r\\n.leis-padding-64 {\\r\\n    padding: 64px;\\r\\n}\\r\\n\\r\\n.leis-padding-65 {\\r\\n    padding: 65px;\\r\\n}\\r\\n\\r\\n.leis-padding-66 {\\r\\n    padding: 66px;\\r\\n}\\r\\n\\r\\n.leis-padding-67 {\\r\\n    padding: 67px;\\r\\n}\\r\\n\\r\\n.leis-padding-68 {\\r\\n    padding: 68px;\\r\\n}\\r\\n\\r\\n.leis-padding-69 {\\r\\n    padding: 69px;\\r\\n}\\r\\n\\r\\n.leis-padding-70 {\\r\\n    padding: 70px;\\r\\n}\\r\\n\\r\\n.leis-padding-71 {\\r\\n    padding: 71px;\\r\\n}\\r\\n\\r\\n.leis-padding-72 {\\r\\n    padding: 72px;\\r\\n}\\r\\n\\r\\n.leis-padding-73 {\\r\\n    padding: 73px;\\r\\n}\\r\\n\\r\\n.leis-padding-74 {\\r\\n    padding: 74px;\\r\\n}\\r\\n\\r\\n.leis-padding-75 {\\r\\n    padding: 75px;\\r\\n}\\r\\n\\r\\n.leis-padding-76 {\\r\\n    padding: 76px;\\r\\n}\\r\\n\\r\\n.leis-padding-77 {\\r\\n    padding: 77px;\\r\\n}\\r\\n\\r\\n.leis-padding-78 {\\r\\n    padding: 78px;\\r\\n}\\r\\n\\r\\n.leis-padding-79 {\\r\\n    padding: 79px;\\r\\n}\\r\\n\\r\\n.leis-padding-80 {\\r\\n    padding: 80px;\\r\\n}\\r\\n\\r\\n.leis-padding-81 {\\r\\n    padding: 81px;\\r\\n}\\r\\n\\r\\n.leis-padding-82 {\\r\\n    padding: 82px;\\r\\n}\\r\\n\\r\\n.leis-padding-83 {\\r\\n    padding: 83px;\\r\\n}\\r\\n\\r\\n.leis-padding-84 {\\r\\n    padding: 84px;\\r\\n}\\r\\n\\r\\n.leis-padding-85 {\\r\\n    padding: 85px;\\r\\n}\\r\\n\\r\\n.leis-padding-86 {\\r\\n    padding: 86px;\\r\\n}\\r\\n\\r\\n.leis-padding-87 {\\r\\n    padding: 87px;\\r\\n}\\r\\n\\r\\n.leis-padding-88 {\\r\\n    padding: 88px;\\r\\n}\\r\\n\\r\\n.leis-padding-89 {\\r\\n    padding: 89px;\\r\\n}\\r\\n\\r\\n.leis-padding-90 {\\r\\n    padding: 90px;\\r\\n}\\r\\n\\r\\n.leis-padding-91 {\\r\\n    padding: 91px;\\r\\n}\\r\\n\\r\\n.leis-padding-92 {\\r\\n    padding: 92px;\\r\\n}\\r\\n\\r\\n.leis-padding-93 {\\r\\n    padding: 93px;\\r\\n}\\r\\n\\r\\n.leis-padding-94 {\\r\\n    padding: 94px;\\r\\n}\\r\\n\\r\\n.leis-padding-95 {\\r\\n    padding: 95px;\\r\\n}\\r\\n\\r\\n.leis-padding-96 {\\r\\n    padding: 96px;\\r\\n}\\r\\n\\r\\n.leis-padding-97 {\\r\\n    padding: 97px;\\r\\n}\\r\\n\\r\\n.leis-padding-98 {\\r\\n    padding: 98px;\\r\\n}\\r\\n\\r\\n.leis-padding-99 {\\r\\n    padding: 99px;\\r\\n}\\r\\n\\r\\n.leis-padding-1rem {\\r\\n    padding: 1rem;\\r\\n}\\r\\n\\r\\n.leis-padding-2rem {\\r\\n    padding: 2rem;\\r\\n}\\r\\n\\r\\n.leis-padding-3rem {\\r\\n    padding: 3rem;\\r\\n}\\r\\n\\r\\n.leis-padding-4rem {\\r\\n    padding: 4rem;\\r\\n}\\r\\n\\r\\n.leis-padding-5rem {\\r\\n    padding: 5rem;\\r\\n}\\r\\n\\r\\n.leis-padding-6rem {\\r\\n    padding: 6rem;\\r\\n}\\r\\n\\r\\n.leis-padding-7rem {\\r\\n    padding: 7rem;\\r\\n}\\r\\n\\r\\n.leis-padding-8rem {\\r\\n    padding: 8rem;\\r\\n}\\r\\n\\r\\n.leis-padding-9rem {\\r\\n    padding: 9rem;\\r\\n}\\r\\n\\r\\n.leis-padding-10rem {\\r\\n    padding: 10rem;\\r\\n}\\r\\n\\r\\n.leis-padding-11rem {\\r\\n    padding: 11rem;\\r\\n}\\r\\n\\r\\n.leis-padding-12rem {\\r\\n    padding: 12rem;\\r\\n}\\r\\n\\r\\n.leis-padding-13rem {\\r\\n    padding: 13rem;\\r\\n}\\r\\n\\r\\n.leis-padding-14rem {\\r\\n    padding: 14rem;\\r\\n}\\r\\n\\r\\n.leis-padding-15rem {\\r\\n    padding: 15rem;\\r\\n}\\r\\n\\r\\n.leis-padding-16rem {\\r\\n    padding: 16rem;\\r\\n}\\r\\n\\r\\n.leis-padding-17rem {\\r\\n    padding: 17rem;\\r\\n}\\r\\n\\r\\n.leis-padding-18rem {\\r\\n    padding: 18rem;\\r\\n}\\r\\n\\r\\n.leis-padding-19rem {\\r\\n    padding: 19rem;\\r\\n}\\r\\n\\r\\n.leis-padding-1-6 {\\r\\n    padding: 1px 6px;\\r\\n}\\r\\n\\r\\n.leis-padding-2-7 {\\r\\n    padding: 2px 7px;\\r\\n}\\r\\n\\r\\n.leis-padding-3-8 {\\r\\n    padding: 3px 8px;\\r\\n}\\r\\n\\r\\n.leis-padding-4-9 {\\r\\n    padding: 4px 9px;\\r\\n}\\r\\n\\r\\n.leis-padding-5-10 {\\r\\n    padding: 5px 10px;\\r\\n}\\r\\n\\r\\n.leis-padding-6-11 {\\r\\n    padding: 6px 11px;\\r\\n}\\r\\n\\r\\n.leis-padding-7-12 {\\r\\n    padding: 7px 12px;\\r\\n}\\r\\n\\r\\n.leis-padding-8-13 {\\r\\n    padding: 8px 13px;\\r\\n}\\r\\n\\r\\n.leis-padding-9-14 {\\r\\n    padding: 9px 14px;\\r\\n}\\r\\n\\r\\n.leis-padding-10-15 {\\r\\n    padding: 10px 15px;\\r\\n}\\r\\n\\r\\n.leis-padding-11-16 {\\r\\n    padding: 11px 16px;\\r\\n}\\r\\n\\r\\n.leis-padding-12-17 {\\r\\n    padding: 12px 17px;\\r\\n}\\r\\n\\r\\n.leis-padding-13-18 {\\r\\n    padding: 13px 18px;\\r\\n}\\r\\n\\r\\n.leis-padding-14-19 {\\r\\n    padding: 14px 19px;\\r\\n}\\r\\n\\r\\n.leis-padding-15-20 {\\r\\n    padding: 15px 20px;\\r\\n}\\r\\n\\r\\n.leis-padding-16-21 {\\r\\n    padding: 16px 21px;\\r\\n}\\r\\n\\r\\n.leis-padding-17-22 {\\r\\n    padding: 17px 22px;\\r\\n}\\r\\n\\r\\n.leis-padding-18-23 {\\r\\n    padding: 18px 23px;\\r\\n}\\r\\n\\r\\n.leis-padding-19-24 {\\r\\n    padding: 19px 24px;\\r\\n}\\r\\n\\r\\n.leis-padding-20-25 {\\r\\n    padding: 20px 25px;\\r\\n}\\r\\n\\r\\n.leis-padding-21-26 {\\r\\n    padding: 21px 26px;\\r\\n}\\r\\n\\r\\n.leis-padding-22-27 {\\r\\n    padding: 22px 27px;\\r\\n}\\r\\n\\r\\n.leis-padding-23-28 {\\r\\n    padding: 23px 28px;\\r\\n}\\r\\n\\r\\n.leis-padding-24-29 {\\r\\n    padding: 24px 29px;\\r\\n}\\r\\n\\r\\n.leis-padding-25-30 {\\r\\n    padding: 25px 30px;\\r\\n}\\r\\n\\r\\n.leis-padding-26-31 {\\r\\n    padding: 26px 31px;\\r\\n}\\r\\n\\r\\n.leis-padding-27-32 {\\r\\n    padding: 27px 32px;\\r\\n}\\r\\n\\r\\n.leis-padding-28-33 {\\r\\n    padding: 28px 33px;\\r\\n}\\r\\n\\r\\n.leis-padding-29-34 {\\r\\n    padding: 29px 34px;\\r\\n}\\r\\n\\r\\n.leis-padding-30-35 {\\r\\n    padding: 30px 35px;\\r\\n}\\r\\n\\r\\n.leis-padding-31-36 {\\r\\n    padding: 31px 36px;\\r\\n}\\r\\n\\r\\n.leis-padding-32-37 {\\r\\n    padding: 32px 37px;\\r\\n}\\r\\n\\r\\n.leis-padding-33-38 {\\r\\n    padding: 33px 38px;\\r\\n}\\r\\n\\r\\n.leis-padding-34-39 {\\r\\n    padding: 34px 39px;\\r\\n}\\r\\n\\r\\n.leis-padding-35-40 {\\r\\n    padding: 35px 40px;\\r\\n}\\r\\n\\r\\n.leis-padding-36-41 {\\r\\n    padding: 36px 41px;\\r\\n}\\r\\n\\r\\n.leis-padding-37-42 {\\r\\n    padding: 37px 42px;\\r\\n}\\r\\n\\r\\n.leis-padding-38-43 {\\r\\n    padding: 38px 43px;\\r\\n}\\r\\n\\r\\n.leis-padding-39-44 {\\r\\n    padding: 39px 44px;\\r\\n}\\r\\n\\r\\n.leis-padding-40-45 {\\r\\n    padding: 40px 45px;\\r\\n}\\r\\n\\r\\n.leis-padding-41-46 {\\r\\n    padding: 41px 46px;\\r\\n}\\r\\n\\r\\n.leis-padding-42-47 {\\r\\n    padding: 42px 47px;\\r\\n}\\r\\n\\r\\n.leis-padding-43-48 {\\r\\n    padding: 43px 48px;\\r\\n}\\r\\n\\r\\n.leis-padding-44-49 {\\r\\n    padding: 44px 49px;\\r\\n}\\r\\n\\r\\n.leis-padding-45-50 {\\r\\n    padding: 45px 50px;\\r\\n}\\r\\n\\r\\n.leis-padding-46-51 {\\r\\n    padding: 46px 51px;\\r\\n}\\r\\n\\r\\n.leis-padding-47-52 {\\r\\n    padding: 47px 52px;\\r\\n}\\r\\n\\r\\n.leis-padding-48-53 {\\r\\n    padding: 48px 53px;\\r\\n}\\r\\n\\r\\n.leis-padding-49-54 {\\r\\n    padding: 49px 54px;\\r\\n}\\r\\n\\r\\n.leis-padding-10p {\\r\\n    padding: 10%;\\r\\n}\\r\\n\\r\\n.leis-padding-20p {\\r\\n    padding: 20%;\\r\\n}\\r\\n\\r\\n.leis-padding-30p {\\r\\n    padding: 30%;\\r\\n}\\r\\n\\r\\n.leis-padding-40p {\\r\\n    padding: 40%;\\r\\n}\\r\\n\\r\\n.leis-padding-left-0 {\\r\\n    padding-left: 0px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-1 {\\r\\n    padding-left: 1px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-2 {\\r\\n    padding-left: 2px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-3 {\\r\\n    padding-left: 3px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-4 {\\r\\n    padding-left: 4px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-5 {\\r\\n    padding-left: 5px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-6 {\\r\\n    padding-left: 6px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-7 {\\r\\n    padding-left: 7px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-8 {\\r\\n    padding-left: 8px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-9 {\\r\\n    padding-left: 9px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-10 {\\r\\n    padding-left: 10px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-11 {\\r\\n    padding-left: 11px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-12 {\\r\\n    padding-left: 12px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-13 {\\r\\n    padding-left: 13px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-14 {\\r\\n    padding-left: 14px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-15 {\\r\\n    padding-left: 15px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-16 {\\r\\n    padding-left: 16px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-17 {\\r\\n    padding-left: 17px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-18 {\\r\\n    padding-left: 18px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-19 {\\r\\n    padding-left: 19px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-20 {\\r\\n    padding-left: 20px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-21 {\\r\\n    padding-left: 21px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-22 {\\r\\n    padding-left: 22px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-23 {\\r\\n    padding-left: 23px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-24 {\\r\\n    padding-left: 24px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-25 {\\r\\n    padding-left: 25px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-26 {\\r\\n    padding-left: 26px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-27 {\\r\\n    padding-left: 27px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-28 {\\r\\n    padding-left: 28px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-29 {\\r\\n    padding-left: 29px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-30 {\\r\\n    padding-left: 30px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-31 {\\r\\n    padding-left: 31px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-32 {\\r\\n    padding-left: 32px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-33 {\\r\\n    padding-left: 33px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-34 {\\r\\n    padding-left: 34px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-35 {\\r\\n    padding-left: 35px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-36 {\\r\\n    padding-left: 36px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-37 {\\r\\n    padding-left: 37px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-38 {\\r\\n    padding-left: 38px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-39 {\\r\\n    padding-left: 39px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-40 {\\r\\n    padding-left: 40px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-41 {\\r\\n    padding-left: 41px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-42 {\\r\\n    padding-left: 42px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-43 {\\r\\n    padding-left: 43px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-44 {\\r\\n    padding-left: 44px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-45 {\\r\\n    padding-left: 45px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-46 {\\r\\n    padding-left: 46px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-47 {\\r\\n    padding-left: 47px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-48 {\\r\\n    padding-left: 48px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-49 {\\r\\n    padding-left: 49px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-50 {\\r\\n    padding-left: 50px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-51 {\\r\\n    padding-left: 51px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-52 {\\r\\n    padding-left: 52px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-53 {\\r\\n    padding-left: 53px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-54 {\\r\\n    padding-left: 54px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-55 {\\r\\n    padding-left: 55px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-56 {\\r\\n    padding-left: 56px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-57 {\\r\\n    padding-left: 57px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-58 {\\r\\n    padding-left: 58px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-59 {\\r\\n    padding-left: 59px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-60 {\\r\\n    padding-left: 60px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-61 {\\r\\n    padding-left: 61px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-62 {\\r\\n    padding-left: 62px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-63 {\\r\\n    padding-left: 63px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-64 {\\r\\n    padding-left: 64px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-65 {\\r\\n    padding-left: 65px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-66 {\\r\\n    padding-left: 66px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-67 {\\r\\n    padding-left: 67px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-68 {\\r\\n    padding-left: 68px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-69 {\\r\\n    padding-left: 69px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-70 {\\r\\n    padding-left: 70px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-71 {\\r\\n    padding-left: 71px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-72 {\\r\\n    padding-left: 72px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-73 {\\r\\n    padding-left: 73px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-74 {\\r\\n    padding-left: 74px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-75 {\\r\\n    padding-left: 75px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-76 {\\r\\n    padding-left: 76px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-77 {\\r\\n    padding-left: 77px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-78 {\\r\\n    padding-left: 78px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-79 {\\r\\n    padding-left: 79px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-80 {\\r\\n    padding-left: 80px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-81 {\\r\\n    padding-left: 81px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-82 {\\r\\n    padding-left: 82px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-83 {\\r\\n    padding-left: 83px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-84 {\\r\\n    padding-left: 84px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-85 {\\r\\n    padding-left: 85px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-86 {\\r\\n    padding-left: 86px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-87 {\\r\\n    padding-left: 87px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-88 {\\r\\n    padding-left: 88px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-89 {\\r\\n    padding-left: 89px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-90 {\\r\\n    padding-left: 90px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-91 {\\r\\n    padding-left: 91px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-92 {\\r\\n    padding-left: 92px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-93 {\\r\\n    padding-left: 93px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-94 {\\r\\n    padding-left: 94px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-95 {\\r\\n    padding-left: 95px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-96 {\\r\\n    padding-left: 96px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-97 {\\r\\n    padding-left: 97px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-98 {\\r\\n    padding-left: 98px;\\r\\n}\\r\\n\\r\\n.leis-padding-left-99 {\\r\\n    padding-left: 99px;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-padding-left-100 {\\r\\n    padding-left: 100px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-0 {\\r\\n    padding-right: 0px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-1 {\\r\\n    padding-right: 1px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-2 {\\r\\n    padding-right: 2px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-3 {\\r\\n    padding-right: 3px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-4 {\\r\\n    padding-right: 4px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-5 {\\r\\n    padding-right: 5px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-6 {\\r\\n    padding-right: 6px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-7 {\\r\\n    padding-right: 7px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-8 {\\r\\n    padding-right: 8px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-9 {\\r\\n    padding-right: 9px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-10 {\\r\\n    padding-right: 10px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-11 {\\r\\n    padding-right: 11px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-12 {\\r\\n    padding-right: 12px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-13 {\\r\\n    padding-right: 13px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-14 {\\r\\n    padding-right: 14px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-15 {\\r\\n    padding-right: 15px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-16 {\\r\\n    padding-right: 16px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-17 {\\r\\n    padding-right: 17px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-18 {\\r\\n    padding-right: 18px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-19 {\\r\\n    padding-right: 19px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-20 {\\r\\n    padding-right: 20px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-21 {\\r\\n    padding-right: 21px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-22 {\\r\\n    padding-right: 22px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-23 {\\r\\n    padding-right: 23px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-24 {\\r\\n    padding-right: 24px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-25 {\\r\\n    padding-right: 25px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-26 {\\r\\n    padding-right: 26px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-27 {\\r\\n    padding-right: 27px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-28 {\\r\\n    padding-right: 28px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-29 {\\r\\n    padding-right: 29px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-30 {\\r\\n    padding-right: 30px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-31 {\\r\\n    padding-right: 31px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-32 {\\r\\n    padding-right: 32px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-33 {\\r\\n    padding-right: 33px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-34 {\\r\\n    padding-right: 34px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-35 {\\r\\n    padding-right: 35px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-36 {\\r\\n    padding-right: 36px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-37 {\\r\\n    padding-right: 37px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-38 {\\r\\n    padding-right: 38px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-39 {\\r\\n    padding-right: 39px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-40 {\\r\\n    padding-right: 40px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-41 {\\r\\n    padding-right: 41px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-42 {\\r\\n    padding-right: 42px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-43 {\\r\\n    padding-right: 43px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-44 {\\r\\n    padding-right: 44px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-45 {\\r\\n    padding-right: 45px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-46 {\\r\\n    padding-right: 46px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-47 {\\r\\n    padding-right: 47px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-48 {\\r\\n    padding-right: 48px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-49 {\\r\\n    padding-right: 49px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-50 {\\r\\n    padding-right: 50px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-51 {\\r\\n    padding-right: 51px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-52 {\\r\\n    padding-right: 52px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-53 {\\r\\n    padding-right: 53px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-54 {\\r\\n    padding-right: 54px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-55 {\\r\\n    padding-right: 55px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-56 {\\r\\n    padding-right: 56px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-57 {\\r\\n    padding-right: 57px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-58 {\\r\\n    padding-right: 58px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-59 {\\r\\n    padding-right: 59px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-60 {\\r\\n    padding-right: 60px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-61 {\\r\\n    padding-right: 61px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-62 {\\r\\n    padding-right: 62px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-63 {\\r\\n    padding-right: 63px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-64 {\\r\\n    padding-right: 64px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-65 {\\r\\n    padding-right: 65px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-66 {\\r\\n    padding-right: 66px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-67 {\\r\\n    padding-right: 67px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-68 {\\r\\n    padding-right: 68px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-69 {\\r\\n    padding-right: 69px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-70 {\\r\\n    padding-right: 70px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-71 {\\r\\n    padding-right: 71px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-72 {\\r\\n    padding-right: 72px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-73 {\\r\\n    padding-right: 73px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-74 {\\r\\n    padding-right: 74px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-75 {\\r\\n    padding-right: 75px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-76 {\\r\\n    padding-right: 76px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-77 {\\r\\n    padding-right: 77px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-78 {\\r\\n    padding-right: 78px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-79 {\\r\\n    padding-right: 79px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-80 {\\r\\n    padding-right: 80px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-81 {\\r\\n    padding-right: 81px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-82 {\\r\\n    padding-right: 82px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-83 {\\r\\n    padding-right: 83px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-84 {\\r\\n    padding-right: 84px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-85 {\\r\\n    padding-right: 85px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-86 {\\r\\n    padding-right: 86px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-87 {\\r\\n    padding-right: 87px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-88 {\\r\\n    padding-right: 88px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-89 {\\r\\n    padding-right: 89px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-90 {\\r\\n    padding-right: 90px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-91 {\\r\\n    padding-right: 91px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-92 {\\r\\n    padding-right: 92px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-93 {\\r\\n    padding-right: 93px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-94 {\\r\\n    padding-right: 94px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-95 {\\r\\n    padding-right: 95px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-96 {\\r\\n    padding-right: 96px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-97 {\\r\\n    padding-right: 97px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-98 {\\r\\n    padding-right: 98px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-99 {\\r\\n    padding-right: 99px;\\r\\n}\\r\\n\\r\\n.leis-padding-right-100 {\\r\\n    padding-right: 100px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-0 {\\r\\n    padding-top: 0px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-1 {\\r\\n    padding-top: 1px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-2 {\\r\\n    padding-top: 2px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-3 {\\r\\n    padding-top: 3px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-4 {\\r\\n    padding-top: 4px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-5 {\\r\\n    padding-top: 5px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-6 {\\r\\n    padding-top: 6px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-7 {\\r\\n    padding-top: 7px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-8 {\\r\\n    padding-top: 8px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-9 {\\r\\n    padding-top: 9px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-10 {\\r\\n    padding-top: 10px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-11 {\\r\\n    padding-top: 11px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-12 {\\r\\n    padding-top: 12px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-13 {\\r\\n    padding-top: 13px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-14 {\\r\\n    padding-top: 14px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-15 {\\r\\n    padding-top: 15px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-16 {\\r\\n    padding-top: 16px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-17 {\\r\\n    padding-top: 17px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-18 {\\r\\n    padding-top: 18px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-19 {\\r\\n    padding-top: 19px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-20 {\\r\\n    padding-top: 20px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-21 {\\r\\n    padding-top: 21px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-22 {\\r\\n    padding-top: 22px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-23 {\\r\\n    padding-top: 23px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-24 {\\r\\n    padding-top: 24px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-25 {\\r\\n    padding-top: 25px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-26 {\\r\\n    padding-top: 26px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-27 {\\r\\n    padding-top: 27px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-28 {\\r\\n    padding-top: 28px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-29 {\\r\\n    padding-top: 29px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-30 {\\r\\n    padding-top: 30px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-31 {\\r\\n    padding-top: 31px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-32 {\\r\\n    padding-top: 32px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-33 {\\r\\n    padding-top: 33px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-34 {\\r\\n    padding-top: 34px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-35 {\\r\\n    padding-top: 35px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-36 {\\r\\n    padding-top: 36px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-37 {\\r\\n    padding-top: 37px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-38 {\\r\\n    padding-top: 38px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-39 {\\r\\n    padding-top: 39px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-40 {\\r\\n    padding-top: 40px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-41 {\\r\\n    padding-top: 41px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-42 {\\r\\n    padding-top: 42px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-43 {\\r\\n    padding-top: 43px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-44 {\\r\\n    padding-top: 44px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-45 {\\r\\n    padding-top: 45px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-46 {\\r\\n    padding-top: 46px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-47 {\\r\\n    padding-top: 47px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-48 {\\r\\n    padding-top: 48px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-49 {\\r\\n    padding-top: 49px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-50 {\\r\\n    padding-top: 50px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-51 {\\r\\n    padding-top: 51px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-52 {\\r\\n    padding-top: 52px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-53 {\\r\\n    padding-top: 53px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-54 {\\r\\n    padding-top: 54px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-55 {\\r\\n    padding-top: 55px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-56 {\\r\\n    padding-top: 56px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-57 {\\r\\n    padding-top: 57px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-58 {\\r\\n    padding-top: 58px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-59 {\\r\\n    padding-top: 59px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-60 {\\r\\n    padding-top: 60px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-61 {\\r\\n    padding-top: 61px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-62 {\\r\\n    padding-top: 62px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-63 {\\r\\n    padding-top: 63px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-64 {\\r\\n    padding-top: 64px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-65 {\\r\\n    padding-top: 65px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-66 {\\r\\n    padding-top: 66px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-67 {\\r\\n    padding-top: 67px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-68 {\\r\\n    padding-top: 68px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-69 {\\r\\n    padding-top: 69px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-70 {\\r\\n    padding-top: 70px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-71 {\\r\\n    padding-top: 71px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-72 {\\r\\n    padding-top: 72px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-73 {\\r\\n    padding-top: 73px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-74 {\\r\\n    padding-top: 74px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-75 {\\r\\n    padding-top: 75px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-76 {\\r\\n    padding-top: 76px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-77 {\\r\\n    padding-top: 77px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-78 {\\r\\n    padding-top: 78px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-79 {\\r\\n    padding-top: 79px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-80 {\\r\\n    padding-top: 80px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-81 {\\r\\n    padding-top: 81px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-82 {\\r\\n    padding-top: 82px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-83 {\\r\\n    padding-top: 83px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-84 {\\r\\n    padding-top: 84px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-85 {\\r\\n    padding-top: 85px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-86 {\\r\\n    padding-top: 86px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-87 {\\r\\n    padding-top: 87px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-88 {\\r\\n    padding-top: 88px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-89 {\\r\\n    padding-top: 89px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-90 {\\r\\n    padding-top: 90px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-91 {\\r\\n    padding-top: 91px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-92 {\\r\\n    padding-top: 92px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-93 {\\r\\n    padding-top: 93px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-94 {\\r\\n    padding-top: 94px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-95 {\\r\\n    padding-top: 95px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-96 {\\r\\n    padding-top: 96px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-97 {\\r\\n    padding-top: 97px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-98 {\\r\\n    padding-top: 98px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-99 {\\r\\n    padding-top: 99px;\\r\\n}\\r\\n\\r\\n.leis-padding-top-100 {\\r\\n    padding-top: 100px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-0 {\\r\\n    padding-bottom: 0px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-1 {\\r\\n    padding-bottom: 1px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-2 {\\r\\n    padding-bottom: 2px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-3 {\\r\\n    padding-bottom: 3px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-4 {\\r\\n    padding-bottom: 4px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-5 {\\r\\n    padding-bottom: 5px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-6 {\\r\\n    padding-bottom: 6px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-7 {\\r\\n    padding-bottom: 7px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-8 {\\r\\n    padding-bottom: 8px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-9 {\\r\\n    padding-bottom: 9px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-10 {\\r\\n    padding-bottom: 10px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-11 {\\r\\n    padding-bottom: 11px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-12 {\\r\\n    padding-bottom: 12px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-13 {\\r\\n    padding-bottom: 13px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-14 {\\r\\n    padding-bottom: 14px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-15 {\\r\\n    padding-bottom: 15px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-16 {\\r\\n    padding-bottom: 16px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-17 {\\r\\n    padding-bottom: 17px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-18 {\\r\\n    padding-bottom: 18px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-19 {\\r\\n    padding-bottom: 19px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-20 {\\r\\n    padding-bottom: 20px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-21 {\\r\\n    padding-bottom: 21px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-22 {\\r\\n    padding-bottom: 22px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-23 {\\r\\n    padding-bottom: 23px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-24 {\\r\\n    padding-bottom: 24px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-25 {\\r\\n    padding-bottom: 25px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-26 {\\r\\n    padding-bottom: 26px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-27 {\\r\\n    padding-bottom: 27px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-28 {\\r\\n    padding-bottom: 28px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-29 {\\r\\n    padding-bottom: 29px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-30 {\\r\\n    padding-bottom: 30px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-31 {\\r\\n    padding-bottom: 31px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-32 {\\r\\n    padding-bottom: 32px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-33 {\\r\\n    padding-bottom: 33px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-34 {\\r\\n    padding-bottom: 34px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-35 {\\r\\n    padding-bottom: 35px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-36 {\\r\\n    padding-bottom: 36px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-37 {\\r\\n    padding-bottom: 37px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-38 {\\r\\n    padding-bottom: 38px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-39 {\\r\\n    padding-bottom: 39px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-40 {\\r\\n    padding-bottom: 40px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-41 {\\r\\n    padding-bottom: 41px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-42 {\\r\\n    padding-bottom: 42px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-43 {\\r\\n    padding-bottom: 43px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-44 {\\r\\n    padding-bottom: 44px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-45 {\\r\\n    padding-bottom: 45px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-46 {\\r\\n    padding-bottom: 46px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-47 {\\r\\n    padding-bottom: 47px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-48 {\\r\\n    padding-bottom: 48px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-49 {\\r\\n    padding-bottom: 49px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-50 {\\r\\n    padding-bottom: 50px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-51 {\\r\\n    padding-bottom: 51px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-52 {\\r\\n    padding-bottom: 52px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-53 {\\r\\n    padding-bottom: 53px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-54 {\\r\\n    padding-bottom: 54px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-55 {\\r\\n    padding-bottom: 55px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-56 {\\r\\n    padding-bottom: 56px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-57 {\\r\\n    padding-bottom: 57px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-58 {\\r\\n    padding-bottom: 58px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-59 {\\r\\n    padding-bottom: 59px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-60 {\\r\\n    padding-bottom: 60px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-61 {\\r\\n    padding-bottom: 61px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-62 {\\r\\n    padding-bottom: 62px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-63 {\\r\\n    padding-bottom: 63px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-64 {\\r\\n    padding-bottom: 64px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-65 {\\r\\n    padding-bottom: 65px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-66 {\\r\\n    padding-bottom: 66px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-67 {\\r\\n    padding-bottom: 67px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-68 {\\r\\n    padding-bottom: 68px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-69 {\\r\\n    padding-bottom: 69px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-70 {\\r\\n    padding-bottom: 70px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-71 {\\r\\n    padding-bottom: 71px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-72 {\\r\\n    padding-bottom: 72px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-73 {\\r\\n    padding-bottom: 73px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-74 {\\r\\n    padding-bottom: 74px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-75 {\\r\\n    padding-bottom: 75px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-76 {\\r\\n    padding-bottom: 76px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-77 {\\r\\n    padding-bottom: 77px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-78 {\\r\\n    padding-bottom: 78px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-79 {\\r\\n    padding-bottom: 79px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-80 {\\r\\n    padding-bottom: 80px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-81 {\\r\\n    padding-bottom: 81px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-82 {\\r\\n    padding-bottom: 82px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-83 {\\r\\n    padding-bottom: 83px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-84 {\\r\\n    padding-bottom: 84px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-85 {\\r\\n    padding-bottom: 85px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-86 {\\r\\n    padding-bottom: 86px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-87 {\\r\\n    padding-bottom: 87px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-88 {\\r\\n    padding-bottom: 88px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-89 {\\r\\n    padding-bottom: 89px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-90 {\\r\\n    padding-bottom: 90px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-91 {\\r\\n    padding-bottom: 91px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-92 {\\r\\n    padding-bottom: 92px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-93 {\\r\\n    padding-bottom: 93px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-94 {\\r\\n    padding-bottom: 94px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-95 {\\r\\n    padding-bottom: 95px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-96 {\\r\\n    padding-bottom: 96px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-97 {\\r\\n    padding-bottom: 97px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-98 {\\r\\n    padding-bottom: 98px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-99 {\\r\\n    padding-bottom: 99px;\\r\\n}\\r\\n\\r\\n.leis-padding-bottom-100 {\\r\\n    padding-bottom: 100px;\\r\\n}\\r\\n\\r\\n/* ------------- margin -------- */\\r\\n\\r\\n.leis-margin-1t {\\r\\n    margin: 1rem auto;\\r\\n}\\r\\n\\r\\n.leis-margin-left-1x {\\r\\n    margin-left: 1rem;\\r\\n}\\r\\n\\r\\n.leis-margin-left-2x {\\r\\n    margin-left: 2rem;\\r\\n}\\r\\n\\r\\n.leis-margin-right-1x {\\r\\n    margin-right: 1rem;\\r\\n}\\r\\n\\r\\n.leis-margin-right-2x {\\r\\n    margin-right: 2rem;\\r\\n}\\r\\n\\r\\n.leis-margin-top-1x {\\r\\n    margin-top: 1rem;\\r\\n}\\r\\n\\r\\n.leis-margin-top-2x {\\r\\n    margin-right: 2rem;\\r\\n}\\r\\n\\r\\n.leis-margin-top-0 {\\r\\n    margin-top: 0px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-1 {\\r\\n    margin-top: 1px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-2 {\\r\\n    margin-top: 2px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-3 {\\r\\n    margin-top: 3px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-4 {\\r\\n    margin-top: 4px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-5 {\\r\\n    margin-top: 5px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-6 {\\r\\n    margin-top: 6px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-7 {\\r\\n    margin-top: 7px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-8 {\\r\\n    margin-top: 8px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-9 {\\r\\n    margin-top: 9px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-10 {\\r\\n    margin-top: 10px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-11 {\\r\\n    margin-top: 11px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-12 {\\r\\n    margin-top: 12px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-13 {\\r\\n    margin-top: 13px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-14 {\\r\\n    margin-top: 14px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-15 {\\r\\n    margin-top: 15px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-16 {\\r\\n    margin-top: 16px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-17 {\\r\\n    margin-top: 17px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-18 {\\r\\n    margin-top: 18px;\\r\\n}\\r\\n\\r\\n.leis-margin-top-19 {\\r\\n    margin-top: 19px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-1x {\\r\\n    margin-bottom: 1rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-2x {\\r\\n    margin-bottom: 2rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-0rem {\\r\\n    margin-bottom: 0rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-1rem {\\r\\n    margin-bottom: 1rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-2rem {\\r\\n    margin-bottom: 2rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-3rem {\\r\\n    margin-bottom: 3rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-4rem {\\r\\n    margin-bottom: 4rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-5rem {\\r\\n    margin-bottom: 5rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-6rem {\\r\\n    margin-bottom: 6rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-7rem {\\r\\n    margin-bottom: 7rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-8rem {\\r\\n    margin-bottom: 8rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-9rem {\\r\\n    margin-bottom: 9rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-10rem {\\r\\n    margin-bottom: 10rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-11rem {\\r\\n    margin-bottom: 11rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-12rem {\\r\\n    margin-bottom: 12rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-13rem {\\r\\n    margin-bottom: 13rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-14rem {\\r\\n    margin-bottom: 14rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-15rem {\\r\\n    margin-bottom: 15rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-16rem {\\r\\n    margin-bottom: 16rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-17rem {\\r\\n    margin-bottom: 17rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-18rem {\\r\\n    margin-bottom: 18rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-19rem {\\r\\n    margin-bottom: 19rem;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-0 {\\r\\n    margin-bottom: 0px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-1 {\\r\\n    margin-bottom: 1px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-2 {\\r\\n    margin-bottom: 2px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-3 {\\r\\n    margin-bottom: 3px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-4 {\\r\\n    margin-bottom: 4px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-5 {\\r\\n    margin-bottom: 5px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-6 {\\r\\n    margin-bottom: 6px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-7 {\\r\\n    margin-bottom: 7px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-8 {\\r\\n    margin-bottom: 8px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-9 {\\r\\n    margin-bottom: 9px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-10 {\\r\\n    margin-bottom: 10px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-11 {\\r\\n    margin-bottom: 11px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-12 {\\r\\n    margin-bottom: 12px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-13 {\\r\\n    margin-bottom: 13px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-14 {\\r\\n    margin-bottom: 14px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-15 {\\r\\n    margin-bottom: 15px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-16 {\\r\\n    margin-bottom: 16px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-17 {\\r\\n    margin-bottom: 17px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-18 {\\r\\n    margin-bottom: 18px;\\r\\n}\\r\\n\\r\\n.leis-margin-bottom-19 {\\r\\n    margin-bottom: 19px;\\r\\n}\\r\\n\\r\\n/* -------------------------- btns ----------------------------------- */\\r\\n.leis-btn-close {\\r\\n    border: 2px solid #dddddd90;\\r\\n    outline: none;\\r\\n    background-color: inherit;\\r\\n    cursor: pointer;\\r\\n    font-size: 1.5rem;\\r\\n    padding-left: 8px;\\r\\n    padding-right: 8px;\\r\\n    padding-bottom: 2px;\\r\\n    border-radius: 8px;\\r\\n}\\r\\n\\r\\n.leis-btn,\\r\\n.leis-dropBtn {\\r\\n    outline: none;\\r\\n    border: none;\\r\\n    background-color: inherit;\\r\\n    cursor: pointer;\\r\\n    padding: 6px 16px;\\r\\n    appearance: none;\\r\\n    border-radius: 6px;\\r\\n    border: 1px solid #ccc;\\r\\n    -webkit-box-shadow: rgba(27, 31, 35, 0.04) 0 1px 0 inset;\\r\\n    box-shadow: rgba(27, 31, 35, 0.04) 0 1px 0 inset;\\r\\n    display: inline-block;\\r\\n    position: relative;\\r\\n    -webkit-user-select: none;\\r\\n    -ms-user-select: none;\\r\\n    -moz-user-select: none;\\r\\n    touch-action: manipulation;\\r\\n    vertical-align: middle;\\r\\n    white-space: nowrap;\\r\\n    font-size: 1rem;\\r\\n    font-family: inherit;\\r\\n    word-wrap: break-word;\\r\\n    overflow: hidden;\\r\\n    text-overflow: ellipsis;\\r\\n    transition: 0.5s ease-in-out;\\r\\n}\\r\\n\\r\\n.leis-dropBtn {\\r\\n    gap: 10px;\\r\\n}\\r\\n\\r\\n.leis-btn:focus {\\r\\n    box-shadow: 0 0 1px 4px #627e7564;\\r\\n}\\r\\n\\r\\n.leis-btn-primary,\\r\\n.leis-dropBtn-primary {\\r\\n    background-color: var(--leis-primary-cl);\\r\\n    color: #fff !important;\\r\\n    border-radius: 6px;\\r\\n    border-width: 0.5px;\\r\\n    border-color: var(--leis-primary-bd-cl);\\r\\n}\\r\\n\\r\\n.leis-btn-primary:hover,\\r\\n.leis-dropBtn-primary:hover {\\r\\n    background-color: var(--leis-primary-hover-cl);\\r\\n    color: #fff;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-btn-primary:focus,\\r\\n.leis-dropBtn-primary:focus,\\r\\n.leis-btn-primary.focus,\\r\\n.leis-dropBtn-primary.focus {\\r\\n    -webkit-box-shadow: var(--leis-primary-focus-bx-sh);\\r\\n    -o-box-shadow: var(--leis-primary-focus-bx-sh);\\r\\n    box-shadow: var(--leis-primary-focus-bx-sh);\\r\\n}\\r\\n\\r\\n.leis-btn-primary:focus:hover {\\r\\n    border: 1px solid var(--leis-primary-bd-fc-cl);\\r\\n}\\r\\n\\r\\n.leis-btn-secondary,\\r\\n.leis-dropBtn-secondary {\\r\\n    background-color: var(--leis-secondary-cl);\\r\\n    color: #fff !important;\\r\\n    border-radius: 6px;\\r\\n    border: 0.5px solid var(--leis-secondary-bd-cl);\\r\\n}\\r\\n\\r\\n.leis-btn-secondary:hover,\\r\\n.leis-dropBtn-secondary:hover {\\r\\n    background-color: var(--leis-secondary-hover-cl);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-btn-secondary:focus,\\r\\n.leis-btn-secondary.focus,\\r\\n.leis-dropBtn-secondary:focus,\\r\\n.leis-dropBtn-secondary.focus,\\r\\n.leis-btn-close:focus {\\r\\n    -webkit-box-shadow: var(--leis-secondary-focus-bx-sh);\\r\\n    -o-box-shadow: var(--leis-secondary-focus-bx-sh);\\r\\n    box-shadow: var(--leis-secondary-focus-bx-sh);\\r\\n    border: 1px solid var(--leis-secondary-bd-cl);\\r\\n    transition: .2s ease-in;\\r\\n}\\r\\n\\r\\n\\r\\n.leis-btn-secondary:focus:hover {\\r\\n    border: 1px solid var(--leis-secondary-bd-fc-cl);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-btn-success,\\r\\n.leis-dropBtn-success {\\r\\n    background-color: var(--leis-success-cl);\\r\\n    color: #fff !important;\\r\\n    border-radius: 6px;\\r\\n    border-width: 0.5px;\\r\\n    border-color: var(--leis-success-bd-cl);\\r\\n}\\r\\n\\r\\n.leis-btn-success:hover,\\r\\n.leis-dropBtn-success:hover {\\r\\n    background-color: var(--leis-success-hover-cl);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-btn-success:focus,\\r\\n.leis-btn-success.focus,\\r\\n.leis-dropBtn-success:focus,\\r\\n.leis-dropBtn-success.focus {\\r\\n    -webkit-box-shadow: var(--leis-success-focus-bx-sh);\\r\\n    -o-box-shadow: var(--leis-success-focus-bx-sh);\\r\\n    box-shadow: var(--leis-success-focus-bx-sh);\\r\\n}\\r\\n\\r\\n.leis-btn-success:focus:hover {\\r\\n    border: 1px solid var(--leis-custom-success-bd-cl);\\r\\n}\\r\\n\\r\\n.leis-btn-warning,\\r\\n.leis-dropBtn-warning {\\r\\n    background-color: var(--leis-warning-cl);\\r\\n    color: black !important;\\r\\n    border-radius: 6px;\\r\\n    border-width: 0.5px;\\r\\n    border-color: var(--leis-warning-bd-cl);\\r\\n}\\r\\n\\r\\n.leis-btn-warning:hover,\\r\\n.leis-dropBtn-warning:hover {\\r\\n    background-color: var(--leis-warning-hover-cl);\\r\\n    border-color: var(--leis-warning-bd-hv-cl)\\r\\n}\\r\\n\\r\\n.leis-btn-warning:focus,\\r\\n.leis-btn-warning.focus,\\r\\n.leis-dropBtn-warning:focus,\\r\\n.leis-dropBtn-warning.focus {\\r\\n    -webkit-box-shadow: var(--leis-warning-focus-bx-sh);\\r\\n    -o-box-shadow: var(--leis-warning-focus-bx-sh);\\r\\n    box-shadow: var(--leis-warning-focus-bx-sh);\\r\\n}\\r\\n\\r\\n.leis-btn-danger,\\r\\n.leis-dropBtn-danger {\\r\\n    background-color: var(--leis-danger-cl);\\r\\n    color: white !important;\\r\\n    border-radius: 6px;\\r\\n    border-width: 0.5px;\\r\\n    border-color: var(--leis-danger-bd-cl);\\r\\n}\\r\\n\\r\\n.leis-btn-danger:hover,\\r\\n.leis-dropBtn-danger:hover {\\r\\n    background-color: var(--leis-danger-hover-cl);\\r\\n    border-color: var(--leis-danger-bd-hv-cl)\\r\\n}\\r\\n\\r\\n.leis-btn-danger:focus,\\r\\n.leis-btn-danger.focus,\\r\\n.leis-dropBtn-danger:focus,\\r\\n.leis-dropBtn-danger.focus {\\r\\n    -webkit-box-shadow: var(--leis-danger-focus-bx-sh);\\r\\n    -o-box-shadow: var(--leis-danger-focus-bx-sh);\\r\\n    box-shadow: var(--leis-danger-focus-bx-sh);\\r\\n}\\r\\n\\r\\n.leis-btn-info,\\r\\n.leis-dropBtn-info {\\r\\n    background-color: var(--leis-info-cl);\\r\\n    color: black !important;\\r\\n    border-radius: 6px;\\r\\n    border-width: 0.5px;\\r\\n    border-color: var(--leis-info-bd-cl);\\r\\n}\\r\\n\\r\\n.leis-btn-info:hover,\\r\\n.leis-dropBtn-info:hover {\\r\\n    background-color: var(--leis-info-hover-cl);\\r\\n    border-color: var(--leis-info-bd-hv-cl)\\r\\n}\\r\\n\\r\\n.leis-btn-info:focus,\\r\\n.leis-btn-info.focus,\\r\\n.leis-dropBtn-info:focus,\\r\\n.leis-dropBtn-info.focus {\\r\\n    -webkit-box-shadow: var(--leis-info-focus-bx-sh);\\r\\n    -o-box-shadow: var(--leis-info-focus-bx-sh);\\r\\n    box-shadow: var(--leis-info-focus-bx-sh);\\r\\n}\\r\\n\\r\\n.leis-btn-light,\\r\\n.leis-dropBtn-light {\\r\\n    background-color: var(--leis-light-cl);\\r\\n    color: black !important;\\r\\n    border-radius: 6px;\\r\\n    border-width: 0.5px;\\r\\n    border-color: var(--leis-light-bd-cl);\\r\\n}\\r\\n\\r\\n.leis-btn-light:hover,\\r\\n.leis-dropBtn-light:hover {\\r\\n    background-color: var(--leis-light-hover-cl);\\r\\n    border-color: var(--leis-light-bd-hv-cl)\\r\\n}\\r\\n\\r\\n.leis-btn-light:focus,\\r\\n.leis-btn-light.focus,\\r\\n.leis-dropBtn-light:focus,\\r\\n.leis-dropBtn-light.focus {\\r\\n    -webkit-box-shadow: var(--leis-light-focus-bx-sh);\\r\\n    -o-box-shadow: var(--leis-light-focus-bx-sh);\\r\\n    box-shadow: var(--leis-light-focus-bx-sh);\\r\\n}\\r\\n\\r\\n.leis-btn-dark,\\r\\n.leis-dropBtn-dark {\\r\\n    background-color: var(--leis-dark-cl);\\r\\n    color: #ddd !important;\\r\\n    border-radius: 6px;\\r\\n    border-width: 0.5px;\\r\\n    border-color: var(--leis-dark-bd-cl);\\r\\n}\\r\\n\\r\\n.leis-btn-dark:hover,\\r\\n.leis-dropBtn-dark:hover {\\r\\n    background-color: var(--leis-dark-hover-cl);\\r\\n    border-color: var(--leis-dark-bd-hv-cl)\\r\\n}\\r\\n\\r\\n.leis-btn-dark:focus,\\r\\n.leis-btn-dark.focus,\\r\\n.leis-dropBtn-dark:focus {\\r\\n    -webkit-box-shadow: var(--leis-dark-focus-bx-sh);\\r\\n    -o-box-shadow: var(--leis-dark-focus-bx-sh);\\r\\n    box-shadow: var(--leis-dark-focus-bx-sh);\\r\\n}\\r\\n\\r\\n.leis-outline-btn-primary {\\r\\n    border-color: var(--leis-primary-cl);\\r\\n    background-color: transparent !important;\\r\\n    color: var(--leis-primary-cl) !important;\\r\\n    -webkit-box-shadow: var(--leis-primary-cl) 0 0 2px inset;\\r\\n    box-shadow: var(--leis-primary-cl) 0 0 2px inset;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-primary:hover,\\r\\n.leis-outline-btn-primary.focus,\\r\\n.leis-outline-btn-primary:focus {\\r\\n    color: #fff !important;\\r\\n    background-color: var(--leis-primary-cl) !important;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-secondary {\\r\\n    border-color: var(--leis-secondary-cl);\\r\\n    background-color: transparent !important;\\r\\n    color: var(--leis-secondary-cl) !important;\\r\\n    -webkit-box-shadow: var(--leis-secondary-cl) 0 0 3px inset;\\r\\n    box-shadow: var(--leis-secondary-cl) 0 0 2px inset;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-secondary:hover,\\r\\n.leis-outline-btn-secondary.focus,\\r\\n.leis-outline-btn-secondary:focus {\\r\\n    color: #fff !important;\\r\\n    background-color: var(--leis-secondary-cl) !important;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-dark {\\r\\n    border-color: var(--leis-dark-cl);\\r\\n    background-color: transparent !important;\\r\\n    color: #9c9999 !important;\\r\\n    -webkit-box-shadow: var(--leis-dark-cl) 0 0 3px inset;\\r\\n    box-shadow: var(--leis-dark-cl) 0 0 2px inset;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-dark:hover,\\r\\n.leis-outline-btn-dark.focus,\\r\\n.leis-outline-btn-dark:focus {\\r\\n    color: #fff !important;\\r\\n    background-color: var(--leis-dark-cl) !important;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-light {\\r\\n    border-color: var(--leis-light-cl);\\r\\n    background-color: transparent !important;\\r\\n    color: var(--leis-primary-bd-hv-cl) !important;\\r\\n    -webkit-box-shadow: #ccc 0 0 3px inset;\\r\\n    box-shadow: #ccc 0 0 2px inset;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-light:hover,\\r\\n.leis-outline-btn-light.focus,\\r\\n.leis-outline-btn-light:focus {\\r\\n    color: var(--leis-primary-bd-hv-cl) !important;\\r\\n    background-color: var(--leis-light-cl) !important;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-success {\\r\\n    border-color: var(--leis-success-cl);\\r\\n    background-color: transparent !important;\\r\\n    color: var(--leis-success-cl) !important;\\r\\n    -webkit-box-shadow: var(--leis-success-cl) 0 0 3px inset;\\r\\n    box-shadow: var(--leis-success-cl) 0 0 2px inset;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-success:hover,\\r\\n.leis-outline-btn-success.focus,\\r\\n.leis-outline-btn-success:focus {\\r\\n    color: #fff !important;\\r\\n    background-color: var(--leis-success-cl) !important;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-info {\\r\\n    border-color: var(--leis-info-cl);\\r\\n    background-color: transparent !important;\\r\\n    color: var(--leis-info-hover-cl) !important;\\r\\n    -webkit-box-shadow: var(--leis-info-cl) 0 0 3px inset;\\r\\n    box-shadow: var(--leis-info-cl) 0 0 2px inset;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-info:hover,\\r\\n.leis-outline-btn-info.focus,\\r\\n.leis-outline-btn-info:focus {\\r\\n    color: black !important;\\r\\n    background-color: var(--leis-info-cl) !important;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-warning {\\r\\n    border-color: var(--leis-warning-cl);\\r\\n    background-color: transparent !important;\\r\\n    color: var(--leis-warning-cl) !important;\\r\\n    -webkit-box-shadow: var(--leis-warning-cl) 0 0 3px inset;\\r\\n    box-shadow: var(--leis-warning-cl) 0 0 2px inset;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-warning:hover,\\r\\n.leis-outline-btn-warning.focus,\\r\\n.leis-outline-btn-warning:focus {\\r\\n    color: black !important;\\r\\n    background-color: var(--leis-warning-cl) !important;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-danger {\\r\\n    border-color: var(--leis-danger-cl);\\r\\n    background-color: transparent !important;\\r\\n    color: var(--leis-danger-cl) !important;\\r\\n    -webkit-box-shadow: var(--leis-danger-cl) 0 0 3px inset;\\r\\n    box-shadow: var(--leis-danger-cl) 0 0 2px inset;\\r\\n}\\r\\n\\r\\n.leis-outline-btn-danger:hover,\\r\\n.leis-outline-btn-danger.focus,\\r\\n.leis-outline-btn-danger:focus {\\r\\n    color: #fff !important;\\r\\n    background-color: var(--leis-danger-cl) !important;\\r\\n}\\r\\n\\r\\n.leis-btn.leis-btn-small,\\r\\n.leis-btn-primary.leis-btn-small,\\r\\n.leis-btn-secondary.leis-btn-small,\\r\\n.leis-btn-success.leis-btn-small,\\r\\n.leis-btn-info.leis-btn-small,\\r\\n.leis-btn-danger.leis-btn-small,\\r\\n.leis-btn-warning.leis-btn-small,\\r\\n.leis-btn-light.leis-btn-small,\\r\\n.leis-btn-dark.leis-btn-small {\\r\\n    padding: 2px 10px;\\r\\n    font-size: 1rem;\\r\\n}\\r\\n\\r\\n.leis-btn.leis-btn-large,\\r\\n.leis-btn-primary.leis-btn-large,\\r\\n.leis-btn-secondary.leis-btn-large,\\r\\n.leis-btn-success.leis-btn-large,\\r\\n.leis-btn-info.leis-btn-large,\\r\\n.leis-btn-danger.leis-btn-large,\\r\\n.leis-btn-warning.leis-btn-large,\\r\\n.leis-btn-light.leis-btn-large,\\r\\n.leis-btn-dark.leis-btn-large {\\r\\n    padding: 0.555rem 16px;\\r\\n    font-size: 1.22rem;\\r\\n    font-weight: inherit;\\r\\n    min-width: 140px;\\r\\n}\\r\\n\\r\\n.leis-btn-icon {\\r\\n    font-size: inherit;\\r\\n    color: inherit;\\r\\n    font-weight: inherit;\\r\\n}\\r\\n\\r\\n.leis-btn-w-icon {\\r\\n    display: flex;\\r\\n    gap: 0.5rem;\\r\\n}\\r\\n\\r\\n/* lines */\\r\\n\\r\\n.leis-line-h {\\r\\n    height: 0.5px;\\r\\n    outline: none;\\r\\n    border: none;\\r\\n    background-color: var(--leis-line-separator-cl);\\r\\n}\\r\\n\\r\\n/* cards */\\r\\n\\r\\n.leis-card,\\r\\n.leis-card-sms,\\r\\n.leis-dropdown,\\r\\n.leis-dropdown-content,\\r\\n.leis-alert-card,\\r\\n.leis-slideshow-container {\\r\\n    position: relative;\\r\\n    display: -webkit-box;\\r\\n    display: -ms-flexbox;\\r\\n    display: flex;\\r\\n    -webkit-box-orient: vertical;\\r\\n    -webkit-box-direction: normal;\\r\\n    -ms-flex-direction: column;\\r\\n    flex-direction: column;\\r\\n    min-width: 0;\\r\\n    word-wrap: break-word;\\r\\n    background-color: #fff;\\r\\n    background-clip: border-box;\\r\\n    border: var(--leis-card-bd);\\r\\n    border-radius: 6px;\\r\\n    -webkit-box-shadow: var(--leis-card-bx-sh);\\r\\n    box-shadow: var(--leis-card-bx-sh);\\r\\n    margin-bottom: 0.5em;\\r\\n}\\r\\n\\r\\n\\r\\n.leis-card .leis-img-card {\\r\\n    max-height: calc(80vh - 7rem);\\r\\n}\\r\\n\\r\\n.leis-card.boxSh-off {\\r\\n    -webkit-box-shadow: none;\\r\\n    box-shadow: none;\\r\\n}\\r\\n\\r\\n.leis-card-body {\\r\\n    -webkit-box-flex: 1;\\r\\n    -ms-flex: 1 1 auto;\\r\\n    flex: 1 1 auto;\\r\\n    padding: 1.25rem;\\r\\n}\\r\\n\\r\\n.leis-card-title {\\r\\n    margin-bottom: 0.75rem;\\r\\n    -webkit-white-space: nowrap;\\r\\n    -ms-white-space: nowrap;\\r\\n    white-space: nowrap;\\r\\n}\\r\\n\\r\\n.leis-card-subtitle {\\r\\n    margin-top: -0.375rem;\\r\\n    margin-bottom: 0.5px;\\r\\n    font-weight: 100;\\r\\n    line-height: 1.2;\\r\\n    color: var(--leis-subtitle-cl);\\r\\n}\\r\\n\\r\\n.leis-card-header {\\r\\n    padding: 0.75rem 1.25rem;\\r\\n    margin-bottom: 0;\\r\\n    background-color: rgba(0, 0, 0, 0.03);\\r\\n    border-bottom: 1px solid rgba(0, 0, 0, 0.125);\\r\\n}\\r\\n\\r\\n.leis-card-text {\\r\\n    font-size: 15.5px;\\r\\n    font-family: 'Poppins-Regular' system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu,\\r\\n        Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;\\r\\n    -webkit-white-space: nowrap;\\r\\n    word-wrap: break-word;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-card-footer {\\r\\n    padding: 0.5rem 1.25rem;\\r\\n    background-color: rgba(0, 0, 0, 0.03);\\r\\n    border-top: 1px solid rgba(0, 0, 0, 0.125);\\r\\n}\\r\\n\\r\\n\\r\\n.leis-card-img {\\r\\n    width: 100%;\\r\\n    height: auto;\\r\\n    border-radius: calc(6px - 1px);\\r\\n}\\r\\n\\r\\n.leis-card-img-top {\\r\\n    width: 100%;\\r\\n    height: auto;\\r\\n    border-top-left-radius: calc(6px - 1px);\\r\\n    border-top-right-radius: calc(6px - 1px);\\r\\n}\\r\\n\\r\\n.leis-card-img-bottom {\\r\\n    width: 100%;\\r\\n    border-bottom-right-radius: calc(0.25rem - 1px);\\r\\n    border-bottom-left-radius: calc(0.25rem - 1px);\\r\\n}\\r\\n\\r\\n.leis-card-sms {\\r\\n    padding: 4.5px;\\r\\n    -webkit-box-shadow: var(--leis-card-sms-bx-sh);\\r\\n    box-shadow: var(--leis-card-sms-bx-sh);\\r\\n    border: var(--leis-card-bd)\\r\\n}\\r\\n\\r\\n.leis-img {\\r\\n    display: block;\\r\\n    width: 100%;\\r\\n    height: auto;\\r\\n}\\r\\n\\r\\n.leis-cover-pic-card {\\r\\n    display: block;\\r\\n    overflow: hidden;\\r\\n    height: 200px;\\r\\n}\\r\\n\\r\\n.leis-cover-pic-card>.leis-img {\\r\\n    width: 100%;\\r\\n    filter: var(--leis-effect-img);\\r\\n}\\r\\n\\r\\n.leis-img-card {\\r\\n    position: relative;\\r\\n    min-width: 0;\\r\\n    overflow: hidden;\\r\\n    border: none;\\r\\n    outline: none;\\r\\n    outline: none;\\r\\n}\\r\\n\\r\\n.leis-cover-pic-card+.leis-img-card {\\r\\n    position: relative;\\r\\n    width: 200px !important;\\r\\n    height: 200px !important;\\r\\n    overflow: hidden !important;\\r\\n    border-radius: 50% !important;\\r\\n    outline: 3.5px solid var(--leis-img-outline-cl);\\r\\n}\\r\\n\\r\\n.leis-img-card>.leis-img {\\r\\n    display: block;\\r\\n    width: 100%;\\r\\n    height: auto;\\r\\n    min-height: 200px !important;\\r\\n    filter: var(--leis-effect-img);\\r\\n}\\r\\n\\r\\n.leis-cover-pic-card+.leis-img-card {\\r\\n    position: absolute;\\r\\n    top: calc(200px - 7rem);\\r\\n    left: 5%;\\r\\n}\\r\\n\\r\\n/* .leis-img-card+.leis-card-title,\\r\\n.leis-img-card+.leis-card-body {\\r\\n    margin-top: 6.5rem;\\r\\n\\r\\n} */\\r\\n\\r\\n.leis-img-card+.leis-card-title,\\r\\n.leis-card-title+.leis-card-subtitle {\\r\\n    position: relative;\\r\\n    left: 5%;\\r\\n    width: 50%;\\r\\n}\\r\\n\\r\\n.leis-card-btn-cd {\\r\\n    width: 100%;\\r\\n}\\r\\n\\r\\n.leis-card-btn-cd>[class*=\\"btn\\"] {\\r\\n    border: none;\\r\\n    outline: none;\\r\\n}\\r\\n\\r\\n.leis-card-btn-cd>.leis-btn-light {\\r\\n    background-color: var(--leis-light-hover-cl);\\r\\n}\\r\\n\\r\\n.leis-card-btn-cd>.leis-btn-light:hover {\\r\\n    color: var(--leis-primary-cl) !important;\\r\\n}\\r\\n\\r\\n.leis-card-body>.leis-card-btn-cd {\\r\\n    border: none;\\r\\n    outline: none;\\r\\n    padding-bottom: 6px;\\r\\n}\\r\\n\\r\\n.leis-card-btn-cd+[class=\\"leis-line-h\\"] {\\r\\n    margin: 14px 0px;\\r\\n}\\r\\n\\r\\n/* calendar*/\\r\\n.leis-calendar-container {\\r\\n    position: relative;\\r\\n    width: 350px;\\r\\n    min-height: 350px;\\r\\n\\r\\n    padding: 0.5rem 0.5rem;\\r\\n    padding-top: 1rem;\\r\\n    margin: 0;\\r\\n    outline: none;\\r\\n    border: 1px solid #ddd;\\r\\n    background-color: #fff;\\r\\n    border-radius: 6px;\\r\\n    -webkit-box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);\\r\\n    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);\\r\\n}\\r\\n\\r\\n.leis-calendar {\\r\\n    position: relative;\\r\\n    left: -2px;\\r\\n    width: 100%;\\r\\n    padding: 0;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-date {\\r\\n    text-align: center;\\r\\n    font-size: inherit;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-date p {\\r\\n    width: 40px;\\r\\n    padding: 0.5rem 0;\\r\\n    border-radius: 5px;\\r\\n    font-weight: 500;\\r\\n    cursor: pointer;\\r\\n}\\r\\n\\r\\n.leis-date p.active {\\r\\n    background-color: #b9d6fcb2;\\r\\n}\\r\\n\\r\\n.leis-date p:hover {\\r\\n    background-color: #7f8d9e4d\\r\\n}\\r\\n\\r\\n.leis-date.active {\\r\\n    background-color: transparent;\\r\\n    color: inherit;\\r\\n}\\r\\n\\r\\n.leis-date.active.today p {\\r\\n    background-color: transparent;\\r\\n    color: inherit;\\r\\n    border: 2px solid rgba(255, 46, 46, 0.743);\\r\\n}\\r\\n\\r\\n.leis-calendar-day {\\r\\n    font-weight: 400;\\r\\n    text-align: left;\\r\\n}\\r\\n\\r\\n.leis-year-info {\\r\\n    position: relative;\\r\\n    margin-bottom: 1.5rem;\\r\\n    width: 100%;\\r\\n    display: flex;\\r\\n    justify-content: center;\\r\\n    align-content: flex-start;\\r\\n    gap: 0.5rem;\\r\\n    font-weight: 500;\\r\\n}\\r\\n\\r\\n.leis-date.today p {\\r\\n    background-color: rgba(255, 46, 46, 0.743);\\r\\n    color: #fff;\\r\\n    border-radius: 6px;\\r\\n}\\r\\n\\r\\n.calendar-next,\\r\\n.calendar-prev {\\r\\n    position: absolute;\\r\\n    top: 5px;\\r\\n    z-index: 1;\\r\\n    font-weight: 500;\\r\\n    outline: none;\\r\\n    border: none;\\r\\n    background-color: inherit;\\r\\n    color: inherit;\\r\\n    padding: 0.2rem 0.5rem;\\r\\n    cursor: pointer;\\r\\n}\\r\\n\\r\\n.calendar-next:hover,\\r\\n.calendar-prev:hover {\\r\\n    color: #0062cc;\\r\\n}\\r\\n\\r\\n.calendar-next {\\r\\n    right: 6px;\\r\\n}\\r\\n\\r\\n.calendar-prev {\\r\\n    left: 6px;\\r\\n}\\r\\n\\r\\n.leis-calendar-cover {\\r\\n    position: relative;\\r\\n    width: -moz-fit-content;\\r\\n    width: fit-content;\\r\\n    overflow: hidden;\\r\\n\\r\\n}\\r\\n\\r\\n/*\\r\\ncustom calendar\\r\\n*/\\r\\n\\r\\n.custom-calendar-container {\\r\\n    position: relative;\\r\\n    width: 320px;\\r\\n    height: auto;\\r\\n    overflow: hidden;\\r\\n    border: none;\\r\\n    outline: none;\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n    -webkit-user-select: none;\\r\\n    user-select: none;\\r\\n\\r\\n    background-color: inherit;\\r\\n\\r\\n}\\r\\n\\r\\n.custom-calendar-card {\\r\\n    position: relative;\\r\\n    width: 100%;\\r\\n    overflow: hidden;\\r\\n    border: 1px solid #ccc;\\r\\n    border-radius: 6px;\\r\\n    background-color: #fff;\\r\\n    padding: 1rem 0.5rem;\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n.custom-Date,\\r\\n.daysOff,\\r\\n.custom-header Div {\\r\\n    border: none;\\r\\n    outline: none;\\r\\n    width: 50px;\\r\\n    padding: 8px 5px;\\r\\n    border-radius: 5px;\\r\\n    font-weight: 500;\\r\\n    color: inherit;\\r\\n}\\r\\n\\r\\n.custom-Date {\\r\\n    cursor: pointer;\\r\\n}\\r\\n\\r\\n.custom-Date.active-date {\\r\\n    background-color: #287be9;\\r\\n    color: #fff;\\r\\n}\\r\\n\\r\\n.custom-Date:hover {\\r\\n    background-color: #abc9f0a4;\\r\\n}\\r\\n\\r\\n.custom-Date,\\r\\n.daysOff {\\r\\n    background-color: #ffffffa8;\\r\\n}\\r\\n\\r\\n.daysOff {\\r\\n    pointer-events: none;\\r\\n    color: #a39999;\\r\\n    opacity: 0.5;\\r\\n}\\r\\n\\r\\n.custom-body {\\r\\n    padding: 0;\\r\\n    width: 100%;\\r\\n    gap: 3px;\\r\\n    overflow: hidden;\\r\\n}\\r\\n\\r\\n.custom-row,\\r\\n.custom-header {\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n    gap: 3px;\\r\\n\\r\\n}\\r\\n\\r\\n.custom-header Div {\\r\\n    font-weight: 400;\\r\\n}\\r\\n\\r\\n.custom-yearinfo {\\r\\n    width: 100%;\\r\\n    gap: 0.5rem;\\r\\n    justify-content: center;\\r\\n    font-weight: 500;\\r\\n}\\r\\n\\r\\n/* inputs*/\\r\\n\\r\\n.leis-card-radioBtns-container,\\r\\n.leis-card-checkboxBtns-container,\\r\\n.leis-card-switchboxBtns-container {\\r\\n    position: relative;\\r\\n    width: 100%;\\r\\n    display: flex;\\r\\n    flex-direction: column;\\r\\n    flex-wrap: wrap;\\r\\n    margin-bottom: 0.2rem;\\r\\n    gap: 0.255rem;\\r\\n}\\r\\n\\r\\n.leis-card-radioBtns-container *>label,\\r\\n.leis-card-checkboxBtns-container *>label,\\r\\n.leis-card-switchboxBtns-container *>label,\\r\\n.leis-textboxinput-container *>label {\\r\\n    font-size: inherit;\\r\\n    font-weight: inherit;\\r\\n}\\r\\n\\r\\n.leis-radioBtns-card,\\r\\n.leis-checkboxBtns-card,\\r\\n.leis-switchboxBtns-card {\\r\\n    position: relative;\\r\\n    width: auto;\\r\\n    display: flex;\\r\\n    flex-direction: row;\\r\\n    text-overflow: ellipsis;\\r\\n    justify-content: start;\\r\\n    flex-wrap: wrap;\\r\\n    gap: 0.255rem;\\r\\n}\\r\\n\\r\\n.leis-radioBtn,\\r\\n.leis-checkboxtBtn,\\r\\n.leis-switchboxtBtn {\\r\\n    appearance: none;\\r\\n    font-size: inherit;\\r\\n    font-weight: inherit;\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n.leis-radioBtn::after,\\r\\n.leis-checkboxtBtn,\\r\\n.leis-switchboxtBtn {\\r\\n    display: inline-block;\\r\\n    content: \\"\\";\\r\\n    width: 15px;\\r\\n    height: 15px;\\r\\n    background-color: inherit;\\r\\n    border-radius: 50%;\\r\\n    border: 1px solid #aaa;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-checkboxtBtn {\\r\\n    top: 5px;\\r\\n    border: 1px solid #aaa;\\r\\n    outline: none;\\r\\n    border-radius: 0.222em;\\r\\n}\\r\\n\\r\\n.leis-switchboxtBtn {\\r\\n    top: 7px;\\r\\n    height: 15px;\\r\\n    width: 30px;\\r\\n    outline: none;\\r\\n    border-radius: 7px;\\r\\n}\\r\\n\\r\\n.leis-switchboxtBtn::after {\\r\\n    content: \\"\\";\\r\\n    display: inline-block;\\r\\n    position: absolute;\\r\\n    width: 10px;\\r\\n    height: 10px;\\r\\n    top: 15%;\\r\\n    left: 8%;\\r\\n    border-radius: 50%;\\r\\n    background-color: #aaa;\\r\\n    transition: left .3s ease;\\r\\n}\\r\\n\\r\\n.leis-checkboxtBtn:checked,\\r\\n.leis-switchboxtBtn:checked {\\r\\n    outline: none;\\r\\n    background-color: #007bff;\\r\\n    filter: brightness(100%);\\r\\n}\\r\\n\\r\\n.leis-switchboxtBtn:checked::after {\\r\\n    left: 52%;\\r\\n    background-color: #fff;\\r\\n}\\r\\n\\r\\n.leis-checkboxtBtn:focus,\\r\\n.leis-switchboxtBtn:focus {\\r\\n    box-shadow: 0 0 0 .25rem rgba(13, 110, 253, .25);\\r\\n}\\r\\n\\r\\n.leis-checkboxtBtn:checked::after {\\r\\n    content: \\"\\";\\r\\n    display: inline-block;\\r\\n    position: absolute;\\r\\n    width: 8px;\\r\\n    height: 5px;\\r\\n    left: calc(50% - 5px);\\r\\n    top: 20%;\\r\\n    border-left: 2px solid #fff;\\r\\n    border-bottom: 2px solid #fff;\\r\\n    transform: rotateZ(-60deg);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-radioBtn:checked::after {\\r\\n    border: 0.333em solid #007bff;\\r\\n    filter: brightness(100%);\\r\\n}\\r\\n\\r\\n.leis-radioBtn:focus::after {\\r\\n    outline: none;\\r\\n    box-shadow: 0 0 0 .25rem rgba(13, 110, 253, .25)\\r\\n}\\r\\n\\r\\n\\r\\n.leis-textboxinput-container {\\r\\n    width: 100%;\\r\\n    height: auto;\\r\\n    padding: none;\\r\\n    margin: 0;\\r\\n    margin-bottom: 0.2rem;\\r\\n    padding-top: 0.5rem;\\r\\n}\\r\\n\\r\\n.leis-textbox-card {\\r\\n    position: relative;\\r\\n    width: 100%;\\r\\n    display: flex;\\r\\n    flex-direction: row-reverse;\\r\\n    justify-content: start;\\r\\n    flex-wrap: wrap-reverse;\\r\\n    gap: 0.5rem;\\r\\n    margin-bottom: 0.5rem;\\r\\n}\\r\\n\\r\\n.leis-textbox-card label {\\r\\n    display: flex;\\r\\n    justify-content: start;\\r\\n    align-content: center;\\r\\n}\\r\\n\\r\\n\\r\\n/* leis group button*/\\r\\n\\r\\n.leis-groupBtn-container {\\r\\n    width: -moz-fit-content;\\r\\n    width: fit-content;\\r\\n    position: relative;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card,\\r\\n.leis-groupBtn-card.dark-group {\\r\\n    width: 100%;\\r\\n    padding: 5px 5px;\\r\\n    background-color: #2b3a49dc;\\r\\n    display: flex;\\r\\n    flex-direction: row;\\r\\n    flex-wrap: wrap;\\r\\n    gap: 0.255rem;\\r\\n    color: rgb(235, 225, 225);\\r\\n    border-radius: 6px;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-item {\\r\\n    border-radius: none;\\r\\n    padding: 0 8px;\\r\\n    background-color: inherit;\\r\\n    font-size: inherit;\\r\\n    color: inherit;\\r\\n    outline: none;\\r\\n    border: none;\\r\\n    cursor: pointer;\\r\\n    border-radius: 4px;\\r\\n    white-space: nowrap;\\r\\n    -webkit-user-select: none;\\r\\n    user-select: none;\\r\\n    transition: .3s ease;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-item:hover,\\r\\n.leis-groupBtn-item.dark-group .leis-groupBtn-item:hover {\\r\\n    background-color: #6e6d6d;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-item:focus,\\r\\n.leis-groupBtn-item.dark-group .leis-groupBtn-item:focus {\\r\\n    background-color: #fff;\\r\\n    background-color: #969292;\\r\\n    box-shadow: 0 0px 0px 2px rgba(0, 0, 0, 0.136);\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.light-group {\\r\\n    background-color: var(--leis-light-cl);\\r\\n    color: #000;\\r\\n    border: 1px solid #ddddddb5;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.light-group .leis-groupBtn-item:not(:last-child) {\\r\\n    border-right: 1px solid #ddddddad;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.light-group .leis-groupBtn-item:hover {\\r\\n    background-color: #e1dadaca;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.light-group .leis-groupBtn-item:focus {\\r\\n    background-color: #e1dadab9;\\r\\n    box-shadow: 0 0px 0px 2px rgba(0, 0, 0, 0.136);\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n.leis-groupBtn-card.secondary-group {\\r\\n    background-color: var(--leis-secondary-hover-cl);\\r\\n    color: rgb(235, 225, 225);\\r\\n    border: 1px solid #ddddddb5;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.secondary-group .leis-groupBtn-item:not(:last-child) {\\r\\n    border-right: 1px solid #bebcbcdf;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.secondary-group .leis-groupBtn-item:hover {\\r\\n    background-color: rgb(183, 179, 179);\\r\\n    color: #fff;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.secondary-group .leis-groupBtn-item:focus {\\r\\n    background-color: rgb(183, 179, 179);\\r\\n    color: #fff;\\r\\n    box-shadow: 0 0px 0px 2px rgba(0, 0, 0, 0.136);\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n.leis-groupBtn-card.primary-group {\\r\\n    background-color: var(--leis-primary-hover-cl);\\r\\n    color: rgb(235, 225, 225);\\r\\n    border: 1px solid #ddddddb5;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.primary-group .leis-groupBtn-item:not(:last-child) {\\r\\n    border-right: 1px solid #bebcbcdf;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.primary-group .leis-groupBtn-item:hover {\\r\\n    background-color: #4f8dd0;\\r\\n    color: #fff;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.primary-group .leis-groupBtn-item:focus {\\r\\n    background-color: #4f8dd0;\\r\\n    color: #fff;\\r\\n    box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.136);\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.success-group {\\r\\n    background-color: var(--leis-success-hover-cl);\\r\\n    color: #fff;\\r\\n    border: 1px solid #70d988;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.success-group .leis-groupBtn-item:not(:last-child) {\\r\\n    border-right: 1px solid #70d988;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.success-group .leis-groupBtn-item:hover {\\r\\n    background-color: #8deba2c4;\\r\\n    color: #000;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.success-group .leis-groupBtn-item:focus {\\r\\n    background-color: #8deba2c4;\\r\\n    color: #000;\\r\\n    box-shadow: 0 0px 0px 2px rgba(0, 0, 0, 0.136);\\r\\n}\\r\\n\\r\\n\\r\\n.leis-groupBtn-card.warning-group {\\r\\n    background-color: hsla(45, 95%, 66%, 0.939);\\r\\n    color: #000;\\r\\n    border: 1px solid hsla(45, 95%, 66%, 0.939);\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.warning-group .leis-groupBtn-item:not(:last-child) {\\r\\n    border-right: 1px solid hsl(45, 64%, 82%);\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.warning-group .leis-groupBtn-item:hover {\\r\\n    background-color: hsla(45, 84%, 42%, 0.939);\\r\\n    color: #fff;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.warning-group .leis-groupBtn-item:focus {\\r\\n    background-color: hsla(45, 84%, 42%, 0.939);\\r\\n    color: #fff;\\r\\n    box-shadow: 0 0px 0px 2px rgba(0, 0, 0, 0.136);\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.info-group {\\r\\n    background-color: #a6eaf5e9;\\r\\n    color: #000;\\r\\n    border: 1px solid #a6eaf5e9;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.info-group .leis-groupBtn-item:not(:last-child) {\\r\\n    border-right: 1px solid #a6eaf5e9;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.info-group .leis-groupBtn-item:hover {\\r\\n    background-color: #589faad1;\\r\\n    color: #fff;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.info-group .leis-groupBtn-item:focus {\\r\\n    background-color: #589faad1;\\r\\n    color: #fff;\\r\\n    box-shadow: 0 0px 0px 2px rgba(0, 0, 0, 0.136);\\r\\n}\\r\\n\\r\\n\\r\\n.leis-groupBtn-card.danger-group {\\r\\n    background-color: #cf5662db;\\r\\n    color: #fff;\\r\\n    border: 1px solid #cf5662db;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.danger-group .leis-groupBtn-item:not(:last-child) {\\r\\n    border-right: 1px solid #ddb2b6;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.danger-group .leis-groupBtn-item:hover {\\r\\n    background-color: #a6464edb;\\r\\n    color: #fff;\\r\\n}\\r\\n\\r\\n.leis-groupBtn-card.danger-group .leis-groupBtn-item:focus {\\r\\n    background-color: #a6464edb;\\r\\n    color: #fff;\\r\\n    box-shadow: 0 0px 0px 2px rgba(0, 0, 0, 0.136);\\r\\n}\\r\\n\\r\\n/* Modal */\\r\\n\\r\\n.leis-modal-container {\\r\\n    display: none;\\r\\n    position: fixed;\\r\\n    top: 0;\\r\\n    left: 0;\\r\\n    width: 100%;\\r\\n    height: 100%;\\r\\n    background-color: hsla(0, 2%, 8%, 0.372);\\r\\n    overflow-x: hidden;\\r\\n    outline: 0;\\r\\n    z-index: 1000;\\r\\n}\\r\\n\\r\\n.leis-modal-dialog {\\r\\n    position: absolute;\\r\\n    top: 25%;\\r\\n    left: 50%;\\r\\n    padding: 0.5rem;\\r\\n    background-clip: padding-box;\\r\\n    background-color: #fff;\\r\\n    border: 1px solid rgba(255, 255, 255, 0.15);\\r\\n    border-radius: 0.5rem;\\r\\n    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);\\r\\n    outline: none;\\r\\n    animation: modal .3s ease;\\r\\n    width: 500px;\\r\\n    min-height: 250px;\\r\\n    height: 250px;\\r\\n\\r\\n\\r\\n}\\r\\n\\r\\n.modal-transform {\\r\\n    transform: translate(-50%, -25%);\\r\\n}\\r\\n\\r\\n.leis-modal-content {\\r\\n    width: 100%;\\r\\n    height: 100%;\\r\\n    padding: 10px 0;\\r\\n    position: relative;\\r\\n    background-color: inherit;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-modal-container.show .leis-modal-dialog {\\r\\n    top: 25%;\\r\\n    transition: 1s ease;\\r\\n}\\r\\n\\r\\n.leis-modal-header {\\r\\n    display: flex;\\r\\n    flex-shrink: 0;\\r\\n    align-items: center;\\r\\n    justify-content: space-between;\\r\\n    border-bottom: 1px solid var(--leis-line-separator-cl);\\r\\n}\\r\\n\\r\\n.leis-modal-header .leis-modal-title {\\r\\n    padding: 5px 10px;\\r\\n}\\r\\n\\r\\n.leis-modal-header .leis-btn-close {\\r\\n    border: none;\\r\\n    font-size: 2rem;\\r\\n    top: -0.5rem;\\r\\n    color: #999;\\r\\n}\\r\\n\\r\\n.leis-modal-header .leis-btn-close:hover {\\r\\n    color: #000;\\r\\n}\\r\\n\\r\\n.leis-modal-body {\\r\\n    position: relative;\\r\\n    margin-left: 7px;\\r\\n    width: 100%;\\r\\n    height: calc(100% - 6rem - 4px);\\r\\n    position: relative;\\r\\n    overflow: hidden;\\r\\n    overflow-x: hidden;\\r\\n    overflow-y: auto;\\r\\n}\\r\\n\\r\\n.leis-modal-footer {\\r\\n    padding: 10px;\\r\\n    width: 100%;\\r\\n    position: absolute;\\r\\n    bottom: 0;\\r\\n    left: 0;\\r\\n    padding: 0;\\r\\n}\\r\\n\\r\\n.leis-modal-footer-card {\\r\\n    position: relative;\\r\\n\\r\\n    display: flex;\\r\\n    flex-shrink: 0;\\r\\n    flex-wrap: wrap;\\r\\n    align-items: center;\\r\\n    justify-content: flex-end;\\r\\n    padding: 0.6rem 1rem;\\r\\n    border-top: 1px solid var(--leis-line-separator-cl);\\r\\n    gap: 0.5rem;\\r\\n\\r\\n\\r\\n}\\r\\n\\r\\n.leis-modal-dafault {\\r\\n    padding: 3% 8%;\\r\\n}\\r\\n\\r\\n.leis-modal-dafault .leis-tooltip.bottom {\\r\\n    top: 80%;\\r\\n    left: 10%;\\r\\n}\\r\\n\\r\\n@keyframes modal {\\r\\n    from {\\r\\n        opacity: 0.1;\\r\\n        top: -320px;\\r\\n\\r\\n\\r\\n    }\\r\\n\\r\\n    top {\\r\\n        opacity: 1;\\r\\n        top: 25%;\\r\\n    }\\r\\n}\\r\\n\\r\\n@keyframes modal-zoom-in {\\r\\n    from {\\r\\n        opacity: 0.1;\\r\\n        transform: scale(2.5);\\r\\n    }\\r\\n\\r\\n    top {\\r\\n        opacity: 1;\\r\\n        transform: scale(1);\\r\\n    }\\r\\n}\\r\\n\\r\\n@keyframes modal-zoom-out {\\r\\n    from {\\r\\n        opacity: 0.1;\\r\\n        transform: scale(0.2);\\r\\n\\r\\n    }\\r\\n\\r\\n    top {\\r\\n        opacity: 1;\\r\\n        transform: scale(1);\\r\\n    }\\r\\n}\\r\\n\\r\\n/* slider*/\\r\\n\\r\\n.leis-slider-container {\\r\\n    position: relative;\\r\\n    background-color: var(--leis-dark-cl);\\r\\n    color: #fff;\\r\\n    height: 100vh;\\r\\n    width: 200px;\\r\\n}\\r\\n\\r\\n.leis-slider-content {\\r\\n    width: 100%;\\r\\n}\\r\\n\\r\\n.leis-slider-slider {\\r\\n    position: absolute;\\r\\n    top: 0;\\r\\n    right: 0;\\r\\n    background-color: inherit;\\r\\n    height: inherit;\\r\\n    width: 8px;\\r\\n    cursor: w-resize;\\r\\n    transition: background-color 1s ease;\\r\\n}\\r\\n\\r\\n.leis-slider-slider:hover {\\r\\n    background-color: #0069d9;\\r\\n\\r\\n}\\r\\n\\r\\n/* alerts*/\\r\\n\\r\\n.leis-alert-card {\\r\\n    position: relative;\\r\\n    box-shadow: none;\\r\\n    padding-right: 25px;\\r\\n}\\r\\n\\r\\n.leis-alert-card a {\\r\\n    white-space: nowrap;\\r\\n}\\r\\n\\r\\n.leis-alert-card .leis-btn-close {\\r\\n    position: absolute;\\r\\n    right: 10px;\\r\\n    top: 0px;\\r\\n    font-size: 2.5rem;\\r\\n    background-color: transparent;\\r\\n    border: none !important;\\r\\n}\\r\\n\\r\\n.leis-alert-card.leis-alert-primary {\\r\\n    background-color: #9ec8ff64;\\r\\n    border: 1.5px solid #74b0ff;\\r\\n\\r\\n\\r\\n}\\r\\n\\r\\n.leis-alert-card.leis-alert-success {\\r\\n    background-color: #96fbae6a;\\r\\n    border: 1.5px solid #51ff7abf;\\r\\n}\\r\\n\\r\\n.leis-alert-card.leis-alert-danger {\\r\\n    background-color: #fa919b77;\\r\\n    border: 1.5px solid #ff485ab2;\\r\\n}\\r\\n\\r\\n.leis-alert-card.leis-alert-info {\\r\\n    background-color: #a6f1fcae;\\r\\n    border: 1.5px solid #51a6b3a7;\\r\\n}\\r\\n\\r\\n.leis-alert-card.leis-alert-warning {\\r\\n    background-color: #ffdd7781;\\r\\n    border: 1.5px solid #ffce3ad5;\\r\\n}\\r\\n\\r\\n.leis-alert-card.leis-alert-dark {\\r\\n    background-color: #3f41437e;\\r\\n    color: rgb(250, 245, 245);\\r\\n}\\r\\n\\r\\n.leis-alert-card.leis-alert-light {\\r\\n    background-color: #fefeffb1;\\r\\n}\\r\\n\\r\\n.leis-alert-card.leis-alert-secondary {\\r\\n    background-color: #a0a1a25c;\\r\\n}\\r\\n\\r\\n.leis-alert-card .leis-alert-text {\\r\\n    padding: 16px;\\r\\n\\r\\n}\\r\\n\\r\\n/* groups */\\r\\n\\r\\n.leis-list-group,\\r\\n.leis-group,\\r\\n.leis-accordion-card {\\r\\n    display: -webkit-box;\\r\\n    display: -ms-flexbox;\\r\\n    display: flex;\\r\\n    -webkit-box-orient: vertical;\\r\\n    -webkit-box-direction: normal;\\r\\n    -ms-flex-direction: column;\\r\\n    flex-direction: column;\\r\\n    padding-left: 0;\\r\\n    margin-bottom: 0;\\r\\n}\\r\\n\\r\\n.leis-list-group {\\r\\n    list-style: none;\\r\\n}\\r\\n\\r\\n.leis-child-group {\\r\\n    padding: 2.5px 5px;\\r\\n    position: relative;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-child-group:not(:last-child) {\\r\\n    border-bottom: 0.5px solid rgb(216, 212, 212);\\r\\n}\\r\\n\\r\\n.leis-group-head {\\r\\n    background-color: rgba(230, 227, 227, 0.744);\\r\\n    border-top-left-radius: 2px;\\r\\n    border-top-right-radius: 2px;\\r\\n}\\r\\n\\r\\n.leis-img-group-left {\\r\\n    display: block;\\r\\n    float: left;\\r\\n    width: 40px;\\r\\n    height: 40px;\\r\\n    border: none;\\r\\n    outline: none;\\r\\n    border-radius: 50%;\\r\\n    overflow: hidden;\\r\\n}\\r\\n\\r\\n.leis-img-group-left>.leis-img {\\r\\n    display: block;\\r\\n    width: 100%;\\r\\n    height: auto;\\r\\n    min-height: 40px !important;\\r\\n    border: none;\\r\\n    outline: none;\\r\\n    filter: var(--leis-effect-img);\\r\\n}\\r\\n\\r\\n.leis-img-group-left~.leis-group-txt {\\r\\n    padding: 12px 14px;\\r\\n    margin-left: 2.5rem;\\r\\n}\\r\\n\\r\\n/* border */\\r\\n\\r\\n.leis-boder-1-primary {\\r\\n    border: 1px solid var(--leis-primary-cl);\\r\\n}\\r\\n\\r\\n.leis-boder-2-primary {\\r\\n    border: 2.5px solid var(--leis-primary-cl);\\r\\n}\\r\\n\\r\\n.leis-border-raduis-5 {\\r\\n    border-radius: 5px;\\r\\n}\\r\\n\\r\\n.leis-border-raduis-4 {\\r\\n    border-radius: 4px;\\r\\n}\\r\\n\\r\\n.leis-border-raduis-8 {\\r\\n    border-radius: 8px;\\r\\n}\\r\\n\\r\\n.leis-border-raduis-16 {\\r\\n    border-radius: 16px;\\r\\n}\\r\\n\\r\\n.leis-border-raduis-50p {\\r\\n    border-radius: 50%;\\r\\n}\\r\\n\\r\\n.leis-border-top-danger {\\r\\n    border-top: 7px solid var(--leis-danger-cl)\\r\\n}\\r\\n\\r\\n.leis-border-top-warning {\\r\\n    border-top: 7px solid var(--leis-warning-cl)\\r\\n}\\r\\n\\r\\n.leis-border-top-dark {\\r\\n    border-top: 7px solid var(--leis-dark-cl)\\r\\n}\\r\\n\\r\\n.leis-border-top-light {\\r\\n    border-top: 7px solid var(--leis-light-cl)\\r\\n}\\r\\n\\r\\n.leis-border-top-info {\\r\\n    border-top: 7px solid var(--leis-info-cl)\\r\\n}\\r\\n\\r\\n.leis-border-top-success {\\r\\n    border-top: 7px solid var(--leis-success-cl)\\r\\n}\\r\\n\\r\\n.leis-border-top-primary {\\r\\n    border-top: 7px solid var(--leis-primary-cl)\\r\\n}\\r\\n\\r\\n.leis-border-top-secondary {\\r\\n    border-top: 7px solid var(--leis-secondary-cl)\\r\\n}\\r\\n\\r\\n.leis-border-left-danger {\\r\\n    border-left: 7px solid var(--leis-danger-cl)\\r\\n}\\r\\n\\r\\n.leis-border-left-warning {\\r\\n    border-left: 7px solid var(--leis-warning-cl)\\r\\n}\\r\\n\\r\\n.leis-border-left-dark {\\r\\n    border-left: 7px solid var(--leis-dark-cl)\\r\\n}\\r\\n\\r\\n.leis-border-left-light {\\r\\n    border-left: 7px solid var(--leis-light-cl)\\r\\n}\\r\\n\\r\\n.leis-border-left-info {\\r\\n    border-left: 7px solid var(--leis-info-cl)\\r\\n}\\r\\n\\r\\n.leis-border-left-success {\\r\\n    border-left: 7px solid var(--leis-success-cl)\\r\\n}\\r\\n\\r\\n.leis-border-left-primary {\\r\\n    border-left: 7px solid var(--leis-primary-cl)\\r\\n}\\r\\n\\r\\n.leis-border-left-secondary {\\r\\n    border-left: 7px solid var(--leis-secondary-cl)\\r\\n}\\r\\n\\r\\n.leis-border-right-danger {\\r\\n    border-right: 7px solid var(--leis-danger-cl)\\r\\n}\\r\\n\\r\\n.leis-border-right-warning {\\r\\n    border-right: 7px solid var(--leis-warning-cl)\\r\\n}\\r\\n\\r\\n.leis-border-right-dark {\\r\\n    border-right: 7px solid var(--leis-dark-cl)\\r\\n}\\r\\n\\r\\n.leis-border-right-light {\\r\\n    border-right: 7px solid var(--leis-light-cl)\\r\\n}\\r\\n\\r\\n.leis-border-right-info {\\r\\n    border-right: 7px solid var(--leis-info-cl)\\r\\n}\\r\\n\\r\\n.leis-border-right-success {\\r\\n    border-right: 7px solid var(--leis-success-cl)\\r\\n}\\r\\n\\r\\n.leis-border-right-primary {\\r\\n    border-right: 7px solid var(--leis-primary-cl)\\r\\n}\\r\\n\\r\\n.leis-border-right-secondary {\\r\\n    border-right: 7px solid var(--leis-secondary-cl)\\r\\n}\\r\\n\\r\\n.leis-border-bottom-danger {\\r\\n    border-bottom: 7px solid var(--leis-danger-cl)\\r\\n}\\r\\n\\r\\n.leis-border-bottom-warning {\\r\\n    border-bottom: 7px solid var(--leis-warning-cl)\\r\\n}\\r\\n\\r\\n.leis-border-bottom-dark {\\r\\n    border-bottom: 7px solid var(--leis-dark-cl)\\r\\n}\\r\\n\\r\\n.leis-border-bottom-light {\\r\\n    border-bottom: 7px solid var(--leis-light-cl)\\r\\n}\\r\\n\\r\\n.leis-border-bottom-info {\\r\\n    border-bottom: 7px solid var(--leis-info-cl)\\r\\n}\\r\\n\\r\\n.leis-border-bottom-success {\\r\\n    border-bottom: 7px solid var(--leis-success-cl)\\r\\n}\\r\\n\\r\\n.leis-border-bottom-primary {\\r\\n    border-bottom: 7px solid var(--leis-primary-cl)\\r\\n}\\r\\n\\r\\n.leis-border-bottom-secondary {\\r\\n    border-bottom: 7px solid var(--leis-secondary-cl)\\r\\n}\\r\\n\\r\\n/* ---------------------- outline -------------------------- */\\r\\n.leis-outline-danger {\\r\\n    border: 2.8px solid;\\r\\n    border-color: var(--leis-danger-cl)\\r\\n}\\r\\n\\r\\n.leis-outline-warning {\\r\\n    border: 2.8px solid;\\r\\n    border-color: var(--leis-warning-cl)\\r\\n}\\r\\n\\r\\n.leis-outline-dark {\\r\\n    border: 2.8px solid;\\r\\n    border-color: var(--leis-dark-cl)\\r\\n}\\r\\n\\r\\n.leis-outline-light {\\r\\n    border: 2.8px solid;\\r\\n    border-color: var(--leis-light-cl)\\r\\n}\\r\\n\\r\\n.leis-outline-info {\\r\\n    border: 2.8px solid;\\r\\n    border-color: var(--leis-info-cl)\\r\\n}\\r\\n\\r\\n.leis-outline-success {\\r\\n    border: 2.8px solid;\\r\\n    border-color: var(--leis-success-cl)\\r\\n}\\r\\n\\r\\n.leis-outline-primary {\\r\\n    border: 2.8px solid;\\r\\n    border-color: var(--leis-primary-cl)\\r\\n}\\r\\n\\r\\n.leis-outline-secondary {\\r\\n    border: 2.8px solid;\\r\\n    border-color: var(--leis-secondary-cl)\\r\\n}\\r\\n\\r\\n.leis-border-primary {\\r\\n    border: 1.5px solid var(--leis-primary-cl);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-border-secondary {\\r\\n    border: 1.5px solid var(--leis-secondary-cl);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-border-warning {\\r\\n    border: 1.5px solid var(--leis-warning-cl);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-border-primary {\\r\\n    border: 1.5px solid var(--leis-primary-cl);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-border-info {\\r\\n    border: 1.5px solid var(--leis-info-cl);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-border-danger {\\r\\n    border: 1.5px solid var(--leis-danger-cl);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-border-success {\\r\\n    border: 1.5px solid var(--leis-success-cl);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-border-light {\\r\\n    border: 1.5px solid var(--leis-light-cl);\\r\\n\\r\\n}\\r\\n\\r\\n.leis-border-dark {\\r\\n    border: 1.5px solid var(--leis-dark-cl);\\r\\n\\r\\n}\\r\\n\\r\\n/* -------------------------- badge---------------------------- */\\r\\n.leis-bg-primary {\\r\\n    background-color: var(--leis-primary-cl);\\r\\n}\\r\\n\\r\\n.leis-bg-secondary {\\r\\n    background-color: var(--leis-secondary-cl);\\r\\n}\\r\\n\\r\\n.leis-bg-succes {\\r\\n    background-color: var(--leis-success-cl);\\r\\n}\\r\\n\\r\\n.leis-bg-danger {\\r\\n    background-color: var(--leis-danger-cl);\\r\\n}\\r\\n\\r\\n.leis-bg-warning {\\r\\n    background-color: var(--leis-warning-cl);\\r\\n}\\r\\n\\r\\n.leis-bg-info {\\r\\n    background-color: var(--leis-info-cl);\\r\\n}\\r\\n\\r\\n.leis-bg-light {\\r\\n    background-color: var(--leis-light-cl);\\r\\n}\\r\\n\\r\\n.leis-bg-dark {\\r\\n    background-color: var(--leis-dark-cl);\\r\\n}\\r\\n\\r\\n/* ---------------------------------- reset style-------------0000 */\\r\\n\\r\\n.leis-reset-margin {\\r\\n    margin: 0;\\r\\n}\\r\\n\\r\\n.leis-reset-padding {\\r\\n    padding: 0;\\r\\n}\\r\\n\\r\\n/* web elements */\\r\\n\\r\\n/* Collapsibles / Accordion */\\r\\n.leis-accordion-card {\\r\\n    outline: none;\\r\\n    border: none;\\r\\n    min-width: 0;\\r\\n    border-radius: 5px;\\r\\n    -webkit-box-shadow: var(--leis-accordion-bx-sh);\\r\\n    box-shadow: var(--leis-accordion-bx-sh);\\r\\n    background-color: var(--leis-default-cl);\\r\\n}\\r\\n\\r\\n\\r\\n.leis-accordion-btn {\\r\\n    position: relative;\\r\\n    cursor: pointer;\\r\\n    padding: 12px 14px;\\r\\n    text-align: left;\\r\\n    border: none;\\r\\n    outline: none;\\r\\n    transition: 0.4s ease-in-out;\\r\\n}\\r\\n\\r\\n.leis-accordion-btn::after,\\r\\n.leis-btn-controler::before,\\r\\n.leis-arrow-down::after {\\r\\n    position: relative;\\r\\n    content: \\"\\";\\r\\n    width: 10px;\\r\\n    height: 10px;\\r\\n    float: right;\\r\\n    top: 5px;\\r\\n    font-weight: 500;\\r\\n    font-size: 16px;\\r\\n    border-bottom: 1.8px solid;\\r\\n    border-left: 1.8px solid;\\r\\n    transform: rotateY(180deg) rotateZ(-40deg);\\r\\n    transition: .16s;\\r\\n}\\r\\n\\r\\n.leis-btn-controler {\\r\\n    color: #0069d9 !important;\\r\\n    position: absolute;\\r\\n    top: 8px;\\r\\n    left: 8px;\\r\\n    border: none;\\r\\n    z-index: 1;\\r\\n    background-color: inherit;\\r\\n}\\r\\n\\r\\n.leis-btn-controler.hide {\\r\\n    display: none;\\r\\n}\\r\\n\\r\\n.DA-close-modal {\\r\\n    position: absolute;\\r\\n    top: 15px;\\r\\n    left: 15px;\\r\\n    font-size: 1.5rem;\\r\\n    border-radius: 50%;\\r\\n}\\r\\n\\r\\n.DA-close-modal:hover {\\r\\n    background-color: #d31b2d;\\r\\n}\\r\\n\\r\\n.leis-btn-controler::before {\\r\\n    position: relative;\\r\\n    top: -1px;\\r\\n    border-bottom: 2.8px solid;\\r\\n    border-left: 2.8px solid;\\r\\n    transform: rotateY(180deg) rotateZ(-140deg);\\r\\n}\\r\\n\\r\\n.leis-accordion-btn.active::after,\\r\\n.leis-dropBtn.activeD .leis-arrow-down::after {\\r\\n    transform: rotateY(180deg) rotateZ(138deg);\\r\\n}\\r\\n\\r\\n.leis-accordion-btn:hover,\\r\\n.leis-accordion-btn.active {\\r\\n    background-color: var(--leis-light-hover-cl);\\r\\n}\\r\\n\\r\\n.leis-accordion-btn.active {\\r\\n    font-size: 18px;\\r\\n}\\r\\n\\r\\n\\r\\n.leis-accordion-btn:not(:last-child) {\\r\\n    border-bottom: 1.2px solid var(--leis-line-separator-cl);\\r\\n}\\r\\n\\r\\n\\r\\n.leis-accordion-panel {\\r\\n    position: relative;\\r\\n    background-color: inherit;\\r\\n    max-height: 0;\\r\\n    overflow: hidden;\\r\\n    transition: max-height 1s ease-in-out;\\r\\n}\\r\\n\\r\\n.leis-accordion-txt {\\r\\n    padding: 5px 14px;\\r\\n}\\r\\n\\r\\n.leis-accordion-panel.active {\\r\\n    max-height: 100vh;\\r\\n    overflow: visible;\\r\\n    background-color: #fff;\\r\\n}\\r\\n\\r\\n.leis-accordion-head {\\r\\n    width: 100%;\\r\\n    display: -webkit-box;\\r\\n    display: -moz-box;\\r\\n    display: block;\\r\\n    font-weight: 500;\\r\\n    background-color: var(--leis-accordion-head-cl);\\r\\n    padding: 12px 14px;\\r\\n    border-bottom: 1.5px solid var(--leis-line-separator-cl);\\r\\n    border-radius: 5px 5px 0px 0px;\\r\\n    color: var(--leis-accordion-head-txt-cl);\\r\\n}\\r\\n\\r\\n.leis-accordion-footer {\\r\\n    width: 100%;\\r\\n    display: -webkit-box;\\r\\n    display: -moz-box;\\r\\n    display: block;\\r\\n    padding: 5px 6px;\\r\\n    font-weight: 500;\\r\\n    border-radius: 0px 0px 5px 5px;\\r\\n    color: #000;\\r\\n    text-align: center;\\r\\n    -webkit-box-shadow: var(--leis-accordion-footer-bx-sh);\\r\\n    box-shadow: var(--leis-accordion-footer-bx-sh);\\r\\n    background-color: var(--leis-accordion-footer-cl);\\r\\n}\\r\\n\\r\\n/* collapsible*/\\r\\n\\r\\n.leis-collapsing-container {\\r\\n    position: relative;\\r\\n    border: none;\\r\\n    margin: 0;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-collapse-btn {\\r\\n    border: none;\\r\\n    font-weight: 500;\\r\\n    text-align: left;\\r\\n    padding: 0;\\r\\n}\\r\\n\\r\\n.leis-collapse-btn::before {\\r\\n    position: absolute;\\r\\n    left: -15px;\\r\\n    top: 8px;\\r\\n    content: \\"\\";\\r\\n    width: 10px;\\r\\n    height: 10px;\\r\\n    border-bottom: 2px solid;\\r\\n    border-left: 2px solid;\\r\\n    transform: rotateY(-180deg) rotateZ(40deg);\\r\\n    transition: .16s;\\r\\n}\\r\\n\\r\\n.leis-collapsing {\\r\\n    max-height: 0;\\r\\n    overflow: hidden;\\r\\n    transition: max-height .45s ease\\r\\n}\\r\\n\\r\\n.leis-collapsing.callo-show {\\r\\n    max-height: 100%;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-collapse-btn.colla-btn-show::before {\\r\\n    transform: rotateY(-180deg) rotateZ(-40deg);\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n\\r\\n/* table*/\\r\\n\\r\\n.leis-table-container {\\r\\n    position: relative;\\r\\n}\\r\\n\\r\\n.leis-table {\\r\\n    width: 100%;\\r\\n    border: 1px solid #ddd;\\r\\n    border-collapse: collapse;\\r\\n}\\r\\n\\r\\n.leis-table-head {\\r\\n    text-align: left;\\r\\n    border: inherit;\\r\\n}\\r\\n\\r\\n.leis-table-head .leis-table-heading {\\r\\n    border: 1px solid #ddd;\\r\\n    padding: 5px 10px;\\r\\n}\\r\\n\\r\\n.leis-table-body {\\r\\n    border: inherit;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-table-data,\\r\\n.leis-table-row {\\r\\n    border: inherit;\\r\\n}\\r\\n\\r\\n\\r\\n.leis-table-data,\\r\\n.leis-table-header {\\r\\n    padding: 5px 8px;\\r\\n}\\r\\n\\r\\n/*ToolTip*/\\r\\n.leis-tooltip {\\r\\n    visibility: hidden;\\r\\n    position: absolute;\\r\\n    border-radius: 8px;\\r\\n    opacity: 0;\\r\\n    padding: 10px;\\r\\n    border: 1px solid #ddd;\\r\\n    background-color: #fff;\\r\\n    width: -moz-fit-content;\\r\\n    width: fit-content;\\r\\n    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);\\r\\n    transition: opacity .3s ease;\\r\\n    -webkit-user-select: none;\\r\\n    user-select: none;\\r\\n}\\r\\n\\r\\n.leis-tooltip::after {\\r\\n    content: \\"\\";\\r\\n    position: absolute;\\r\\n    width: 12px;\\r\\n    height: 12px;\\r\\n    background-color: inherit;\\r\\n    top: 100%;\\r\\n    left: 50%;\\r\\n    margin-top: -5px;\\r\\n    border-left: inherit;\\r\\n    border-top: inherit;\\r\\n    transform: rotateY(180deg) rotateZ(-140deg);\\r\\n}\\r\\n\\r\\n.leis-tooltip.top {\\r\\n    bottom: calc(100% + 10px);\\r\\n    left: 50%;\\r\\n}\\r\\n\\r\\n.leis-tooltip.bottom {\\r\\n    top: calc(100% + 10px);\\r\\n    left: calc(100% - 60%);\\r\\n}\\r\\n\\r\\n.leis-tooltip.bottom::after {\\r\\n    top: -3px;\\r\\n    left: calc(100% - 60%);\\r\\n    width: 15px;\\r\\n    height: 15px;\\r\\n    transform: rotateY(180deg) rotateZ(40deg);\\r\\n}\\r\\n\\r\\n.leis-tooltip.right {\\r\\n    bottom: calc(50% - 10px);\\r\\n    left: calc(100% + 10px);\\r\\n    min-width: 140px;\\r\\n}\\r\\n\\r\\n.leis-tooltip.right::after {\\r\\n    top: 50%;\\r\\n    left: -8px;\\r\\n    width: 14px;\\r\\n    transform: rotateY(180deg) rotateZ(130deg);\\r\\n}\\r\\n\\r\\n.leis-tooltip.left {\\r\\n    bottom: calc(50% - 10px);\\r\\n    right: calc(100% + 10px);\\r\\n    min-width: 140px;\\r\\n}\\r\\n\\r\\n.leis-tooltip.left::after {\\r\\n    top: 50%;\\r\\n    left: 100%;\\r\\n    margin-left: -5px;\\r\\n    transform: rotateY(180deg) rotateZ(-50deg);\\r\\n}\\r\\n\\r\\n.leis-tooltip .leis-tooltip-content {\\r\\n    max-width: 350px;\\r\\n    max-height: 50vh;\\r\\n    overflow: hidden;\\r\\n    overflow-x: hidden;\\r\\n    overflow-y: auto;\\r\\n}\\r\\n\\r\\n.leis-tooltip * {\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n}\\r\\n\\r\\n\\r\\n/*search Bar*/\\r\\n\\r\\n.leis-searchBar,\\r\\n.leis-textinput {\\r\\n    width: 100%;\\r\\n    outline: none;\\r\\n    border: 1px solid #ddd;\\r\\n    padding: 3px 12px;\\r\\n    border-radius: 6px;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-searchBar:focus,\\r\\n.leis-textinput:focus {\\r\\n    -webkit-box-shadow: 0 0 0 .25rem rgba(13, 110, 253, .25);\\r\\n    box-shadow: 0 0 0 .25rem rgba(13, 110, 253, .25);\\r\\n    filter: brightness(100%);\\r\\n}\\r\\n\\r\\n/* tabs */\\r\\n.leis-tabs-card {\\r\\n    position: relative;\\r\\n    -webkit-display: flex;\\r\\n    -moz-display: flex;\\r\\n    -o-display: flex;\\r\\n    -ms-display: flex;\\r\\n    display: flex;\\r\\n    padding: 5px 14px;\\r\\n    gap: 0.5em;\\r\\n    white-space: nowrap;\\r\\n    overflow-x: auto;\\r\\n    background-color: inherit;\\r\\n    font-size: inherit;\\r\\n}\\r\\n\\r\\n.leis-tabs-btn {\\r\\n    position: relative;\\r\\n    display: -moz-box;\\r\\n    display: -webkit-box;\\r\\n    display: block;\\r\\n    padding: 5px;\\r\\n    background-color: inherit;\\r\\n    outline: none;\\r\\n    border: none;\\r\\n    font-weight: 500;\\r\\n    cursor: pointer;\\r\\n    text-decoration: none;\\r\\n    list-style: none;\\r\\n    overflow: visible;\\r\\n    text-overflow: inherit;\\r\\n}\\r\\n\\r\\n\\r\\n.leis-tab-txt {\\r\\n    padding: 0.5rem;\\r\\n}\\r\\n\\r\\n.leis-tab-content {\\r\\n    position: relative;\\r\\n    display: -webkit-box;\\r\\n    display: -ms-flexbox;\\r\\n    display: flex;\\r\\n    display: none;\\r\\n    -webkit-box-orient: vertical;\\r\\n    -webkit-box-direction: normal;\\r\\n    -ms-flex-direction: column;\\r\\n    flex-direction: column;\\r\\n    min-width: 0;\\r\\n    word-wrap: break-word;\\r\\n    background-color: inherit;\\r\\n    animation: fade-content 1s ease-in-out;\\r\\n}\\r\\n\\r\\n.leis-tab-content.active {\\r\\n    display: block;\\r\\n    background-color: inherit;\\r\\n    font-size: inherit;\\r\\n    font-weight: inherit;\\r\\n}\\r\\n\\r\\n.leis-tabs-btn.active {\\r\\n    background-color: #ddd;\\r\\n}\\r\\n\\r\\n@keyframes fade-content {\\r\\n    from {\\r\\n        opacity: 0;\\r\\n    }\\r\\n\\r\\n    to {\\r\\n        opacity: 1;\\r\\n    }\\r\\n}\\r\\n\\r\\n/*autocomplate*/\\r\\n\\r\\n.leis-autoComplate,\\r\\n.leis-textbox-container {\\r\\n    width: -moz-fit-content;\\r\\n    width: fit-content;\\r\\n    padding: none;\\r\\n    margin: 0;\\r\\n}\\r\\n\\r\\n.leis-autoComplate .leis-group * {\\r\\n    border: none;\\r\\n    padding: 0;\\r\\n}\\r\\n\\r\\n.leis-autoComplate .leis-group .leis-child-group {\\r\\n    padding: 6px 10px;\\r\\n    cursor: pointer;\\r\\n    border: 1px solid #f6f3f3a3;\\r\\n    display: flex;\\r\\n    gap: 10px;\\r\\n}\\r\\n\\r\\n.aut-item-subTitle {\\r\\n    color: var(--leis-subtitle-cl);\\r\\n    font-size: calc(var(--leis-font-size) - 1px);\\r\\n}\\r\\n\\r\\n.leis-autoComplate .leis-group .leis-child-group:hover {\\r\\n    background-color: var(--leis-select-cl)\\r\\n}\\r\\n\\r\\n.leis-autoComplateCard {\\r\\n    visibility: hidden;\\r\\n}\\r\\n\\r\\n\\r\\n.leis-autoComplateCard.clicked:hover {\\r\\n    visibility: visible;\\r\\n}\\r\\n\\r\\n.leis-autoComplateCard.empty {\\r\\n    padding: 0;\\r\\n    border: 0;\\r\\n    margin: 0;\\r\\n}\\r\\n\\r\\n.leis-searchBar:focus+.leis-autoComplateCard,\\r\\n.leis-autoInput:focus+.leis-autoComplateCard {\\r\\n    visibility: visible;\\r\\n}\\r\\n\\r\\n.leis-autComplate-container {\\r\\n    width: 100%;\\r\\n    position: absolute;\\r\\n    border: 1px solid #ddd;\\r\\n    background-color: #fff;\\r\\n    border-radius: 6px;\\r\\n    z-index: 1000;\\r\\n    -webkit-box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);\\r\\n    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15)\\r\\n}\\r\\n\\r\\n/* TopNav */\\r\\n.leis-icon-menu {\\r\\n    position: relative;\\r\\n    display: inline-block;\\r\\n    width: 20px;\\r\\n    height: 2.5px;\\r\\n    left: -0.5px;\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n    background-color: var(--leis-txt-cl);\\r\\n    transition: .5s ease-in;\\r\\n}\\r\\n\\r\\n.leis-icon-menu::after {\\r\\n    position: absolute;\\r\\n    top: -4px;\\r\\n    left: -0px;\\r\\n    margin-left: -0.5px;\\r\\n    display: inline-block;\\r\\n    content: \\"\\";\\r\\n    width: inherit;\\r\\n    height: inherit;\\r\\n    margin-bottom: 0.5px;\\r\\n    background-color: inherit;\\r\\n}\\r\\n\\r\\n.leis-icon-menu::before {\\r\\n    position: absolute;\\r\\n    display: inline-block;\\r\\n    top: -8px;\\r\\n    left: -0.5px;\\r\\n    content: \\"\\";\\r\\n    width: inherit;\\r\\n    height: inherit;\\r\\n    margin-bottom: 0.5px;\\r\\n    background-color: inherit;\\r\\n}\\r\\n\\r\\n.leis-icon-menu.clicked {\\r\\n    transform: rotateZ(-150deg);\\r\\n}\\r\\n\\r\\n.leis-icon-menu.clicked::after {\\r\\n    transform: rotateZ(90deg);\\r\\n    top: 0px;\\r\\n    left: 0.5px;\\r\\n}\\r\\n\\r\\n.leis-icon-menu.clicked::before {\\r\\n    transform: rotateZ(40deg);\\r\\n    background-color: transparent;\\r\\n}\\r\\n\\r\\n.leis-topnav {\\r\\n    position: relative;\\r\\n    font-size: 18px;\\r\\n    width: 100%;\\r\\n    height: 50px;\\r\\n    border-bottom: 1px solid #eee;\\r\\n    -webkit-box-shadow: var(--leis-nav-bx-sh);\\r\\n    box-shadow: var(--leis-nav-bx-sh);\\r\\n    margin: 0;\\r\\n}\\r\\n\\r\\n\\r\\n.leis-topnav.primary,\\r\\n.leis-topnav.primary .leis-dropBtn {\\r\\n    background-color: var(--leis-primary-hover-cl);\\r\\n    color: rgba(230, 227, 227, 0.991) !important;\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n.leis-topnav .leis-dropBtn,\\r\\n.leis-topnav .leis-dropBtn.activeD {\\r\\n    width: auto;\\r\\n    border: none;\\r\\n    outline: none;\\r\\n    box-shadow: none;\\r\\n    font-size: 18px;\\r\\n    text-align: left;\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n    display: inline-block;\\r\\n    padding-top: 4px;\\r\\n    font-weight: 300;\\r\\n}\\r\\n\\r\\n.leis-topnav .leis-dropdown-content.show {\\r\\n    z-index: 1000;\\r\\n    min-width: 200px;\\r\\n    color: #000 !important;\\r\\n}\\r\\n\\r\\n.leis-topnav .leis-dropBtn {\\r\\n    display: flex;\\r\\n    gap: 10px;\\r\\n}\\r\\n\\r\\n.leis-topnav .leis-dropBtn.activeD .leis-arrow-down::after {\\r\\n    left: 10px;\\r\\n}\\r\\n\\r\\n.leis-topnav .leis-dropBtn .leis-arrow-down::after {\\r\\n    height: 6px;\\r\\n    width: 6px;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-topnav.primary .leis-child-group:hover,\\r\\n.leis-topnav.primary .leis-dropBtn:hover {\\r\\n    color: #fff !important\\r\\n}\\r\\n\\r\\n.leis-topnav.secondary,\\r\\n.leis-topnav.secondary .leis-dropBtn {\\r\\n    background-color: var(--leis-secondary-cl);\\r\\n    color: rgba(230, 227, 227, 0.991) !important;\\r\\n}\\r\\n\\r\\n.leis-topnav.secondary .leis-child-group:hover,\\r\\n.leis-topnav.secondary .leis-dropBtn {\\r\\n    color: #fff !important\\r\\n}\\r\\n\\r\\n.leis-topnav.warning,\\r\\n.leis-topnav.warning .leis-dropBtn {\\r\\n    background-color: var(--leis-warning-cl);\\r\\n    color: #221e1e !important\\r\\n}\\r\\n\\r\\n.leis-topnav.warning .leis-child-group:hover,\\r\\n.leis-topnav.warning .leis-dropBtn:hover {\\r\\n    color: #000 !important\\r\\n}\\r\\n\\r\\n.leis-topnav.dark,\\r\\n.leis-topnav.dark .leis-dropBtn {\\r\\n    background-color: var(--leis-dark-cl);\\r\\n    color: rgb(216, 212, 212) !important\\r\\n}\\r\\n\\r\\n.leis-topnav.dark .leis-child-group:hover,\\r\\n.leis-topnav.dark .leis-dropBtn:hover {\\r\\n    color: #fff !important\\r\\n}\\r\\n\\r\\n\\r\\n.leis-topnav.light,\\r\\n.leis-topnav.light .leis-dropBtn {\\r\\n    background-color: var(--leis-light-cl);\\r\\n    color: #3c3939 !important\\r\\n}\\r\\n\\r\\n.leis-topnav.light .leis-child-group:hover,\\r\\n.leis-topnav.light .leis-dropBtn:hover {\\r\\n    color: var(--leis-primary-cl) !important\\r\\n}\\r\\n\\r\\n\\r\\n.leis-topnav.success,\\r\\n.leis-topnav.success .leis-dropBtn {\\r\\n    background-color: var(--leis-success-cl);\\r\\n    color: rgb(216, 212, 212) !important\\r\\n}\\r\\n\\r\\n.leis-topnav.success .leis-child-group:hover,\\r\\n.leis-topnav.success .leis-dropBtn:hover {\\r\\n    color: #fff\\r\\n}\\r\\n\\r\\n.leis-topnav.danger,\\r\\n.leis-topnav.danger .leis-dropBtn {\\r\\n    background-color: var(--leis-danger-cl);\\r\\n    color: rgb(216, 212, 212) !important\\r\\n}\\r\\n\\r\\n.leis-topnav.danger .leis-child-group:hover,\\r\\n.leis-topnav.danger .leis-dropBtn:hover {\\r\\n    color: #fff\\r\\n}\\r\\n\\r\\n.leis-topnav.info,\\r\\n.leis-topnav.info .leis-dropBtn {\\r\\n    background-color: var(--leis-info-cl);\\r\\n    color: #333 !important\\r\\n}\\r\\n\\r\\n.leis-topnav.info .leis-child-group:hover,\\r\\n.leis-topnav.info .leis-dropBtn:hover {\\r\\n    color: #000 !important\\r\\n}\\r\\n\\r\\n.leis-topnav-cd-profil-right {\\r\\n    display: block;\\r\\n    float: right;\\r\\n}\\r\\n\\r\\n.leis-topnav .leis-list-group {\\r\\n    display: inline-block;\\r\\n    padding: 10px 16px;\\r\\n    margin: 0;\\r\\n    display: flex;\\r\\n    flex-direction: row;\\r\\n    gap: 0.8rem;\\r\\n}\\r\\n\\r\\n.leis-topnav .leis-list-group .leis-img-group-left {\\r\\n    display: inline-block;\\r\\n    width: 30px;\\r\\n    height: 30px;\\r\\n    margin: 5 auto;\\r\\n}\\r\\n\\r\\n.leis-topnav .leis-group .leis-dropdown {\\r\\n    background-color: red;\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n.profil {\\r\\n    padding: 0 !important;\\r\\n    margin: 0 !important;\\r\\n}\\r\\n\\r\\n.leis-topnav .leis-list-group .leis-img-group-left img {\\r\\n    min-height: 30px;\\r\\n}\\r\\n\\r\\n.leis-topnav .leis-list-group .leis-child-group {\\r\\n    margin: 0;\\r\\n    border: none;\\r\\n    outline: none;\\r\\n    padding: 2.5px 2.5px 0 0;\\r\\n}\\r\\n\\r\\n.leis-topnav .leis-list-group .leis-child-group * {\\r\\n    text-decoration: none;\\r\\n    color: inherit;\\r\\n\\r\\n}\\r\\n\\r\\n@media screen and (max-width:600px) {\\r\\n\\r\\n    .leis-topnav a:not(:first-child) {\\r\\n        display: none;\\r\\n    }\\r\\n\\r\\n    .leis-topnav a.icon {\\r\\n        float: right;\\r\\n        display: block;\\r\\n\\r\\n    }\\r\\n\\r\\n    .leis-topnav.responsive a.icon {\\r\\n        position: absolute;\\r\\n        top: 0;\\r\\n        right: 0;\\r\\n    }\\r\\n\\r\\n    .leis-topnav.responsive a {\\r\\n        float: none;\\r\\n        display: block;\\r\\n        text-align: left;\\r\\n    }\\r\\n}\\r\\n\\r\\n/* SideNav */\\r\\n.leis-sideNav {\\r\\n    padding: 10px;\\r\\n    height: 100%;\\r\\n    width: 250px;\\r\\n    position: fixed;\\r\\n    overflow: hidden;\\r\\n    z-index: 100;\\r\\n    top: 0;\\r\\n    left: 0;\\r\\n    background-color: var(--leis-dark-cl);\\r\\n    overflow-x: hidden;\\r\\n    transition: 0.5s;\\r\\n    -webkit-box-shadow: var(--leis-sideNav-bx-sh);\\r\\n    box-shadow: var(--leis-sideNav-bx-sh);\\r\\n    border-right: 1.8px solid var(--leis-default-cl);\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-collapsing-container * {\\r\\n    color: inherit;\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-list-group * {\\r\\n    font-weight: 400;\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-collapsing-container .leis-collapse-btn {\\r\\n    padding-left: 20px;\\r\\n    font-size: inherit;\\r\\n    font-weight: inherit;\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-collapsing-container .leis-collapse-btn::before {\\r\\n    left: 0;\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-collapsing-container .leis-collapse-btn.colla-btn-show {\\r\\n    font-weight: 400;\\r\\n    color: #dad6d6e8;\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-collapsing-container .leis-collapse-btn:hover {\\r\\n    color: #ede7e7;\\r\\n}\\r\\n\\r\\n.leis-sideNav a {\\r\\n    text-decoration: none;\\r\\n    color: inherit;\\r\\n    font-size: inherit;\\r\\n    font-family: inherit;\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-list-group.links {\\r\\n    max-height: 75vh;\\r\\n    overflow: hidden;\\r\\n    overflow-x: hidden;\\r\\n    overflow-y: auto;\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-list-group::-webkit-scrollbar {\\r\\n    height: 4px;\\r\\n    width: 8px;\\r\\n    cursor: default !important;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-list-group::-webkit-scrollbar-thumb {\\r\\n    background-color: rgba(222, 217, 217, 0.541);\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-list-group .leis-child-group {\\r\\n    padding: 8.5px 6px;\\r\\n    font-size: 1.1rem;\\r\\n    font-family: inherit;\\r\\n    border-radius: 8px;\\r\\n    border: none;\\r\\n    color: rgb(216, 212, 212);\\r\\n    cursor: pointer;\\r\\n    -webkit-user-select: none;\\r\\n    user-select: none;\\r\\n    display: flex;\\r\\n    justify-content: start;\\r\\n    gap: 13px;\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-list-group .leis-child-group.active {\\r\\n    background-color: inherit;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-collapsing-container .leis-list-group .leis-child-group {\\r\\n    padding: 3px 1.5px;\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-collapsing-container .leis-list-group {\\r\\n    padding-left: 15px;\\r\\n}\\r\\n\\r\\n.leis-sideNav .sideNavHeader {\\r\\n    padding: 5px 5px;\\r\\n    color: #fff;\\r\\n    font-size: 1.5rem;\\r\\n    margin-bottom: 1rem;\\r\\n    padding-bottom: 1.5rem;\\r\\n    border-bottom: 1.5px solid #6860609f;\\r\\n}\\r\\n\\r\\n.leis-sideNav .sideNavFooter {\\r\\n    position: absolute;\\r\\n    bottom: 0;\\r\\n    left: 0;\\r\\n    width: 100%;\\r\\n    padding: 10px 10px;\\r\\n    color: #fff;\\r\\n    font-size: 1.5rem;\\r\\n    padding-top: 1rem;\\r\\n    border-top: 1.5px solid #6860609f;\\r\\n\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n.leis-sideNav .leis-list-group .leis-child-group:not(.colla-item):hover {\\r\\n    background-color: #98c3f16b;\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-list-group .leis-child-group.sideItemActive {\\r\\n    background-color: #0069d9;\\r\\n    color: #fff;\\r\\n}\\r\\n\\r\\n\\r\\n.leis-sideNav a:hover {\\r\\n    background-color: var(--leis-light-hover-cl);\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-close-btn {\\r\\n    position: absolute;\\r\\n    top: 0;\\r\\n    right: 0;\\r\\n    font-size: 35px;\\r\\n    margin-left: 50px;\\r\\n}\\r\\n\\r\\n\\r\\n.leis-openSide,\\r\\n.leis-Closeside {\\r\\n    position: relative;\\r\\n    display: inline-block\\r\\n}\\r\\n\\r\\n@media screen and(max-height:450px) {\\r\\n    .leis-sideNav {\\r\\n        padding: 15px;\\r\\n    }\\r\\n\\r\\n    .leis-sideNav a {\\r\\n        font-size: 18px;\\r\\n    }\\r\\n}\\r\\n\\r\\n/* dropdown btn */\\r\\n\\r\\n\\r\\n.leis-dropdown,\\r\\n.leis-slideshow-container {\\r\\n    position: relative;\\r\\n    border: none;\\r\\n    outline: none;\\r\\n    box-shadow: none;\\r\\n}\\r\\n\\r\\n.leis-dropdown {\\r\\n    display: inline-block;\\r\\n}\\r\\n\\r\\n.leis-dropdown-content {\\r\\n    display: none;\\r\\n    position: absolute;\\r\\n    top: -8px;\\r\\n    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, .2) !important;\\r\\n    z-index: 1;\\r\\n    animation: fade .16s ease-in;\\r\\n}\\r\\n\\r\\n.leis-dropdwn-content-card {\\r\\n    position: relative;\\r\\n    max-height: 350px;\\r\\n    min-width: 100px;\\r\\n    overflow-y: auto;\\r\\n    overflow-x: hidden;\\r\\n}\\r\\n\\r\\n.leis-content {\\r\\n    width: 100%;\\r\\n    position: relative;\\r\\n}\\r\\n\\r\\n.leis-content>.leis-dropdown-content {\\r\\n    width: 100%;\\r\\n}\\r\\n\\r\\n.leis-dropdown-content a {\\r\\n    color: black;\\r\\n    padding: 12px 16px;\\r\\n    display: block;\\r\\n}\\r\\n\\r\\n.leis-dropdwn-content-card>* {\\r\\n    display: block;\\r\\n}\\r\\n\\r\\n.hide {\\r\\n    display: none;\\r\\n}\\r\\n\\r\\n.show {\\r\\n    display: block;\\r\\n}\\r\\n\\r\\n/* Page */\\r\\n\\r\\n.leis-mainPage {\\r\\n    position: relative;\\r\\n    padding-top: 30px;\\r\\n    min-width: 100%;\\r\\n}\\r\\n\\r\\n.leis-page-content {\\r\\n    position: relative;\\r\\n    display: none;\\r\\n    animation: fr .4s ease-in-out\\r\\n}\\r\\n\\r\\n@keyframes fr {\\r\\n    from {\\r\\n        transform: scale(0.5);\\r\\n        opacity: 0;\\r\\n    }\\r\\n\\r\\n    to {\\r\\n        transform: scale(1);\\r\\n        opacity: 1;\\r\\n    }\\r\\n}\\r\\n\\r\\n.leis-page-legende {\\r\\n    cursor: pointer;\\r\\n}\\r\\n\\r\\n/* slideshow/ carousel */\\r\\n\\r\\n.leis-slideshow-container {\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n    max-width: 1000px;\\r\\n    margin: auto;\\r\\n    overflow: hidden;\\r\\n}\\r\\n\\r\\n.leis-slideshow-container .leis-img-card {\\r\\n    width: 100%;\\r\\n    height: inherit;\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n    position: relative;\\r\\n    display: none;\\r\\n\\r\\n}\\r\\n\\r\\n.leis-slideshow-container .leis-img-card .leis-img {\\r\\n    width: 100%;\\r\\n    height: auto;\\r\\n    max-height: calc(100%);\\r\\n}\\r\\n\\r\\n.leis-slideshow-prev-btn,\\r\\n.leis-slideshow-next-btn {\\r\\n    cursor: pointer;\\r\\n    position: absolute;\\r\\n    top: 50%;\\r\\n    padding: 10px;\\r\\n    color: white;\\r\\n    font-weight: bold;\\r\\n    font-size: 18px;\\r\\n    transition: 0.6s ease;\\r\\n    border-radius: 0 3px 3px 0;\\r\\n    -webkit-user-select: none;\\r\\n    user-select: none;\\r\\n    z-index: 1;\\r\\n}\\r\\n\\r\\n.leis-slideshow-prev-btn {\\r\\n    left: 0;\\r\\n}\\r\\n\\r\\n.leis-slideshow-next-btn {\\r\\n    right: 0;\\r\\n    border-radius: 3px 0 0 3px;\\r\\n}\\r\\n\\r\\n.leis-slideshow-next-btn:hover,\\r\\n.leis-slideshow-prev-btn:hover {\\r\\n    background-color: rgba(0, 0, 0, 0.8);\\r\\n}\\r\\n\\r\\n.leis-slideshow-txt {\\r\\n    color: #f2f2f2;\\r\\n    font-size: 18px;\\r\\n    position: absolute;\\r\\n    padding: 8px;\\r\\n    left: 0;\\r\\n    bottom: 0;\\r\\n    width: 100%;\\r\\n    text-align: center;\\r\\n    background-color: rgba(0, 0, 0, 0.479);\\r\\n    z-index: 1;\\r\\n}\\r\\n\\r\\n.leis-slideshowNumTxt {\\r\\n    position: absolute;\\r\\n    color: #f2f2f2;\\r\\n    font-size: 17px;\\r\\n    padding: 8px 12px;\\r\\n    top: 0;\\r\\n}\\r\\n\\r\\n.leis-slideshow-dot {\\r\\n    cursor: pointer;\\r\\n    height: 15px;\\r\\n    width: 15px;\\r\\n    margin: 0 2px;\\r\\n    background-color: #bbb;\\r\\n    border-radius: 50%;\\r\\n    display: inline-block;\\r\\n    transition: background-color 0.6s ease\\r\\n}\\r\\n\\r\\n.active,\\r\\n.leis-slideshow-dot:hover {\\r\\n    background-color: #717171;\\r\\n}\\r\\n\\r\\n.fade {\\r\\n    animation-name: fade;\\r\\n    animation-duration: 1.5s;\\r\\n}\\r\\n\\r\\n.leis-firstSlideShow {\\r\\n    word-wrap: break-word;\\r\\n}\\r\\n\\r\\n@keyframes fade {\\r\\n    from {\\r\\n        opacity: .4;\\r\\n    }\\r\\n\\r\\n    to {\\r\\n        opacity: 1;\\r\\n    }\\r\\n}\\r\\n\\r\\n\\r\\n/* slideshow gallery */\\r\\n/* ---------------------- */\\r\\n\\r\\n/* modal image */\\r\\n\\r\\n@font-face {\\r\\n    font-family: \\"Open-Sans\\";\\r\\n    src: url(\\"../font/OpenSans/OpenSans-VariableFont_wdth\\\\,wght.ttf\\");\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-Meduim';\\r\\n    src: url(\\"../font/Poppins/Poppins-Medium.ttf\\");\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-Regular';\\r\\n    src: url(\\"../font/Poppins/Poppins-Regular.ttf\\");\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Italic-VariableFont-wdthwght';\\r\\n    src: url('../font/OpenSans/OpenSans-Italic-VariableFont_wdth,wght.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-VariableFont-wdthwght';\\r\\n    src: url('../font/OpenSans/OpenSans-VariableFont_wdth,wght.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Bold';\\r\\n    src: url('../font/OpenSans/static/OpenSans-Bold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-BoldItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans-BoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-ExtraBold';\\r\\n    src: url('../font/OpenSans/static/OpenSans-ExtraBold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-ExtraBoldItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans-ExtraBoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Italic';\\r\\n    src: url('../font/OpenSans/static/OpenSans-Italic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Light';\\r\\n    src: url('../font/OpenSans/static/OpenSans-Light.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-LightItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans-LightItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Medium';\\r\\n    src: url('../font/OpenSans/static/OpenSans-Medium.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-MediumItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans-MediumItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Regular';\\r\\n    src: url('../font/OpenSans/static/OpenSans-Regular.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiBold';\\r\\n    src: url('../font/OpenSans/static/OpenSans-SemiBold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiBoldItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans-SemiBoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-Bold';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-Bold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-BoldItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-BoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-ExtraBold';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-ExtraBold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-ExtraBoldItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-ExtraBoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-Italic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-Italic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-Light';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-Light.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-LightItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-LightItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-Medium';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-Medium.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-MediumItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-MediumItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-Regular';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-Regular.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-SemiBold';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-SemiBold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-Condensed-SemiBoldItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_Condensed-SemiBoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-Bold';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-Bold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-BoldItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-BoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-ExtraBold';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-ExtraBold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-ExtraBoldItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-ExtraBoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-Italic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-Italic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-Light';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-Light.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-LightItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-LightItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-Medium';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-Medium.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-MediumItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-MediumItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-Regular';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-Regular.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-SemiBold';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-SemiBold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'OpenSans-SemiCondensed-SemiBoldItalic';\\r\\n    src: url('../font/OpenSans/static/OpenSans_SemiCondensed-SemiBoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-Black';\\r\\n    src: url('../font/Poppins/Poppins-Black.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-BlackItalic';\\r\\n    src: url('../font/Poppins/Poppins-BlackItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-Bold';\\r\\n    src: url('../font/Poppins/Poppins-Bold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-BoldItalic';\\r\\n    src: url('../font/Poppins/Poppins-BoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-ExtraBold';\\r\\n    src: url('../font/Poppins/Poppins-ExtraBold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-ExtraBoldItalic';\\r\\n    src: url('../font/Poppins/Poppins-ExtraBoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-ExtraLight';\\r\\n    src: url('../font/Poppins/Poppins-ExtraLight.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-ExtraLightItalic';\\r\\n    src: url('../font/Poppins/Poppins-ExtraLightItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-Italic';\\r\\n    src: url('../font/Poppins/Poppins-Italic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-Light';\\r\\n    src: url('../font/Poppins/Poppins-Light.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-LightItalic';\\r\\n    src: url('../font/Poppins/Poppins-LightItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-Medium';\\r\\n    src: url('../font/Poppins/Poppins-Medium.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-MediumItalic';\\r\\n    src: url('../font/Poppins/Poppins-MediumItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-Regular';\\r\\n    src: url('../font/Poppins/Poppins-Regular.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-SemiBold';\\r\\n    src: url('../font/Poppins/Poppins-SemiBold.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-SemiBoldItalic';\\r\\n    src: url('../font/Poppins/Poppins-SemiBoldItalic.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-Thin';\\r\\n    src: url('../font/Poppins/Poppins-Thin.ttf');\\r\\n}\\r\\n\\r\\n@font-face {\\r\\n    font-family: 'Poppins-ThinItalic';\\r\\n    src: url('../font/Poppins/Poppins-ThinItalic.ttf');\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Italic-VariableFont-wdthwght {\\r\\n    font-family: 'OpenSans-Italic-VariableFont-wdthwght',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-VariableFont-wdthwght {\\r\\n    font-family: 'OpenSans-VariableFont-wdthwght',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Bold {\\r\\n    font-family: 'OpenSans-Bold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-BoldItalic {\\r\\n    font-family: 'OpenSans-BoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-ExtraBold {\\r\\n    font-family: 'OpenSans-ExtraBold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-ExtraBoldItalic {\\r\\n    font-family: 'OpenSans-ExtraBoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Italic {\\r\\n    font-family: 'OpenSans-Italic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Light {\\r\\n    font-family: 'OpenSans-Light',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-LightItalic {\\r\\n    font-family: 'OpenSans-LightItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Medium {\\r\\n    font-family: 'OpenSans-Medium',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-MediumItalic {\\r\\n    font-family: 'OpenSans-MediumItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Regular {\\r\\n    font-family: 'OpenSans-Regular',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiBold {\\r\\n    font-family: 'OpenSans-SemiBold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiBoldItalic {\\r\\n    font-family: 'OpenSans-SemiBoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-Bold {\\r\\n    font-family: 'OpenSans-Condensed-Bold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-BoldItalic {\\r\\n    font-family: 'OpenSans-Condensed-BoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-ExtraBold {\\r\\n    font-family: 'OpenSans-Condensed-ExtraBold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-ExtraBoldItalic {\\r\\n    font-family: 'OpenSans-Condensed-ExtraBoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-Italic {\\r\\n    font-family: 'OpenSans-Condensed-Italic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-Light {\\r\\n    font-family: 'OpenSans-Condensed-Light',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-LightItalic {\\r\\n    font-family: 'OpenSans-Condensed-LightItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-Medium {\\r\\n    font-family: 'OpenSans-Condensed-Medium',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-MediumItalic {\\r\\n    font-family: 'OpenSans-Condensed-MediumItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-Regular {\\r\\n    font-family: 'OpenSans-Condensed-Regular',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-SemiBold {\\r\\n    font-family: 'OpenSans-Condensed-SemiBold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-Condensed-SemiBoldItalic {\\r\\n    font-family: 'OpenSans-Condensed-SemiBoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-Bold {\\r\\n    font-family: 'OpenSans-SemiCondensed-Bold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-BoldItalic {\\r\\n    font-family: 'OpenSans-SemiCondensed-BoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-ExtraBold {\\r\\n    font-family: 'OpenSans-SemiCondensed-ExtraBold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-ExtraBoldItalic {\\r\\n    font-family: 'OpenSans-SemiCondensed-ExtraBoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-Italic {\\r\\n    font-family: 'OpenSans-SemiCondensed-Italic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-Light {\\r\\n    font-family: 'OpenSans-SemiCondensed-Light',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-LightItalic {\\r\\n    font-family: 'OpenSans-SemiCondensed-LightItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-Medium {\\r\\n    font-family: 'OpenSans-SemiCondensed-Medium',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-MediumItalic {\\r\\n    font-family: 'OpenSans-SemiCondensed-MediumItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-Regular {\\r\\n    font-family: 'OpenSans-SemiCondensed-Regular',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-SemiBold {\\r\\n    font-family: 'OpenSans-SemiCondensed-SemiBold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-OpenSans-SemiCondensed-SemiBoldItalic {\\r\\n    font-family: 'OpenSans-SemiCondensed-SemiBoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-Black {\\r\\n    font-family: 'Poppins-Black',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-BlackItalic {\\r\\n    font-family: 'Poppins-BlackItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-Bold {\\r\\n    font-family: 'Poppins-Bold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-BoldItalic {\\r\\n    font-family: 'Poppins-BoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-ExtraBold {\\r\\n    font-family: 'Poppins-ExtraBold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-ExtraBoldItalic {\\r\\n    font-family: 'Poppins-ExtraBoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-ExtraLight {\\r\\n    font-family: 'Poppins-ExtraLight',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-ExtraLightItalic {\\r\\n    font-family: 'Poppins-ExtraLightItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-Italic {\\r\\n    font-family: 'Poppins-Italic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-Light {\\r\\n    font-family: 'Poppins-Light',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-LightItalic {\\r\\n    font-family: 'Poppins-LightItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-Medium {\\r\\n    font-family: 'Poppins-Medium',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-MediumItalic {\\r\\n    font-family: 'Poppins-MediumItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-Regular {\\r\\n    font-family: 'Poppins-Regular',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-SemiBold {\\r\\n    font-family: 'Poppins-SemiBold',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-SemiBoldItalic {\\r\\n    font-family: 'Poppins-SemiBoldItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-Thin {\\r\\n    font-family: 'Poppins-Thin',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-Poppins-ThinItalic {\\r\\n    font-family: 'Poppins-ThinItalic',\\r\\n        system-ui, -apple-system,\\r\\n        BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,\\r\\n        Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue',\\r\\n        sans-serif;\\r\\n}\\r\\n\\r\\n.leis-font-100 {\\r\\n    font-weight: 100;\\r\\n}\\r\\n\\r\\n.leis-font-200 {\\r\\n    font-weight: 200;\\r\\n}\\r\\n\\r\\n.leis-font-300 {\\r\\n    font-weight: 300;\\r\\n}\\r\\n\\r\\n.leis-font-400 {\\r\\n    font-weight: 400;\\r\\n}\\r\\n\\r\\n.leis-font-500 {\\r\\n    font-weight: 500;\\r\\n}\\r\\n\\r\\n.leis-font-600 {\\r\\n    font-weight: 600;\\r\\n}\\r\\n\\r\\n.leis-font-700 {\\r\\n    font-weight: 700;\\r\\n}\\r\\n\\r\\n.leis-font-800 {\\r\\n    font-weight: 800;\\r\\n}\\r\\n\\r\\n.leis-font-900 {\\r\\n    font-weight: 900;\\r\\n}\\r\\n\\r\\n.leis-font-size-1 {\\r\\n    font-size: 1px;\\r\\n}\\r\\n\\r\\n.leis-font-size-2 {\\r\\n    font-size: 2px;\\r\\n}\\r\\n\\r\\n.leis-font-size-3 {\\r\\n    font-size: 3px;\\r\\n}\\r\\n\\r\\n.leis-font-size-4 {\\r\\n    font-size: 4px;\\r\\n}\\r\\n\\r\\n.leis-font-size-5 {\\r\\n    font-size: 5px;\\r\\n}\\r\\n\\r\\n.leis-font-size-6 {\\r\\n    font-size: 6px;\\r\\n}\\r\\n\\r\\n.leis-font-size-7 {\\r\\n    font-size: 7px;\\r\\n}\\r\\n\\r\\n.leis-font-size-8 {\\r\\n    font-size: 8px;\\r\\n}\\r\\n\\r\\n.leis-font-size-9 {\\r\\n    font-size: 9px;\\r\\n}\\r\\n\\r\\n.leis-font-size-10 {\\r\\n    font-size: 10px;\\r\\n}\\r\\n\\r\\n.leis-font-size-11 {\\r\\n    font-size: 11px;\\r\\n}\\r\\n\\r\\n.leis-font-size-12 {\\r\\n    font-size: 12px;\\r\\n}\\r\\n\\r\\n.leis-font-size-13 {\\r\\n    font-size: 13px;\\r\\n}\\r\\n\\r\\n.leis-font-size-14 {\\r\\n    font-size: 14px;\\r\\n}\\r\\n\\r\\n.leis-font-size-15 {\\r\\n    font-size: 15px;\\r\\n}\\r\\n\\r\\n.leis-font-size-16 {\\r\\n    font-size: 16px;\\r\\n}\\r\\n\\r\\n.leis-font-size-17 {\\r\\n    font-size: 17px;\\r\\n}\\r\\n\\r\\n.leis-font-size-18 {\\r\\n    font-size: 18px;\\r\\n}\\r\\n\\r\\n.leis-font-size-19 {\\r\\n    font-size: 19px;\\r\\n}\\r\\n\\r\\n.leis-font-size-20 {\\r\\n    font-size: 20px;\\r\\n}\\r\\n\\r\\n.leis-font-size-21 {\\r\\n    font-size: 21px;\\r\\n}\\r\\n\\r\\n.leis-font-size-22 {\\r\\n    font-size: 22px;\\r\\n}\\r\\n\\r\\n.leis-font-size-23 {\\r\\n    font-size: 23px;\\r\\n}\\r\\n\\r\\n.leis-font-size-24 {\\r\\n    font-size: 24px;\\r\\n}\\r\\n\\r\\n.leis-font-size-25 {\\r\\n    font-size: 25px;\\r\\n}\\r\\n\\r\\n.leis-font-size-26 {\\r\\n    font-size: 26px;\\r\\n}\\r\\n\\r\\n.leis-font-size-27 {\\r\\n    font-size: 27px;\\r\\n}\\r\\n\\r\\n.leis-font-size-28 {\\r\\n    font-size: 28px;\\r\\n}\\r\\n\\r\\n.leis-font-size-29 {\\r\\n    font-size: 29px;\\r\\n}\\r\\n\\r\\n.leis-font-size-30 {\\r\\n    font-size: 30px;\\r\\n}\\r\\n\\r\\n.leis-font-size-31 {\\r\\n    font-size: 31px;\\r\\n}\\r\\n\\r\\n.leis-font-size-32 {\\r\\n    font-size: 32px;\\r\\n}\\r\\n\\r\\n.leis-font-size-33 {\\r\\n    font-size: 33px;\\r\\n}\\r\\n\\r\\n.leis-font-size-34 {\\r\\n    font-size: 34px;\\r\\n}\\r\\n\\r\\n.leis-font-size-35 {\\r\\n    font-size: 35px;\\r\\n}\\r\\n\\r\\n.leis-font-size-36 {\\r\\n    font-size: 36px;\\r\\n}\\r\\n\\r\\n.leis-font-size-37 {\\r\\n    font-size: 37px;\\r\\n}\\r\\n\\r\\n.leis-font-size-38 {\\r\\n    font-size: 38px;\\r\\n}\\r\\n\\r\\n.leis-font-size-39 {\\r\\n    font-size: 39px;\\r\\n}\\r\\n\\r\\n.leis-font-size-40 {\\r\\n    font-size: 40px;\\r\\n}\\r\\n\\r\\n.leis-font-size-41 {\\r\\n    font-size: 41px;\\r\\n}\\r\\n\\r\\n.leis-font-size-42 {\\r\\n    font-size: 42px;\\r\\n}\\r\\n\\r\\n.leis-font-size-43 {\\r\\n    font-size: 43px;\\r\\n}\\r\\n\\r\\n.leis-font-size-44 {\\r\\n    font-size: 44px;\\r\\n}\\r\\n\\r\\n.leis-font-size-45 {\\r\\n    font-size: 45px;\\r\\n}\\r\\n\\r\\n.leis-font-size-46 {\\r\\n    font-size: 46px;\\r\\n}\\r\\n\\r\\n.leis-font-size-47 {\\r\\n    font-size: 47px;\\r\\n}\\r\\n\\r\\n.leis-font-size-48 {\\r\\n    font-size: 48px;\\r\\n}\\r\\n\\r\\n.leis-font-size-49 {\\r\\n    font-size: 49px;\\r\\n}\\r\\n\\r\\n.leis-font-size-50 {\\r\\n    font-size: 50px;\\r\\n}\\r\\n\\r\\n.leis-font-size-51 {\\r\\n    font-size: 51px;\\r\\n}\\r\\n\\r\\n.leis-font-size-52 {\\r\\n    font-size: 52px;\\r\\n}\\r\\n\\r\\n.leis-font-size-53 {\\r\\n    font-size: 53px;\\r\\n}\\r\\n\\r\\n.leis-font-size-54 {\\r\\n    font-size: 54px;\\r\\n}\\r\\n\\r\\n.leis-font-size-55 {\\r\\n    font-size: 55px;\\r\\n}\\r\\n\\r\\n.leis-font-size-56 {\\r\\n    font-size: 56px;\\r\\n}\\r\\n\\r\\n.leis-font-size-57 {\\r\\n    font-size: 57px;\\r\\n}\\r\\n\\r\\n.leis-font-size-58 {\\r\\n    font-size: 58px;\\r\\n}\\r\\n\\r\\n.leis-font-size-59 {\\r\\n    font-size: 59px;\\r\\n}\\r\\n\\r\\n.leis-font-size-60 {\\r\\n    font-size: 60px;\\r\\n}\\r\\n\\r\\n.leis-font-size-61 {\\r\\n    font-size: 61px;\\r\\n}\\r\\n\\r\\n.leis-font-size-62 {\\r\\n    font-size: 62px;\\r\\n}\\r\\n\\r\\n.leis-font-size-63 {\\r\\n    font-size: 63px;\\r\\n}\\r\\n\\r\\n.leis-font-size-64 {\\r\\n    font-size: 64px;\\r\\n}\\r\\n\\r\\n.leis-font-size-65 {\\r\\n    font-size: 65px;\\r\\n}\\r\\n\\r\\n.leis-font-size-66 {\\r\\n    font-size: 66px;\\r\\n}\\r\\n\\r\\n.leis-font-size-67 {\\r\\n    font-size: 67px;\\r\\n}\\r\\n\\r\\n.leis-font-size-68 {\\r\\n    font-size: 68px;\\r\\n}\\r\\n\\r\\n.leis-font-size-69 {\\r\\n    font-size: 69px;\\r\\n}\\r\\n\\r\\n.leis-font-size-70 {\\r\\n    font-size: 70px;\\r\\n}\\r\\n\\r\\n.leis-font-size-71 {\\r\\n    font-size: 71px;\\r\\n}\\r\\n\\r\\n.leis-font-size-72 {\\r\\n    font-size: 72px;\\r\\n}\\r\\n\\r\\n.leis-font-size-73 {\\r\\n    font-size: 73px;\\r\\n}\\r\\n\\r\\n.leis-font-size-74 {\\r\\n    font-size: 74px;\\r\\n}\\r\\n\\r\\n.leis-font-size-75 {\\r\\n    font-size: 75px;\\r\\n}\\r\\n\\r\\n.leis-font-size-76 {\\r\\n    font-size: 76px;\\r\\n}\\r\\n\\r\\n.leis-font-size-77 {\\r\\n    font-size: 77px;\\r\\n}\\r\\n\\r\\n.leis-font-size-78 {\\r\\n    font-size: 78px;\\r\\n}\\r\\n\\r\\n.leis-font-size-79 {\\r\\n    font-size: 79px;\\r\\n}\\r\\n\\r\\n.leis-font-size-80 {\\r\\n    font-size: 80px;\\r\\n}\\r\\n\\r\\n.leis-font-size-81 {\\r\\n    font-size: 81px;\\r\\n}\\r\\n\\r\\n.leis-font-size-82 {\\r\\n    font-size: 82px;\\r\\n}\\r\\n\\r\\n.leis-font-size-83 {\\r\\n    font-size: 83px;\\r\\n}\\r\\n\\r\\n.leis-font-size-84 {\\r\\n    font-size: 84px;\\r\\n}\\r\\n\\r\\n.leis-font-size-85 {\\r\\n    font-size: 85px;\\r\\n}\\r\\n\\r\\n.leis-font-size-86 {\\r\\n    font-size: 86px;\\r\\n}\\r\\n\\r\\n.leis-font-size-87 {\\r\\n    font-size: 87px;\\r\\n}\\r\\n\\r\\n.leis-font-size-88 {\\r\\n    font-size: 88px;\\r\\n}\\r\\n\\r\\n.leis-font-size-89 {\\r\\n    font-size: 89px;\\r\\n}\\r\\n\\r\\n.leis-font-size-90 {\\r\\n    font-size: 90px;\\r\\n}\\r\\n\\r\\n.leis-font-size-91 {\\r\\n    font-size: 91px;\\r\\n}\\r\\n\\r\\n.leis-font-size-92 {\\r\\n    font-size: 92px;\\r\\n}\\r\\n\\r\\n.leis-font-size-93 {\\r\\n    font-size: 93px;\\r\\n}\\r\\n\\r\\n.leis-font-size-94 {\\r\\n    font-size: 94px;\\r\\n}\\r\\n\\r\\n.leis-font-size-95 {\\r\\n    font-size: 95px;\\r\\n}\\r\\n\\r\\n.leis-font-size-96 {\\r\\n    font-size: 96px;\\r\\n}\\r\\n\\r\\n.leis-font-size-97 {\\r\\n    font-size: 97px;\\r\\n}\\r\\n\\r\\n.leis-font-size-98 {\\r\\n    font-size: 98px;\\r\\n}\\r\\n\\r\\n.leis-font-size-99 {\\r\\n    font-size: 99px;\\r\\n}\\r\\n\\r\\n.leis-font-size-1vw {\\r\\n    font-size: 1vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-2vw {\\r\\n    font-size: 2vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-3vw {\\r\\n    font-size: 3vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-4vw {\\r\\n    font-size: 4vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-5vw {\\r\\n    font-size: 5vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-6vw {\\r\\n    font-size: 6vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-7vw {\\r\\n    font-size: 7vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-8vw {\\r\\n    font-size: 8vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-9vw {\\r\\n    font-size: 9vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-10vw {\\r\\n    font-size: 10vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-11vw {\\r\\n    font-size: 11vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-12vw {\\r\\n    font-size: 12vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-13vw {\\r\\n    font-size: 13vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-14vw {\\r\\n    font-size: 14vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-15vw {\\r\\n    font-size: 15vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-16vw {\\r\\n    font-size: 16vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-17vw {\\r\\n    font-size: 17vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-18vw {\\r\\n    font-size: 18vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-19vw {\\r\\n    font-size: 19vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-20vw {\\r\\n    font-size: 20vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-21vw {\\r\\n    font-size: 21vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-22vw {\\r\\n    font-size: 22vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-23vw {\\r\\n    font-size: 23vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-24vw {\\r\\n    font-size: 24vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-25vw {\\r\\n    font-size: 25vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-26vw {\\r\\n    font-size: 26vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-27vw {\\r\\n    font-size: 27vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-28vw {\\r\\n    font-size: 28vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-29vw {\\r\\n    font-size: 29vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-30vw {\\r\\n    font-size: 30vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-31vw {\\r\\n    font-size: 31vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-32vw {\\r\\n    font-size: 32vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-33vw {\\r\\n    font-size: 33vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-34vw {\\r\\n    font-size: 34vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-35vw {\\r\\n    font-size: 35vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-36vw {\\r\\n    font-size: 36vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-37vw {\\r\\n    font-size: 37vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-38vw {\\r\\n    font-size: 38vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-39vw {\\r\\n    font-size: 39vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-40vw {\\r\\n    font-size: 40vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-41vw {\\r\\n    font-size: 41vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-42vw {\\r\\n    font-size: 42vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-43vw {\\r\\n    font-size: 43vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-44vw {\\r\\n    font-size: 44vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-45vw {\\r\\n    font-size: 45vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-46vw {\\r\\n    font-size: 46vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-47vw {\\r\\n    font-size: 47vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-48vw {\\r\\n    font-size: 48vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-49vw {\\r\\n    font-size: 49vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-50vw {\\r\\n    font-size: 50vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-51vw {\\r\\n    font-size: 51vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-52vw {\\r\\n    font-size: 52vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-53vw {\\r\\n    font-size: 53vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-54vw {\\r\\n    font-size: 54vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-55vw {\\r\\n    font-size: 55vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-56vw {\\r\\n    font-size: 56vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-57vw {\\r\\n    font-size: 57vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-58vw {\\r\\n    font-size: 58vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-59vw {\\r\\n    font-size: 59vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-60vw {\\r\\n    font-size: 60vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-61vw {\\r\\n    font-size: 61vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-62vw {\\r\\n    font-size: 62vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-63vw {\\r\\n    font-size: 63vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-64vw {\\r\\n    font-size: 64vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-65vw {\\r\\n    font-size: 65vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-66vw {\\r\\n    font-size: 66vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-67vw {\\r\\n    font-size: 67vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-68vw {\\r\\n    font-size: 68vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-69vw {\\r\\n    font-size: 69vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-70vw {\\r\\n    font-size: 70vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-71vw {\\r\\n    font-size: 71vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-72vw {\\r\\n    font-size: 72vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-73vw {\\r\\n    font-size: 73vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-74vw {\\r\\n    font-size: 74vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-75vw {\\r\\n    font-size: 75vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-76vw {\\r\\n    font-size: 76vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-77vw {\\r\\n    font-size: 77vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-78vw {\\r\\n    font-size: 78vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-79vw {\\r\\n    font-size: 79vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-80vw {\\r\\n    font-size: 80vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-81vw {\\r\\n    font-size: 81vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-82vw {\\r\\n    font-size: 82vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-83vw {\\r\\n    font-size: 83vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-84vw {\\r\\n    font-size: 84vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-85vw {\\r\\n    font-size: 85vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-86vw {\\r\\n    font-size: 86vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-87vw {\\r\\n    font-size: 87vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-88vw {\\r\\n    font-size: 88vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-89vw {\\r\\n    font-size: 89vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-90vw {\\r\\n    font-size: 90vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-91vw {\\r\\n    font-size: 91vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-92vw {\\r\\n    font-size: 92vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-93vw {\\r\\n    font-size: 93vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-94vw {\\r\\n    font-size: 94vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-95vw {\\r\\n    font-size: 95vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-96vw {\\r\\n    font-size: 96vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-97vw {\\r\\n    font-size: 97vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-98vw {\\r\\n    font-size: 98vw;\\r\\n}\\r\\n\\r\\n.leis-font-size-99vw {\\r\\n    font-size: 99vw;\\r\\n}\\r\\n\\r\\n/* width */\\r\\n.leis-width-1pct {\\r\\n    width: 1%;\\r\\n}\\r\\n\\r\\n.leis-width-2pct {\\r\\n    width: 2%;\\r\\n}\\r\\n\\r\\n.leis-width-3pct {\\r\\n    width: 3%;\\r\\n}\\r\\n\\r\\n.leis-width-4pct {\\r\\n    width: 4%;\\r\\n}\\r\\n\\r\\n.leis-width-5pct {\\r\\n    width: 5%;\\r\\n}\\r\\n\\r\\n.leis-width-6pct {\\r\\n    width: 6%;\\r\\n}\\r\\n\\r\\n.leis-width-7pct {\\r\\n    width: 7%;\\r\\n}\\r\\n\\r\\n.leis-width-8pct {\\r\\n    width: 8%;\\r\\n}\\r\\n\\r\\n.leis-width-9pct {\\r\\n    width: 9%;\\r\\n}\\r\\n\\r\\n.leis-width-10pct {\\r\\n    width: 10%;\\r\\n}\\r\\n\\r\\n.leis-width-11pct {\\r\\n    width: 11%;\\r\\n}\\r\\n\\r\\n.leis-width-12pct {\\r\\n    width: 12%;\\r\\n}\\r\\n\\r\\n.leis-width-13pct {\\r\\n    width: 13%;\\r\\n}\\r\\n\\r\\n.leis-width-14pct {\\r\\n    width: 14%;\\r\\n}\\r\\n\\r\\n.leis-width-15pct {\\r\\n    width: 15%;\\r\\n}\\r\\n\\r\\n.leis-width-16pct {\\r\\n    width: 16%;\\r\\n}\\r\\n\\r\\n.leis-width-17pct {\\r\\n    width: 17%;\\r\\n}\\r\\n\\r\\n.leis-width-18pct {\\r\\n    width: 18%;\\r\\n}\\r\\n\\r\\n.leis-width-19pct {\\r\\n    width: 19%;\\r\\n}\\r\\n\\r\\n.leis-width-20pct {\\r\\n    width: 20%;\\r\\n}\\r\\n\\r\\n.leis-width-21pct {\\r\\n    width: 21%;\\r\\n}\\r\\n\\r\\n.leis-width-22pct {\\r\\n    width: 22%;\\r\\n}\\r\\n\\r\\n.leis-width-23pct {\\r\\n    width: 23%;\\r\\n}\\r\\n\\r\\n.leis-width-24pct {\\r\\n    width: 24%;\\r\\n}\\r\\n\\r\\n.leis-width-25pct {\\r\\n    width: 25%;\\r\\n}\\r\\n\\r\\n.leis-width-26pct {\\r\\n    width: 26%;\\r\\n}\\r\\n\\r\\n.leis-width-27pct {\\r\\n    width: 27%;\\r\\n}\\r\\n\\r\\n.leis-width-28pct {\\r\\n    width: 28%;\\r\\n}\\r\\n\\r\\n.leis-width-29pct {\\r\\n    width: 29%;\\r\\n}\\r\\n\\r\\n.leis-width-30pct {\\r\\n    width: 30%;\\r\\n}\\r\\n\\r\\n.leis-width-31pct {\\r\\n    width: 31%;\\r\\n}\\r\\n\\r\\n.leis-width-32pct {\\r\\n    width: 32%;\\r\\n}\\r\\n\\r\\n.leis-width-33pct {\\r\\n    width: 33%;\\r\\n}\\r\\n\\r\\n.leis-width-34pct {\\r\\n    width: 34%;\\r\\n}\\r\\n\\r\\n.leis-width-35pct {\\r\\n    width: 35%;\\r\\n}\\r\\n\\r\\n.leis-width-36pct {\\r\\n    width: 36%;\\r\\n}\\r\\n\\r\\n.leis-width-37pct {\\r\\n    width: 37%;\\r\\n}\\r\\n\\r\\n.leis-width-38pct {\\r\\n    width: 38%;\\r\\n}\\r\\n\\r\\n.leis-width-39pct {\\r\\n    width: 39%;\\r\\n}\\r\\n\\r\\n.leis-width-40pct {\\r\\n    width: 40%;\\r\\n}\\r\\n\\r\\n.leis-width-41pct {\\r\\n    width: 41%;\\r\\n}\\r\\n\\r\\n.leis-width-42pct {\\r\\n    width: 42%;\\r\\n}\\r\\n\\r\\n.leis-width-43pct {\\r\\n    width: 43%;\\r\\n}\\r\\n\\r\\n.leis-width-44pct {\\r\\n    width: 44%;\\r\\n}\\r\\n\\r\\n.leis-width-45pct {\\r\\n    width: 45%;\\r\\n}\\r\\n\\r\\n.leis-width-46pct {\\r\\n    width: 46%;\\r\\n}\\r\\n\\r\\n.leis-width-47pct {\\r\\n    width: 47%;\\r\\n}\\r\\n\\r\\n.leis-width-48pct {\\r\\n    width: 48%;\\r\\n}\\r\\n\\r\\n.leis-width-49pct {\\r\\n    width: 49%;\\r\\n}\\r\\n\\r\\n.leis-width-50pct {\\r\\n    width: 50%;\\r\\n}\\r\\n\\r\\n.leis-width-51pct {\\r\\n    width: 51%;\\r\\n}\\r\\n\\r\\n.leis-width-52pct {\\r\\n    width: 52%;\\r\\n}\\r\\n\\r\\n.leis-width-53pct {\\r\\n    width: 53%;\\r\\n}\\r\\n\\r\\n.leis-width-54pct {\\r\\n    width: 54%;\\r\\n}\\r\\n\\r\\n.leis-width-55pct {\\r\\n    width: 55%;\\r\\n}\\r\\n\\r\\n.leis-width-56pct {\\r\\n    width: 56%;\\r\\n}\\r\\n\\r\\n.leis-width-57pct {\\r\\n    width: 57%;\\r\\n}\\r\\n\\r\\n.leis-width-58pct {\\r\\n    width: 58%;\\r\\n}\\r\\n\\r\\n.leis-width-59pct {\\r\\n    width: 59%;\\r\\n}\\r\\n\\r\\n.leis-width-60pct {\\r\\n    width: 60%;\\r\\n}\\r\\n\\r\\n.leis-width-61pct {\\r\\n    width: 61%;\\r\\n}\\r\\n\\r\\n.leis-width-62pct {\\r\\n    width: 62%;\\r\\n}\\r\\n\\r\\n.leis-width-63pct {\\r\\n    width: 63%;\\r\\n}\\r\\n\\r\\n.leis-width-64pct {\\r\\n    width: 64%;\\r\\n}\\r\\n\\r\\n.leis-width-65pct {\\r\\n    width: 65%;\\r\\n}\\r\\n\\r\\n.leis-width-66pct {\\r\\n    width: 66%;\\r\\n}\\r\\n\\r\\n.leis-width-67pct {\\r\\n    width: 67%;\\r\\n}\\r\\n\\r\\n.leis-width-68pct {\\r\\n    width: 68%;\\r\\n}\\r\\n\\r\\n.leis-width-69pct {\\r\\n    width: 69%;\\r\\n}\\r\\n\\r\\n.leis-width-70pct {\\r\\n    width: 70%;\\r\\n}\\r\\n\\r\\n.leis-width-71pct {\\r\\n    width: 71%;\\r\\n}\\r\\n\\r\\n.leis-width-72pct {\\r\\n    width: 72%;\\r\\n}\\r\\n\\r\\n.leis-width-73pct {\\r\\n    width: 73%;\\r\\n}\\r\\n\\r\\n.leis-width-74pct {\\r\\n    width: 74%;\\r\\n}\\r\\n\\r\\n.leis-width-75pct {\\r\\n    width: 75%;\\r\\n}\\r\\n\\r\\n.leis-width-76pct {\\r\\n    width: 76%;\\r\\n}\\r\\n\\r\\n.leis-width-77pct {\\r\\n    width: 77%;\\r\\n}\\r\\n\\r\\n.leis-width-78pct {\\r\\n    width: 78%;\\r\\n}\\r\\n\\r\\n.leis-width-79pct {\\r\\n    width: 79%;\\r\\n}\\r\\n\\r\\n.leis-width-80pct {\\r\\n    width: 80%;\\r\\n}\\r\\n\\r\\n.leis-width-81pct {\\r\\n    width: 81%;\\r\\n}\\r\\n\\r\\n.leis-width-82pct {\\r\\n    width: 82%;\\r\\n}\\r\\n\\r\\n.leis-width-83pct {\\r\\n    width: 83%;\\r\\n}\\r\\n\\r\\n.leis-width-84pct {\\r\\n    width: 84%;\\r\\n}\\r\\n\\r\\n.leis-width-85pct {\\r\\n    width: 85%;\\r\\n}\\r\\n\\r\\n.leis-width-86pct {\\r\\n    width: 86%;\\r\\n}\\r\\n\\r\\n.leis-width-87pct {\\r\\n    width: 87%;\\r\\n}\\r\\n\\r\\n.leis-width-88pct {\\r\\n    width: 88%;\\r\\n}\\r\\n\\r\\n.leis-width-89pct {\\r\\n    width: 89%;\\r\\n}\\r\\n\\r\\n.leis-width-90pct {\\r\\n    width: 90%;\\r\\n}\\r\\n\\r\\n.leis-width-91pct {\\r\\n    width: 91%;\\r\\n}\\r\\n\\r\\n.leis-width-92pct {\\r\\n    width: 92%;\\r\\n}\\r\\n\\r\\n.leis-width-93pct {\\r\\n    width: 93%;\\r\\n}\\r\\n\\r\\n.leis-width-94pct {\\r\\n    width: 94%;\\r\\n}\\r\\n\\r\\n.leis-width-95pct {\\r\\n    width: 95%;\\r\\n}\\r\\n\\r\\n.leis-width-96pct {\\r\\n    width: 96%;\\r\\n}\\r\\n\\r\\n.leis-width-97pct {\\r\\n    width: 97%;\\r\\n}\\r\\n\\r\\n.leis-width-98pct {\\r\\n    width: 98%;\\r\\n}\\r\\n\\r\\n.leis-width-99pct {\\r\\n    width: 99%;\\r\\n}\\r\\n\\r\\n/* dispay */\\r\\n.leis-flex {\\r\\n    display: flex;\\r\\n}\\r\\n\\r\\n.leis-gap-5 {\\r\\n    gap: 5px;\\r\\n}\\r\\n\\r\\n*:hover>.leis-tooltip {\\r\\n    visibility: visible;\\r\\n    opacity: 1;\\r\\n    z-index: 1001;\\r\\n}";

    var uiCss = ":root {\\r\\n    --ui5-bigSide: 250px;\\r\\n    --ui5-smallSide: 60px;\\r\\n    --ui5-head: 40px;\\r\\n    --ui5-toolbar: 20px;\\r\\n    --ui5-side-height: calc(100% - (var(--ui5-head) + var(--ui5-toolbar)));\\r\\n}\\r\\n\\r\\n* {\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n    box-sizing: border-box;\\r\\n}\\r\\n\\r\\n.cell {\\r\\n    outline: none;\\r\\n    border: none;\\r\\n    padding: none;\\r\\n    margin: none;\\r\\n    width: 100%;\\r\\n    height: 100%;\\r\\n    overflow: hidden;\\r\\n    text-overflow: ellipsis;\\r\\n    text-align: center;\\r\\n\\r\\n}\\r\\n\\r\\n.cell:not(:first-child) {\\r\\n    border-left: 1px solid #ccc;\\r\\n}\\r\\n\\r\\n.flexTable-container {\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n}\\r\\n\\r\\n.flexTable-table {\\r\\n    border: 1px solid #ccc;\\r\\n}\\r\\n\\r\\n.flexttable-row,\\r\\n.flexttable-head {\\r\\n    width: 100%;\\r\\n    position: relative;\\r\\n    margin: 0;\\r\\n\\r\\n\\r\\n}\\r\\n\\r\\n.flexttable-row {\\r\\n    border-top: 1px solid #ccc;\\r\\n\\r\\n}\\r\\n\\r\\n.flexttable-body {\\r\\n    position: relative;\\r\\n    width: 100%;\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n}\\r\\n\\r\\n/* ui5 */\\r\\n\\r\\n.ui5-head {\\r\\n    position: fixed;\\r\\n    top: 0;\\r\\n    left: 0;\\r\\n    width: 100%;\\r\\n    height: var(--ui5-head);\\r\\n    border-bottom: var(--leis-border);\\r\\n    background-color: var(--leis-container-cl);\\r\\n    z-index: var(--leis-z-index-header);\\r\\n}\\r\\n\\r\\n.leis-sideNav,\\r\\n.ui5-big-side {\\r\\n    height: var(--ui5-side-height);\\r\\n    top: var(--ui5-head);\\r\\n    border-right: var(--leis-border);\\r\\n    box-shadow: none;\\r\\n\\r\\n}\\r\\n\\r\\n.ui5-small-side {\\r\\n    width: var(--ui5-smallSide);\\r\\n}\\r\\n\\r\\n.ui5-small-side i {\\r\\n    font-size: 1.5rem;\\r\\n}\\r\\n\\r\\n.ui5-big-side {\\r\\n    position: fixed;\\r\\n    left: var(--ui5-smallSide);\\r\\n    border-right: var(--leis-border);\\r\\n    background-color: var(--leis-container-cl);\\r\\n    width: var(--ui5-bigSide);\\r\\n    z-index: var(--leis-z-index-header);\\r\\n}\\r\\n\\r\\n.ui5-big-side .coll-item {\\r\\n    color: var(--leis-text-cl) !important;\\r\\n}\\r\\n\\r\\n.ui5-body {\\r\\n    background-color: inherit;\\r\\n    width: calc(100% - (var(--ui5-bigSide) + var(--ui5-smallSide) + 40px));\\r\\n    height: calc(100vh - 75px);\\r\\n    padding: 16px;\\r\\n    margin-left: 320px;\\r\\n    margin-top: 50px;\\r\\n    overflow: hidden;\\r\\n    overflow-x: hidden;\\r\\n    overflow-y: auto;\\r\\n    margin-bottom: 1rem;\\r\\n}\\r\\n\\r\\n.ui5-toolbar {\\r\\n    position: fixed;\\r\\n    bottom: 0;\\r\\n    left: 0;\\r\\n    width: 100%;\\r\\n    height: var(--ui5-toolbar);\\r\\n    background-color: var(--leis-toolbar-cl);\\r\\n    z-index: var(--leis-z-index-drop-up);\\r\\n    border-top: var(--leis-border);\\r\\n}\\r\\n\\r\\n.ui5-controlBar {\\r\\n    background-color: var(--leis-controlBar-cl);\\r\\n    position: absolute;\\r\\n    right: 0;\\r\\n    top: 0;\\r\\n    width: 250px;\\r\\n    height: 100%;\\r\\n}\\r\\n\\r\\n.ui5-cardCtrl {\\r\\n    position: relative;\\r\\n    width: 100%;\\r\\n    height: 100%;\\r\\n    gap: 0.5rem;\\r\\n    justify-content: flex-end;\\r\\n}\\r\\n\\r\\n.ui5-controlBar button,\\r\\n.ui5-controlBar button:active {\\r\\n    font-weight: 500;\\r\\n    border: none;\\r\\n    box-shadow: none !important;\\r\\n    outline: none;\\r\\n    background-color: inherit;\\r\\n    color: var(--leis-text-cl);\\r\\n}\\r\\n\\r\\n.ui5-controlBar button {\\r\\n    padding: 6px 0;\\r\\n}\\r\\n\\r\\n.ui5-controlBar button i {\\r\\n    font-size: 1.2rem;\\r\\n}\\r\\n\\r\\n.ui5-controlBar button:hover {\\r\\n    background-color: inherit;\\r\\n    transform: scale(1.05);\\r\\n    color: var(--leis-text-hv-cl);\\r\\n}\\r\\n\\r\\n.ui5-cardCtrl button[class *=\\"w-icon\\"]:not(:first-child) {\\r\\n    position: relative;\\r\\n    top: 10px;\\r\\n    background-color: var(--leis-default-btn-cl);\\r\\n    padding: 0;\\r\\n    height: 20px;\\r\\n}\\r\\n\\r\\n.ui5-cardCtrl button[class *=\\"w-icon\\"]:not(:first-child) i {\\r\\n    position: relative;\\r\\n    left: 5px;\\r\\n    top: -3px;\\r\\n}\\r\\n\\r\\n.ui5-cardCtrl button[class *=\\"close\\"] {\\r\\n    position: relative;\\r\\n    padding: 0 0.5rem;\\r\\n    border: none;\\r\\n    border-radius: 0;\\r\\n    font-size: 2rem;\\r\\n    font-weight: 400;\\r\\n}\\r\\n\\r\\n.ui5-cardCtrl button[class *=\\"close\\"] span {\\r\\n    position: relative;\\r\\n    left: 2px;\\r\\n    top: -7px;\\r\\n}\\r\\n\\r\\n.ui5-cardCtrl button[class *=\\"close\\"]:hover {\\r\\n    background-color: rgb(232, 58, 58);\\r\\n    color: #fff;\\r\\n}";

    function Ui5() {
        function ui(dir) {
            var leis = leistrap.dep.leis;
            /**
             * User interface with 5 main parts
             */
            class ui5 {
                constructor(parent, smlSide) {
                    this.point = this.#setUi(parent, smlSide);

                }
                #setUi(parent, smlSide) {
                    this.body = leistrap.Div();
                    this.head = leistrap.Div();
                    this.smallSide = leistrap.SideBar(smlSide);
                    this.bigSide = leistrap.Div();
                    this.toolbar = leistrap.Div();
                    this.controlBar = leistrap.Div({ parent: this.head });
                    const cardCtr = leistrap.Div({ parent: this.controlBar });
                    this.notification = leistrap.Button({ text: "Notification" }).getButton();
                    this.notification.setIcon("bi bi-bell");

                    this.minimize = leistrap.Button().getButton();
                    this.minimize.setIcon("bi bi-dash");


                    this.maximize = leistrap.Button().getButton();
                    this.maximize.setIcon("bi bi-clipboard");

                    this.close = leistrap.CloseBtn();

                    // resize the big side
                    const resize = leistrap.Div({ otherAttr: { "class": "resize right-resize" } });
                    this.bigSide.add(resize);

                    const rex = () => leistrap.MPC.toggleClass("resizing-right");
                    leistrap.main.onPressMove(resize, (o) => {
                        if (o.clientX <= leistrap.MPC.getRect().width - 250) {
                            var sw = this.smallSide.point.getRect().width;
                            var w = o.clientX - sw;
                            var bdw = \`calc(100% - (\${w}px + \${sw}px + 40px))\`;
                            var marginLeft = sw + w + 10;
                            this.body.setStyleProp("width", bdw);
                            this.body.setStyleProp("marginLeft", \`\${marginLeft}px\`);
                            this.bigSide.setStyleProp("width", \`\${w}px\`);
                        }
                    }, rex, rex);

                    cardCtr.add(this.notification);
                    cardCtr.add(this.minimize);
                    cardCtr.add(this.maximize);
                    cardCtr.add(this.close);
                    const main = leistrap.Div({
                        content: [this.smallSide, this.bigSide, this.head, this.body, this.toolbar]
                    });
                    this.smallSide.addClass("ui5-small-side");
                    this.controlBar.addClass("ui5-controlBar");
                    leis.addClassList(this.head, "ui5-head");
                    leis.addClassList(cardCtr, "ui5-cardCtrl leis-flex leis-row");
                    leis.addClassList(this.body, "ui5-body");
                    leis.addClassList(this.bigSide, "ui5-big-side");
                    leis.addClassList(this.toolbar, "ui5-toolbar");
                    leis.addClassList(main, "ui5-container");
                    leistrap.addStyle(uiCss);
                    return main
                }
            }

            return ui5
        }
        return ui
    }

    var light = ":root {\\r\\n    --leis-body-cl: #f8f8f8;\\r\\n    --leis-container-cl: #fff;\\r\\n    --leis-default-btn-cl: #e1e9ff;\\r\\n    --leis-select-cl: #98c3f16b;\\r\\n    --leis-select-txt-cl: var(--leis-text-cl);\\r\\n    --leis-active-cl: #0069d9;\\r\\n    --leis-active-txt-cl: #fff;\\r\\n    --leis-text-cl: #5f5d5d;\\r\\n    --leis-text-hv-cl: #000;\\r\\n    --leis-font-size: 1rem;\\r\\n    --leis-toolbar-cl: var(--leis-active-cl);\\r\\n    --leis-controlBar-cl: inherit;\\r\\n    --leis-z-index-header: 100;\\r\\n    --leis-z-index-drop-up: 200;\\r\\n    --leis-z-index-tooltip: 150;\\r\\n    --leis-border: 1px solid #f7eaead8;\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n\\r\\n/* sideBar*/\\r\\n.leis-sideNav {\\r\\n    background-color: var(--leis-container-cl);\\r\\n    z-index: var(--leis-z-index-header);\\r\\n    color: var(--leis-text-cl)\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-list-group .leis-child-group {\\r\\n    color: var(--leis-text-cl)\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-list-group .leis-child-group:not(.colla-item):hover {\\r\\n    background-color: var(--leis-select-cl);\\r\\n    color: var(--leis-select-txt-cl);\\r\\n}\\r\\n\\r\\n.leis-sideNav .leis-list-group .leis-child-group.sideItemActive {\\r\\n    background-color: var(--leis-active-cl);\\r\\n    color: var(--leis-active-txt-cl);\\r\\n}\\r\\n\\r\\n/*coll-item*/\\r\\n\\r\\n.colla-item {\\r\\n    color: var(--leis-text-cl) !important;\\r\\n\\r\\n}";

    var dark = ":root {\\r\\n    --leis-body-cl: #111;\\r\\n    --leis-container-cl: #fff;\\r\\n    --leis-default-btn-cl: #e1e9ff;\\r\\n    --leis-select-cl: #98c3f16b;\\r\\n    --leis-select-txt-cl: var(--leis-text-cl);\\r\\n    --leis-active-cl: #0069d9;\\r\\n    --leis-active-txt-cl: #fff;\\r\\n    --leis-txt-cl: #fff;\\r\\n    --leis-text-hv-cl: #fff;\\r\\n    --leis-font-size: 1rem;\\r\\n    --leis-toolbar-cl: var(--leis-active-cl);\\r\\n    --leis-controlBar-cl: inherit;\\r\\n    --leis-z-index-header: 100;\\r\\n    --leis-z-index-drop-up: 200;\\r\\n    --leis-z-index-tooltip: 150;\\r\\n    --leis-border: 1px solid #f7eaead8;\\r\\n}";

    function Theme() {

        leistrap.defineExtension("theme", function (option, Core, { obj }) {
            if (!option) option = {};
            if (!option.theme) option.theme = "light";
            if (!option.dir) option.dir = "./";


            const _themes_ = {
                light: light,
                dark: dark
            };
            obj.has(option.theme, _themes_) ? option.theme : "light";
            const _theme_ = Core.addStyle(_themes_.light);

            function Theme(name) {
                if (obj.has(name, themes)) {
                    _theme_.addAttr("href",
                        \`\${option.theme.dir}Apps/theme/themes/\${name}.css\`);
                }
            }
            return Theme
        });
    }

    const colorName = {
        "aliceblue": [240, 248, 255],
        "antiquewhite": [250, 235, 215],
        "aqua": [0, 255, 255],
        "aquamarine": [127, 255, 212],
        "azure": [240, 255, 255],
        "beige": [245, 245, 220],
        "bisque": [255, 228, 196],
        "black": [0, 0, 0],
        "blanchedalmond": [255, 235, 205],
        "blue": [0, 0, 255],
        "blueviolet": [138, 43, 226],
        "brown": [165, 42, 42],
        "burlywood": [222, 184, 135],
        "cadetblue": [95, 158, 160],
        "chartreuse": [127, 255, 0],
        "chocolate": [210, 105, 30],
        "coral": [255, 127, 80],
        "cornflowerblue": [100, 149, 237],
        "cornsilk": [255, 248, 220],
        "crimson": [220, 20, 60],
        "cyan": [0, 255, 255],
        "darkblue": [0, 0, 139],
        "darkcyan": [0, 139, 139],
        "darkgoldenrod": [184, 134, 11],
        "darkgray": [169, 169, 169],
        "darkgreen": [0, 100, 0],
        "darkgrey": [169, 169, 169],
        "darkkhaki": [189, 183, 107],
        "darkmagenta": [139, 0, 139],
        "darkolivegreen": [85, 107, 47],
        "darkorange": [255, 140, 0],
        "darkorchid": [153, 50, 204],
        "darkred": [139, 0, 0],
        "darksalmon": [233, 150, 122],
        "darkseagreen": [143, 188, 143],
        "darkslateblue": [72, 61, 139],
        "darkslategray": [47, 79, 79],
        "darkslategrey": [47, 79, 79],
        "darkturquoise": [0, 206, 209],
        "darkviolet": [148, 0, 211],
        "deeppink": [255, 20, 147],
        "deepskyblue": [0, 191, 255],
        "dimgray": [105, 105, 105],
        "dimgrey": [105, 105, 105],
        "dodgerblue": [30, 144, 255],
        "firebrick": [178, 34, 34],
        "floralwhite": [255, 250, 240],
        "forestgreen": [34, 139, 34],
        "fuchsia": [255, 0, 255],
        "gainsboro": [220, 220, 220],
        "ghostwhite": [248, 248, 255],
        "gold": [255, 215, 0],
        "goldenrod": [218, 165, 32],
        "gray": [128, 128, 128],
        "green": [0, 128, 0],
        "greenyellow": [173, 255, 47],
        "grey": [128, 128, 128],
        "honeydew": [240, 255, 240],
        "hotpink": [255, 105, 180],
        "indianred": [205, 92, 92],
        "indigo": [75, 0, 130],
        "ivory": [255, 255, 240],
        "khaki": [240, 230, 140],
        "lavender": [230, 230, 250],
        "lavenderblush": [255, 240, 245],
        "lawngreen": [124, 252, 0],
        "lemonchiffon": [255, 250, 205],
        "lightblue": [173, 216, 230],
        "lightcoral": [240, 128, 128],
        "lightcyan": [224, 255, 255],
        "lightgoldenrodyellow": [250, 250, 210],
        "lightgray": [211, 211, 211],
        "lightgreen": [144, 238, 144],
        "lightgrey": [211, 211, 211],
        "lightpink": [255, 182, 193],
        "lightsalmon": [255, 160, 122],
        "lightseagreen": [32, 178, 170],
        "lightskyblue": [135, 206, 250],
        "lightslategray": [119, 136, 153],
        "lightslategrey": [119, 136, 153],
        "lightsteelblue": [176, 196, 222],
        "lightyellow": [255, 255, 224],
        "lime": [0, 255, 0],
        "limegreen": [50, 205, 50],
        "linen": [250, 240, 230],
        "magenta": [255, 0, 255],
        "maroon": [128, 0, 0],
        "mediumaquamarine": [102, 205, 170],
        "mediumblue": [0, 0, 205],
        "mediumorchid": [186, 85, 211],
        "mediumpurple": [147, 112, 219],
        "mediumseagreen": [60, 179, 113],
        "mediumslateblue": [123, 104, 238],
        "mediumspringgreen": [0, 250, 154],
        "mediumturquoise": [72, 209, 204],
        "mediumvioletred": [199, 21, 133],
        "midnightblue": [25, 25, 112],
        "mintcream": [245, 255, 250],
        "mistyrose": [255, 228, 225],
        "moccasin": [255, 228, 181],
        "navajowhite": [255, 222, 173],
        "navy": [0, 0, 128],
        "oldlace": [253, 245, 230],
        "olive": [128, 128, 0],
        "olivedrab": [107, 142, 35],
        "orange": [255, 165, 0],
        "orangered": [255, 69, 0],
        "orchid": [218, 112, 214],
        "palegoldenrod": [238, 232, 170],
        "palegreen": [152, 251, 152],
        "paleturquoise": [175, 238, 238],
        "palevioletred": [219, 112, 147],
        "papayawhip": [255, 239, 213],
        "peachpuff": [255, 218, 185],
        "peru": [205, 133, 63],
        "pink": [255, 192, 203],
        "plum": [221, 160, 221],
        "powderblue": [176, 224, 230],
        "purple": [128, 0, 128],
        "rebeccapurple": [102, 51, 153],
        "red": [255, 0, 0],
        "rosybrown": [188, 143, 143],
        "royalblue": [65, 105, 225],
        "saddlebrown": [139, 69, 19],
        "salmon": [250, 128, 114],
        "sandybrown": [244, 164, 96],
        "seagreen": [46, 139, 87],
        "seashell": [255, 245, 238],
        "sienna": [160, 82, 45],
        "silver": [192, 192, 192],
        "skyblue": [135, 206, 235],
        "slateblue": [106, 90, 205],
        "slategray": [112, 128, 144],
        "slategrey": [112, 128, 144],
        "snow": [255, 250, 250],
        "springgreen": [0, 255, 127],
        "steelblue": [70, 130, 180],
        "tan": [210, 180, 140],
        "teal": [0, 128, 128],
        "thistle": [216, 191, 216],
        "tomato": [255, 99, 71],
        "turquoise": [64, 224, 208],
        "violet": [238, 130, 238],
        "wheat": [245, 222, 179],
        "white": [255, 255, 255],
        "whitesmoke": [245, 245, 245],
        "yellow": [255, 255, 0],
        "yellowgreen": [154, 205, 50]
    };

    const color = colorName;

    function Cl(value, callback, parent) {
        const c = leistrap.Button({
            parent,
            otherAttr: { "style": \`background:\${value}; border-radius:5px\`, "class": 'colorBtn' },
            attr: { className: ["Da-cl"] },
            eventType: "click",
            eventOnce: function () { callback ? callback(value) : undefined; }
        });
        return c
    }

    function Colorpalette(callback, OnceAdd) {

        const ColorPalette = leistrap.Card({ attr: { className: ["DA-ColorPalette"] } });
        const _color = leistrap.Card({ parent: ColorPalette });
        const addedColors = leistrap.Card({ parent: ColorPalette, content: [leistrap.P({ text: "Mes coleurs" })] });

        //back end get SQLITE API
        if (typeof window.electronAPI !== "undefined") {
            window.electronAPI.initUserColor("works !").then(v => {
                v.forEach(col => Cl(col.name, callback, addedColors));
                addedColors.CASCADE();
            });
        }
        const colorPicker = leistrap.Input({
            otherAttr: { type: 'color', "class": "colorPicker" },
            eventType: "mouseenter",
            eventOnce: function () { setTimeout(() => { this.getAttr("click"); }, 500); }
        });

        colorPicker.addEvent("input", function () { callback ? callback(this.getAttr("value")) : undefined; });
        const choose = leistrap.Card({
            parent: ColorPalette,
            content: [
                leistrap.Span({ text: "Autres couleurs" }),
                colorPicker,
                leistrap.Button({
                    attr: { className: ["choice", "leis-btn-primary "] },
                    text: "Choisir",
                }),
                leistrap.Button({
                    attr: { className: ["Add-color", 'leis-btn-secondary '] },
                    text: "Ajouter",
                    eventType: "click",
                    eventOnce: function () {
                        addedColors.content.push(Cl(colorPicker.getAttr("value"), callback));
                        addedColors.CASCADE();
                        OnceAdd ? OnceAdd(colorPicker.getAttr("value")) : undefined;
                    }
                })
            ],
            attr: { className: ["choiceColor"] }
        });
        choose.addEvent("click", (e) => { e.stopPropagation(); });
        Object.keys(color).forEach(item => _color.content.push(Cl(\`rgb(\${color[item].toString()})\`, callback)));
        return ColorPalette
    }

    function Setting(ls) {
        var conf = {
            dir: "./leistrap1.0/",
            theme: "light",
            plugin: [
                Theme
            ]
        };
        ls(conf);
        return conf
    }

    var tcs = "textarea {\\r\\n    resize: none;\\r\\n}\\r\\n\\r\\n* {\\r\\n    position: relative;\\r\\n}\\r\\n\\r\\n.todo-side-container * {\\r\\n    white-space: nowrap;\\r\\n    text-overflow: ellipsis;\\r\\n    border: none;\\r\\n}\\r\\n\\r\\n.todo-side-taskList {\\r\\n    position: relative;\\r\\n    width: 100%;\\r\\n    top: 0;\\r\\n    left: 0;\\r\\n    height: calc(100vh - 60px);\\r\\n    background-color: inherit;\\r\\n}\\r\\n\\r\\n.todo-side-container {\\r\\n    position: relative;\\r\\n    width: 100%;\\r\\n    margin: 0;\\r\\n    padding: 0;\\r\\n}\\r\\n\\r\\n.todo-side-taskList .sideNavHeader {\\r\\n    color: var(--leis-text-cl);\\r\\n    border-bottom: var(--leis-border);\\r\\n}\\r\\n\\r\\n.todo-side-container .leis-tabs-btn,\\r\\n.todo-side-container .leis-collapse-btn {\\r\\n    font-weight: 400;\\r\\n    font-size: var(--leis-font-size);\\r\\n    padding: 0 18px;\\r\\n\\r\\n}\\r\\n\\r\\n.todo-side-container .leis-collapse-btn::before {\\r\\n    left: 0;\\r\\n}\\r\\n\\r\\n\\r\\n.todo-side-container .leis-collapse-btn:hover,\\r\\n.todo-side-container .leis-collapse-btn.colla-btn-show {\\r\\n    color: var(--leis-primary) !important;\\r\\n    font-weight: 400 !important;\\r\\n    border: none;\\r\\n    box-shadow: none;\\r\\n}\\r\\n\\r\\n.todo-side-container .leis-collapse-btn.active,\\r\\n.todo-side-container .colla-item {\\r\\n    background-color: inherit;\\r\\n\\r\\n}\\r\\n\\r\\n.todo-side-container .leis-collapsing .leis-list-group {\\r\\n    margin-left: 18px;\\r\\n}\\r\\n\\r\\n/* today fun */\\r\\n\\r\\n.dropFolder {\\r\\n    width: 100%;\\r\\n}\\r\\n\\r\\n.dropFolder button {\\r\\n    position: relative;\\r\\n    width: 100% !important;\\r\\n}\\r\\n\\r\\n.todo-colorIcon {\\r\\n    position: absolute;\\r\\n    top: 10px;\\r\\n    right: 20px;\\r\\n    display: flex;\\r\\n    gap: 12px;\\r\\n}\\r\\n\\r\\n.todo-task-color {\\r\\n    position: relative;\\r\\n    width: 13px;\\r\\n    height: 13;\\r\\n    border-radius: 50%;\\r\\n    border: none;\\r\\n    outline: none;\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n.todo-task-info-card {\\r\\n    justify-content: space-between;\\r\\n}\\r\\n\\r\\n.todo-task-info-card *:not(input, .colorBtn) {\\r\\n    width: -moz-fit-content;\\r\\n    width: fit-content;\\r\\n}\\r\\n\\r\\n.todo-task-color {\\r\\n    border-radius: 50%;\\r\\n}\\r\\n\\r\\n.todo-task-container {\\r\\n    position: relative;\\r\\n    margin: 1rem auto;\\r\\n    background-color: var(--leis-card-cl);\\r\\n    min-height: calc(100vh - 200px);\\r\\n    border-radius: 6px;\\r\\n    padding: 20px;\\r\\n    width: 80%;\\r\\n\\r\\n}\\r\\n\\r\\n.todo-pane {\\r\\n    position: sticky;\\r\\n    top: -20px;\\r\\n    z-index: 100;\\r\\n    margin: 1rem 0;\\r\\n    height: 50px;\\r\\n    background-color: var(--leis-body-cl);\\r\\n}\\r\\n\\r\\n.todo-zoneText {\\r\\n    border: none;\\r\\n    position: relative;\\r\\n    width: 100%;\\r\\n    border-radius: inherit;\\r\\n    min-height: 40px;\\r\\n\\r\\n}";

    var customCss = "/* color picker */\\r\\n\\r\\n.DA-ColorPalette {\\r\\n    background-color: rgba(227, 227, 227, 0.492);\\r\\n    border-radius: 6px;\\r\\n    outline: none;\\r\\n    border: none;\\r\\n}\\r\\n\\r\\n.colorPicker {\\r\\n    display: inline-block;\\r\\n    margin-left: 8px;\\r\\n    margin-right: 8px;\\r\\n    border: 1px solid #135dbe;\\r\\n    outline: none;\\r\\n    border-radius: 5px;\\r\\n    width: 30%;\\r\\n}\\r\\n\\r\\n\\r\\n.choice,\\r\\n.Add-color {\\r\\n    display: inline-block;\\r\\n    margin-right: 7px;\\r\\n    border: none;\\r\\n    outline: none;\\r\\n    padding: 4px 8px;\\r\\n    border-radius: 6px;\\r\\n    touch-action: manipulation;\\r\\n    cursor: pointer;\\r\\n    font-weight: 550;\\r\\n    width: 18%;\\r\\n    white-space: nowrap;\\r\\n}\\r\\n\\r\\n.choiceColor {\\r\\n    margin-top: 0.5rem;\\r\\n    border-top: 1px solid var(--DA-line);\\r\\n    padding: 14px 16px;\\r\\n}\\r\\n\\r\\n.colorBtn {\\r\\n    height: 30px;\\r\\n    width: 30px;\\r\\n    cursor: pointer;\\r\\n    outline: none;\\r\\n    border: 1px solid #ddd;\\r\\n    display: inline-block;\\r\\n}";

    const Todo = (function (fnt, leistrap, ui5, leis, dir, data) {

        class TodoTask { }

        /*
        fill information to the small side of the UI5 componet
        this represent all functionalities of this application.
        these function are represented by icons in the first small sidebar on the 
        left side
        */
        const sm = { "items": leistrap.inRange(fnt.length, 0, i => fnt[i].funIcon) };

        /*
        todo app first interface, this is the main page of the todoList app 
        */

        const home = new ui5(undefined, sm);
        /*
        making the tabPage for each functionality.
         create a tab page to the sm side for displaying in detail the current clicked 
         item 
        */

        leistrap.TabPage({
            useContentParent: home.bigSide,
            concatLink: home.smallSide.allItems,
            tabContent: leistrap.inRange(fnt.length, 0, i => {
                let side = setSideTabContent(fnt[i].sideData); fnt[i].side = side; return side
            })
        });
        /*
         creating tabPage for subfunctionalities 
         */

        const bg_tab = leistrap.TabPage({ useContentParent: home.body });
        leistrap.inRange(fnt.length, 0, i => { if (fnt[i].sbFunc) { fnt[i].sbFunc(fnt[i].side.content[0], home, bg_tab); } });

        /**
         * set sidenav for tabContent 
         */
        function setSideTabContent(option) {
            const side = leistrap.SideBar(option);
            const main = leistrap.Div({ content: [side] });
            leis.addClassList(main, "todo-side-container");
            side.addClass("todo-side-taskList");
            return main
        }

        TodoTask.home = home;
        leistrap.addStyle(tcs);
        leistrap.addStyle(customCss);
        return TodoTask
    });

    // today page

    const today = function (ls, data, cp) {

        // creating a input widget which allows us to add a new task directly
        const newInputTask = ls.Input().getTextBox();
        const _addNewtask = newInputTask.add("Nouvelle tâche");
        newInputTask.on(_addNewtask, "keyup", MoreOptionsNewTask);

        // add pane tool 
        var btns = ls.Button().groupBtn();
        btns.setType("light");
        btns.add("Piece jointe");
        var zoneText = btns.add("Zone de text");
        btns.add("Codes");
        var saveTodoPapierBtn = btns.add("Enregister");

        function setZoneText(w) {
            var input = ls.Div({
                otherAttr: {
                    "class": "todo-zoneText leis-textinput",
                    "contenteditable": "true"
                }
            });
            var tables = ls.Table().getTable();
            var myTable = new tables();
            myTable.insertTable(5, 5);
            input.add(myTable);
            w.add(input);
        }
        btns.on(zoneText, "click", function () {
            ls.event.invoke("folder:today", function (o) {
                setZoneText(o.page.currentPage.content[0]);
            });
        });
        btns.on(saveTodoPapierBtn, "click", function () {
            ls.event.invoke("folder:today", function (o) {
                ls.event.invoke("data:update", null, { data: o.page.currentPage._conf.innerHTML });
            });
        });
        btns.setSize("100%");
        ls.event.invoke('folder:today', function (o) {
            if (o.page.currentPage == "main") paneTool.hide();
            o.page.point.addEvent("click", function (e) {
                if (o.page.currentPage === "main") paneTool.hide();
                else { paneTool.show(); }
            });
        });
        var pane = ls.Div({ content: [btns] });
        var paneTool = ls.Div({ otherAttr: { "class": "todo-pane" }, content: [pane] });

        // function which display the more options for adding a new task
        // when a user hits the return key let display our modal
        const modalNewtask = ls.Modal();
        modalNewtask.setSize("400px", "80vh");
        modalNewtask.clear();

        //configure modal buttons
        modalNewtask.closeBtn.setText("Annuler");
        modalNewtask.saveBtn.setText("Enregistrer");

        // get the result or data that user typed from
        // our newTask form
        // adding a task to the folder selected
        function getNewTaskFormResult() {
            var res = {
                title: taskTitle.getValue(_taskTitleInput),
                folder: taskFolder.getValue(_taskFolderInput),
                priority: taskPriority.getChecked(),
                comment: commentTask._conf.value,
                color,
                zoneText: null
            };
            addNewTask(res);
        }

        // create  the function which allows us to add a new task to the folder
        //selected
        function addNewTask(res) {
            var d = setTaskStyle(res);
            var cnt = ls.Div();
            var container = ls.Div({ content: [cnt] });
            ls.dep.leis.addClassList(cnt, "todo-task-container");
            var btn_ = ls.pageButton({
                parent: d.df,
                contentPage: container,
                otherAttr: { "class": "leis-collapse-btn todo-task-link" }
            });

            ls.event.invoke("folder:today", function (o) {
                o.def.add(d.d);
                o.page.addButton(btn_, true);
            });
        }

        // function which creates the default task style
        function setTaskStyle(res) {
            var d = ls.Div();
            var check = ls.Input().getCheckBox();
            check.add(res.title);
            ls.dep.leis.addClassList(d, "todo-task-info-card leis-flex leis-row");
            // creation of the task detail card
            var df = ls.Div();
            var cmnts = ls.P({ text: res.comment });
            var color = ls.Button({
                otherAttr: {
                    style: \`background:\${res.color}; width:15px; height:15px\`,
                    "class": "colorBtn todo-task-color"
                }
            });


            d.addElements(check, cmnts, color, df);
            return { d, df }
        }
        modalNewtask.saveBtn.on("click", getNewTaskFormResult, "newTask");
        //! let create the options what a task can have
        //todo title
        const taskTitle = ls.Input().getTextBox();
        const _taskTitleInput = taskTitle.add("Titre");
        taskTitle.setSize(_taskTitleInput, "85%");
        modalNewtask.add(taskTitle);

        //todo folder
        const defaultValue = data.MainDirs.map(folder => {
            return {
                icon: ls.I({ otherAttr: { "class": "bi bi-folder" } }),
                text: folder.name
            }
        });
        const taskFolder = ls.Input().getTextBox();
        taskFolder.autoComplete = {
            defaultValue: defaultValue.slice(0, 5),
            autoComplete: defaultValue,
            limit: 5
        };
        const _taskFolderInput = taskFolder.add("Dossier", "dossier");
        taskFolder.setSize(_taskFolderInput, "80%");
        modalNewtask.add(taskFolder);

        //todo priority
        const taskPriority = ls.Input().getRadio();
        taskPriority.add("Très élévée", 1);
        taskPriority.add("Elévée", 2,);
        taskPriority.add("Moyenne", 3);
        taskPriority.add("Faible", 4);
        taskPriority.add("Sans priorité", 5);
        modalNewtask.add(ls.H4({ text: "Priorité" }));
        modalNewtask.add(taskPriority);

        //todo colorPicker and Icon
        var color = null;
        const ColorModal = ls.Modal();
        ColorModal.removeHeader();
        ColorModal.removeFooter();
        ColorModal.clear();
        ColorModal.setEffect("modal-zoom-out");
        ColorModal.body.setStyleProp("height", "100%");
        const cp1 = cp(function (value) { color = value; });
        cp1.setStyleProp("height", "100%");
        ColorModal.add(cp1);
        ColorModal.setSize("600px", "60vh");

        function shoColorPicker(e) {
            ColorModal.moveTo(e.clientX - 100, e.clientY - 100);
        }
        const colorIcon = ls.Div({
            attr: { className: ["todo-colorIcon"] },
            content: [
                ls.Span({
                    content: [ls.I({ otherAttr: { "class": "bi bi-palette" } })],
                    events: { click: shoColorPicker }
                }),
                ls.Span({ text: "🙂" }),
            ]
        });
        modalNewtask.add(colorIcon);

        //todo : comment textarea inout
        const commentTask = ls.Textarea({
            otherAttr: {
                placeholder: "Ajouter un commentaire  ",
                "class": "leis-textinput",
                style: "height: 90px; width:98%; margin-left:2px"
            },

        });

        modalNewtask.add(ls.Div({
            tooltip: { postion: "top", text: "commentaire" },
            content: [commentTask]
        }));

        // creating a function which will display the Modal
        // if a user hits return key to the input newtask
        function MoreOptionsNewTask(event) {
            if (event.keyCode === 13) {
                taskTitle.setValue(_taskTitleInput, newInputTask.getValue(_addNewtask));
                modalNewtask.setTitle("Nouvelle tâche");
                modalNewtask.show();
            }

        }
        // emit our newTask form and colorPicker
        ls.event.handle("newTask", function (event) {
            event.send(modalNewtask);
        });
        ls.event.handle("colorPicker", function (event, x, y) {
            ColorModal.moveTo(x, y);
            event.send(ColorModal);
        });

        newInputTask.setSize(_addNewtask, "80%");

        // add all modals into the main object
        ls.event.invoke("main", function (m) {
            m.addElements(modalNewtask, ColorModal);
        });

        // create a today page
        const p = ls.pageButton({
            contentPage: ls.Div({ text: ls.MLorem(20) })
        });
        var def_ = ls.Div();
        const pageTody = ls.Page({
            legend: [p],
            content: [def_]
        });
        // expose the pageToday
        ls.event.handle("folder:today", (event) => event.send({ page: pageTody, def: def_ }));

        // getall Data
        ls.event.invoke("data:all", function (data) {
            data.all.forEach((item, index) => {
                addNewTask(item);
            });
        });
        return ls.Div({
            content: [
                newInputTask,
                paneTool,
                pageTody
            ]
        })

    };

    const tomorrow = function (ls) {
        return ls.Div({ text: "tasks For Tomorrow" })
    };

    const sevenDays = function (ls) {
        return ls.Div({ text: "tasks For  the next week" })
    };

    const inbox = function (ls) {
        return ls.Div({ text: "The inbox taks" })
    };

    const tags = function (ls) {
        return ls.Div({ text: "tags tasks" })
    };

    const folders\$1 = function (ls) {
        return ls.Div({ text: "Cliquez sur un dossier ..." })
    };

    const tasklist = (function (leistrap, data, colorPalette) {

        /*
        taskList functionality

        create a sideBar for taskLisk tab Button.
        the first functionality of the application, it about Todtasks,
        create, modification etc.. of the task. this first functionality contains others 
        subfunctionalities.

            1. Aujourd'hui:         -today
            2. Demain               -tomorrow
            3. Prochains jours      -sevenDays
            4. Boîte de réception   -inbox
            5. Étiquettes*          -tags
            6. Dossiers             -foldes
        we will create a tabPage for each subfunctionlity, these will be in the "ui5.body" part as content
         */

        // create a collapsible for displaying all foldes

        const coll = leistrap.Collapsible({
            caption: "Dossiers",
            content: [leistrap.GroupItem({
                items: leistrap.inRange(10, 0, i => leistrap.Li({ text: \`item \${i}\` }))
            })]
        });
        const dataTaskList = {
            "header": leistrap.P({ text: "Be focus" }),
            "items":
                [
                    { "caption": "Aujourd'hui", "icon": "bi bi-calendar2-range-fill" },
                    { "caption": "Demain", "icon": "bi bi-sunrise-fill" },
                    { "caption": "Prochains jours", "icon": "bi bi-calendar-day-fill" },
                    { "caption": "Boîte de réception", "icon": "bi bi-envelope-paper-fill" },
                    { "caption": "Étiquettes", "icon": "bi bi-tags-fill" }
                ],
            collapsible: [
                [coll]
            ]
        };

        /*
        the default Tab Button , has a default content
         */
        const defaultBtn = leistrap.Input({ otherAttr: { type: "hidden" }, linkName: "default" });
        const defaultContent = leistrap.Div({ text: "Welcome to task list" });

        // options

        const options = [
            today(leistrap, data, colorPalette),
            tomorrow(leistrap),
            sevenDays(leistrap),
            inbox(leistrap),
            tags(leistrap),
            folders\$1(leistrap)
        ];
        /*
          funtionality controller  function   
        */

        function sbFunc(side, home, tab) {
            side.allItems.forEach((i, id) => { tab.addTab(i, options[id], true); });
            tab.addTab(defaultBtn, defaultContent, true);
            home.body.add(defaultBtn);
        }

        /*
        expose the functionality to the entire application
         */

        const TaskList = {
            "funIcon": {
                "icon": "bi bi-card-checklist",
                "action": function () {
                    if (!defaultBtn.dp) {
                        defaultBtn.getAttr("click"); defaultBtn.dp = true;
                    }
                }
            },
            "sideData": dataTaskList,
            "sbFunc": sbFunc,


        };
        return TaskList
    });

    const calendarView = (function (leistrap) {


        const dataViewCalendar = {
            "header": leistrap.P({ text: "Calendar View" }),
            "items": [
                { "caption": "Menseul" }
            ]
        };

        function sbFunc(side, home, tab) {
            tab.addTab(side.allItems[0], leistrap.Div({ text: "leistrap.lorem for calendar view " }), true);
        }
        /*
        expose the functionality to the entire application
         */
        const viewCalendar = {
            "funIcon": { "icon": "bi bi-calendar3" },
            "sideData": dataViewCalendar,
            "sbFunc": sbFunc,

        };
        return viewCalendar
    });

    const trdacking = (function (leistrap) {

        const dataTracking = {
            "header": leistrap.P({ text: "Tracking" }),

        };


        /*
        expose the functionality to the entire application
         */
        const track = {
            "funIcon": { "icon": "bi bi-bar-chart-steps" },
            "sideData": dataTracking,
        };
        return track
    });

    /**
     * 
     * this functionality displays all folders which are in our application
     * and if  a user clicks on one of this folder will display in detail the 
     * folder clicked. 
     */
    const folders = (function (leistrap, data) {

        // creation  the function which will create a new folder when the folder icon is clicked 
        // before  creating a new folder we have to create a form which will help us to do it.
        //todo creating a form NewFolderForm
        // ! i use the DropDown widget for displaying the form 

        var sideBar;
        function newFolder() {
            var input = leistrap.Input().getTextBox();
            var folderInput = input.add(null, "folder", null,
                { attr: { style: "background: var(--leis-body-cl)" } });

            input.setSize(folderInput, "100%");
            sideBar.addItems([
                { "icon": "ni bi-folder", widget: input }
            ]);
            leistrap.event.invoke("newTask", function (modal) {
                modal.setTitle("Nouvelle tâche");
                modal.show();
            });
        }

        // setting  the date 
        const dataFolder = {
            "header": leistrap.P({ text: "Tous les dossiers" }),
            "items": [
                { caption: "Nouveau dossier", icon: "bi bi-folder-plus", action: newFolder }
            ]
        };
        // display all  mainFolders
        data.MainDirs.forEach(folder => dataFolder.items.push(
            { caption: folder.name, "icon": "bi bi-folder" }
        ));

        function sbFunc(side, home, tab) {
            sideBar = side;
        }
        /*
        expose the functionality to the entire application
         */
        const track = {
            "funIcon": { "icon": "bi bi-folder" },
            "sideData": dataFolder,
            sbFunc
        };
        return track
    });

    const MainDirs = [
        { "name": "Aujourd'hui", "widget": "today" },
        { "name": "Demain", "widget": "tomorrow" },
        { "name": "JavaScript" },
        { "name": "Python" },
        { "name": "PHP" },
        { "name": "HTML" },
        { "name": "JAVA" },
        { "name": "C" },
        { "name": "C++" },
        { "name": "C#" },
        { "name": "SQL" },
    ];
    const dataAPI = {
        MainDirs
    };

    const todoTask = (ui5, dir, colorPalette) => Todo(
        [
            tasklist(leistrap, dataAPI, colorPalette),
            calendarView(leistrap),
            trdacking(leistrap),
            folders(leistrap, dataAPI)
        ],
        leistrap,
        ui5,
        leistrap.dep.leis);

    const MyTasks = todoTask;

    function App(setting) {


      const ui = Ui5();

      return leistrap.Div({
        content: [
          MyTasks(ui(setting.dir), setting.dir, Colorpalette).home
        ]
      })
    }

    function leisMain() {

      var param = Setting(leistrap);
      leistrap.whenReady(function () {
        leistrap.event.handle("main", (e) => e.send(this));
        fetch("http://localhost:5000/api/all").then(data => {
          data.json().then(d => leistrap.event.handle("data:all", (event) => event.send(d)));
          console.log(data);
        });
        leistrap.event.handle("data:update", function (event, o) {
          var data = [];
          for (var c of JSON.stringify(o)) {
            data.push(c.charCodeAt(0));
          }
          fetch(\`http://localhost:5000/api-update/\${data.join("_")}\`);
        });
        this.add(App(param));
      });


      leistrap.render("main");
    }

    var leisR = "* {\\r\\n    padding: 0;\\r\\n    margin: 0;\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n.resize {\\r\\n    position: absolute;\\r\\n    background-color: inherit;\\r\\n    -webkit-user-select: none;\\r\\n    user-select: none;\\r\\n    z-index: 1000;\\r\\n\\r\\n}\\r\\n\\r\\n.resize.right-resize {\\r\\n    right: 0;\\r\\n    top: 0;\\r\\n    cursor: e-resize;\\r\\n    width: 7px;\\r\\n    height: 100%;\\r\\n}\\r\\n\\r\\n.resize.left-resize {\\r\\n    left: 0;\\r\\n    top: 0;\\r\\n    cursor: e-resize;\\r\\n    width: 7px;\\r\\n    height: 100%;\\r\\n}\\r\\n\\r\\n.resize.bottom-resize {\\r\\n    bottom: 0;\\r\\n    left: 0;\\r\\n    cursor: s-resize;\\r\\n    width: 100%;\\r\\n    height: 7px;\\r\\n}\\r\\n\\r\\n.resize:hover {\\r\\n    background-color: var(--leis-resize-cl);\\r\\n}\\r\\n\\r\\n.card-resizable {\\r\\n    position: relative !important;\\r\\n}\\r\\n\\r\\n.resizing-right {\\r\\n    cursor: e-resize !important;\\r\\n}\\r\\n\\r\\n.resizing-right .resize.right-resize {\\r\\n    cursor: e-resize !important;\\r\\n    background-color: var(--leis-resize-cl);\\r\\n}";

    var icons = "/*!\\n * Bootstrap Icons v1.10.5 (https://icons.getbootstrap.com/)\\n * Copyright 2019-2023 The Bootstrap Authors\\n * Licensed under MIT (https://github.com/twbs/icons/blob/main/LICENSE)\\n */\\n@font-face {\\n    font-display: block;\\n    font-family: bootstrap-icons;\\n    src: url(\\"./front/leistrap1.0/static/css/font/fonts/bootstrap-icons.woff2\\") format(\\"woff2\\"), url(\\"./front/leistrap1.0/static/css/font/fonts/bootstrap-icons.woff\\") format(\\"woff\\")\\n}\\n\\n.bi::before,\\n[class*=\\" bi-\\"]::before,\\n[class^=bi-]::before {\\n    display: inline-block;\\n    font-family: bootstrap-icons !important;\\n    font-style: normal;\\n    font-weight: 400 !important;\\n    font-variant: normal;\\n    text-transform: none;\\n    line-height: 1;\\n    vertical-align: -.125em;\\n    -webkit-font-smoothing: antialiased;\\n    -moz-osx-font-smoothing: grayscale\\n}\\n\\n.bi-123::before {\\n    content: \\"\\\\f67f\\"\\n}\\n\\n.bi-alarm-fill::before {\\n    content: \\"\\\\f101\\"\\n}\\n\\n.bi-alarm::before {\\n    content: \\"\\\\f102\\"\\n}\\n\\n.bi-align-bottom::before {\\n    content: \\"\\\\f103\\"\\n}\\n\\n.bi-align-center::before {\\n    content: \\"\\\\f104\\"\\n}\\n\\n.bi-align-end::before {\\n    content: \\"\\\\f105\\"\\n}\\n\\n.bi-align-middle::before {\\n    content: \\"\\\\f106\\"\\n}\\n\\n.bi-align-start::before {\\n    content: \\"\\\\f107\\"\\n}\\n\\n.bi-align-top::before {\\n    content: \\"\\\\f108\\"\\n}\\n\\n.bi-alt::before {\\n    content: \\"\\\\f109\\"\\n}\\n\\n.bi-app-indicator::before {\\n    content: \\"\\\\f10a\\"\\n}\\n\\n.bi-app::before {\\n    content: \\"\\\\f10b\\"\\n}\\n\\n.bi-archive-fill::before {\\n    content: \\"\\\\f10c\\"\\n}\\n\\n.bi-archive::before {\\n    content: \\"\\\\f10d\\"\\n}\\n\\n.bi-arrow-90deg-down::before {\\n    content: \\"\\\\f10e\\"\\n}\\n\\n.bi-arrow-90deg-left::before {\\n    content: \\"\\\\f10f\\"\\n}\\n\\n.bi-arrow-90deg-right::before {\\n    content: \\"\\\\f110\\"\\n}\\n\\n.bi-arrow-90deg-up::before {\\n    content: \\"\\\\f111\\"\\n}\\n\\n.bi-arrow-bar-down::before {\\n    content: \\"\\\\f112\\"\\n}\\n\\n.bi-arrow-bar-left::before {\\n    content: \\"\\\\f113\\"\\n}\\n\\n.bi-arrow-bar-right::before {\\n    content: \\"\\\\f114\\"\\n}\\n\\n.bi-arrow-bar-up::before {\\n    content: \\"\\\\f115\\"\\n}\\n\\n.bi-arrow-clockwise::before {\\n    content: \\"\\\\f116\\"\\n}\\n\\n.bi-arrow-counterclockwise::before {\\n    content: \\"\\\\f117\\"\\n}\\n\\n.bi-arrow-down-circle-fill::before {\\n    content: \\"\\\\f118\\"\\n}\\n\\n.bi-arrow-down-circle::before {\\n    content: \\"\\\\f119\\"\\n}\\n\\n.bi-arrow-down-left-circle-fill::before {\\n    content: \\"\\\\f11a\\"\\n}\\n\\n.bi-arrow-down-left-circle::before {\\n    content: \\"\\\\f11b\\"\\n}\\n\\n.bi-arrow-down-left-square-fill::before {\\n    content: \\"\\\\f11c\\"\\n}\\n\\n.bi-arrow-down-left-square::before {\\n    content: \\"\\\\f11d\\"\\n}\\n\\n.bi-arrow-down-left::before {\\n    content: \\"\\\\f11e\\"\\n}\\n\\n.bi-arrow-down-right-circle-fill::before {\\n    content: \\"\\\\f11f\\"\\n}\\n\\n.bi-arrow-down-right-circle::before {\\n    content: \\"\\\\f120\\"\\n}\\n\\n.bi-arrow-down-right-square-fill::before {\\n    content: \\"\\\\f121\\"\\n}\\n\\n.bi-arrow-down-right-square::before {\\n    content: \\"\\\\f122\\"\\n}\\n\\n.bi-arrow-down-right::before {\\n    content: \\"\\\\f123\\"\\n}\\n\\n.bi-arrow-down-short::before {\\n    content: \\"\\\\f124\\"\\n}\\n\\n.bi-arrow-down-square-fill::before {\\n    content: \\"\\\\f125\\"\\n}\\n\\n.bi-arrow-down-square::before {\\n    content: \\"\\\\f126\\"\\n}\\n\\n.bi-arrow-down-up::before {\\n    content: \\"\\\\f127\\"\\n}\\n\\n.bi-arrow-down::before {\\n    content: \\"\\\\f128\\"\\n}\\n\\n.bi-arrow-left-circle-fill::before {\\n    content: \\"\\\\f129\\"\\n}\\n\\n.bi-arrow-left-circle::before {\\n    content: \\"\\\\f12a\\"\\n}\\n\\n.bi-arrow-left-right::before {\\n    content: \\"\\\\f12b\\"\\n}\\n\\n.bi-arrow-left-short::before {\\n    content: \\"\\\\f12c\\"\\n}\\n\\n.bi-arrow-left-square-fill::before {\\n    content: \\"\\\\f12d\\"\\n}\\n\\n.bi-arrow-left-square::before {\\n    content: \\"\\\\f12e\\"\\n}\\n\\n.bi-arrow-left::before {\\n    content: \\"\\\\f12f\\"\\n}\\n\\n.bi-arrow-repeat::before {\\n    content: \\"\\\\f130\\"\\n}\\n\\n.bi-arrow-return-left::before {\\n    content: \\"\\\\f131\\"\\n}\\n\\n.bi-arrow-return-right::before {\\n    content: \\"\\\\f132\\"\\n}\\n\\n.bi-arrow-right-circle-fill::before {\\n    content: \\"\\\\f133\\"\\n}\\n\\n.bi-arrow-right-circle::before {\\n    content: \\"\\\\f134\\"\\n}\\n\\n.bi-arrow-right-short::before {\\n    content: \\"\\\\f135\\"\\n}\\n\\n.bi-arrow-right-square-fill::before {\\n    content: \\"\\\\f136\\"\\n}\\n\\n.bi-arrow-right-square::before {\\n    content: \\"\\\\f137\\"\\n}\\n\\n.bi-arrow-right::before {\\n    content: \\"\\\\f138\\"\\n}\\n\\n.bi-arrow-up-circle-fill::before {\\n    content: \\"\\\\f139\\"\\n}\\n\\n.bi-arrow-up-circle::before {\\n    content: \\"\\\\f13a\\"\\n}\\n\\n.bi-arrow-up-left-circle-fill::before {\\n    content: \\"\\\\f13b\\"\\n}\\n\\n.bi-arrow-up-left-circle::before {\\n    content: \\"\\\\f13c\\"\\n}\\n\\n.bi-arrow-up-left-square-fill::before {\\n    content: \\"\\\\f13d\\"\\n}\\n\\n.bi-arrow-up-left-square::before {\\n    content: \\"\\\\f13e\\"\\n}\\n\\n.bi-arrow-up-left::before {\\n    content: \\"\\\\f13f\\"\\n}\\n\\n.bi-arrow-up-right-circle-fill::before {\\n    content: \\"\\\\f140\\"\\n}\\n\\n.bi-arrow-up-right-circle::before {\\n    content: \\"\\\\f141\\"\\n}\\n\\n.bi-arrow-up-right-square-fill::before {\\n    content: \\"\\\\f142\\"\\n}\\n\\n.bi-arrow-up-right-square::before {\\n    content: \\"\\\\f143\\"\\n}\\n\\n.bi-arrow-up-right::before {\\n    content: \\"\\\\f144\\"\\n}\\n\\n.bi-arrow-up-short::before {\\n    content: \\"\\\\f145\\"\\n}\\n\\n.bi-arrow-up-square-fill::before {\\n    content: \\"\\\\f146\\"\\n}\\n\\n.bi-arrow-up-square::before {\\n    content: \\"\\\\f147\\"\\n}\\n\\n.bi-arrow-up::before {\\n    content: \\"\\\\f148\\"\\n}\\n\\n.bi-arrows-angle-contract::before {\\n    content: \\"\\\\f149\\"\\n}\\n\\n.bi-arrows-angle-expand::before {\\n    content: \\"\\\\f14a\\"\\n}\\n\\n.bi-arrows-collapse::before {\\n    content: \\"\\\\f14b\\"\\n}\\n\\n.bi-arrows-expand::before {\\n    content: \\"\\\\f14c\\"\\n}\\n\\n.bi-arrows-fullscreen::before {\\n    content: \\"\\\\f14d\\"\\n}\\n\\n.bi-arrows-move::before {\\n    content: \\"\\\\f14e\\"\\n}\\n\\n.bi-aspect-ratio-fill::before {\\n    content: \\"\\\\f14f\\"\\n}\\n\\n.bi-aspect-ratio::before {\\n    content: \\"\\\\f150\\"\\n}\\n\\n.bi-asterisk::before {\\n    content: \\"\\\\f151\\"\\n}\\n\\n.bi-at::before {\\n    content: \\"\\\\f152\\"\\n}\\n\\n.bi-award-fill::before {\\n    content: \\"\\\\f153\\"\\n}\\n\\n.bi-award::before {\\n    content: \\"\\\\f154\\"\\n}\\n\\n.bi-back::before {\\n    content: \\"\\\\f155\\"\\n}\\n\\n.bi-backspace-fill::before {\\n    content: \\"\\\\f156\\"\\n}\\n\\n.bi-backspace-reverse-fill::before {\\n    content: \\"\\\\f157\\"\\n}\\n\\n.bi-backspace-reverse::before {\\n    content: \\"\\\\f158\\"\\n}\\n\\n.bi-backspace::before {\\n    content: \\"\\\\f159\\"\\n}\\n\\n.bi-badge-3d-fill::before {\\n    content: \\"\\\\f15a\\"\\n}\\n\\n.bi-badge-3d::before {\\n    content: \\"\\\\f15b\\"\\n}\\n\\n.bi-badge-4k-fill::before {\\n    content: \\"\\\\f15c\\"\\n}\\n\\n.bi-badge-4k::before {\\n    content: \\"\\\\f15d\\"\\n}\\n\\n.bi-badge-8k-fill::before {\\n    content: \\"\\\\f15e\\"\\n}\\n\\n.bi-badge-8k::before {\\n    content: \\"\\\\f15f\\"\\n}\\n\\n.bi-badge-ad-fill::before {\\n    content: \\"\\\\f160\\"\\n}\\n\\n.bi-badge-ad::before {\\n    content: \\"\\\\f161\\"\\n}\\n\\n.bi-badge-ar-fill::before {\\n    content: \\"\\\\f162\\"\\n}\\n\\n.bi-badge-ar::before {\\n    content: \\"\\\\f163\\"\\n}\\n\\n.bi-badge-cc-fill::before {\\n    content: \\"\\\\f164\\"\\n}\\n\\n.bi-badge-cc::before {\\n    content: \\"\\\\f165\\"\\n}\\n\\n.bi-badge-hd-fill::before {\\n    content: \\"\\\\f166\\"\\n}\\n\\n.bi-badge-hd::before {\\n    content: \\"\\\\f167\\"\\n}\\n\\n.bi-badge-tm-fill::before {\\n    content: \\"\\\\f168\\"\\n}\\n\\n.bi-badge-tm::before {\\n    content: \\"\\\\f169\\"\\n}\\n\\n.bi-badge-vo-fill::before {\\n    content: \\"\\\\f16a\\"\\n}\\n\\n.bi-badge-vo::before {\\n    content: \\"\\\\f16b\\"\\n}\\n\\n.bi-badge-vr-fill::before {\\n    content: \\"\\\\f16c\\"\\n}\\n\\n.bi-badge-vr::before {\\n    content: \\"\\\\f16d\\"\\n}\\n\\n.bi-badge-wc-fill::before {\\n    content: \\"\\\\f16e\\"\\n}\\n\\n.bi-badge-wc::before {\\n    content: \\"\\\\f16f\\"\\n}\\n\\n.bi-bag-check-fill::before {\\n    content: \\"\\\\f170\\"\\n}\\n\\n.bi-bag-check::before {\\n    content: \\"\\\\f171\\"\\n}\\n\\n.bi-bag-dash-fill::before {\\n    content: \\"\\\\f172\\"\\n}\\n\\n.bi-bag-dash::before {\\n    content: \\"\\\\f173\\"\\n}\\n\\n.bi-bag-fill::before {\\n    content: \\"\\\\f174\\"\\n}\\n\\n.bi-bag-plus-fill::before {\\n    content: \\"\\\\f175\\"\\n}\\n\\n.bi-bag-plus::before {\\n    content: \\"\\\\f176\\"\\n}\\n\\n.bi-bag-x-fill::before {\\n    content: \\"\\\\f177\\"\\n}\\n\\n.bi-bag-x::before {\\n    content: \\"\\\\f178\\"\\n}\\n\\n.bi-bag::before {\\n    content: \\"\\\\f179\\"\\n}\\n\\n.bi-bar-chart-fill::before {\\n    content: \\"\\\\f17a\\"\\n}\\n\\n.bi-bar-chart-line-fill::before {\\n    content: \\"\\\\f17b\\"\\n}\\n\\n.bi-bar-chart-line::before {\\n    content: \\"\\\\f17c\\"\\n}\\n\\n.bi-bar-chart-steps::before {\\n    content: \\"\\\\f17d\\"\\n}\\n\\n.bi-bar-chart::before {\\n    content: \\"\\\\f17e\\"\\n}\\n\\n.bi-basket-fill::before {\\n    content: \\"\\\\f17f\\"\\n}\\n\\n.bi-basket::before {\\n    content: \\"\\\\f180\\"\\n}\\n\\n.bi-basket2-fill::before {\\n    content: \\"\\\\f181\\"\\n}\\n\\n.bi-basket2::before {\\n    content: \\"\\\\f182\\"\\n}\\n\\n.bi-basket3-fill::before {\\n    content: \\"\\\\f183\\"\\n}\\n\\n.bi-basket3::before {\\n    content: \\"\\\\f184\\"\\n}\\n\\n.bi-battery-charging::before {\\n    content: \\"\\\\f185\\"\\n}\\n\\n.bi-battery-full::before {\\n    content: \\"\\\\f186\\"\\n}\\n\\n.bi-battery-half::before {\\n    content: \\"\\\\f187\\"\\n}\\n\\n.bi-battery::before {\\n    content: \\"\\\\f188\\"\\n}\\n\\n.bi-bell-fill::before {\\n    content: \\"\\\\f189\\"\\n}\\n\\n.bi-bell::before {\\n    content: \\"\\\\f18a\\"\\n}\\n\\n.bi-bezier::before {\\n    content: \\"\\\\f18b\\"\\n}\\n\\n.bi-bezier2::before {\\n    content: \\"\\\\f18c\\"\\n}\\n\\n.bi-bicycle::before {\\n    content: \\"\\\\f18d\\"\\n}\\n\\n.bi-binoculars-fill::before {\\n    content: \\"\\\\f18e\\"\\n}\\n\\n.bi-binoculars::before {\\n    content: \\"\\\\f18f\\"\\n}\\n\\n.bi-blockquote-left::before {\\n    content: \\"\\\\f190\\"\\n}\\n\\n.bi-blockquote-right::before {\\n    content: \\"\\\\f191\\"\\n}\\n\\n.bi-book-fill::before {\\n    content: \\"\\\\f192\\"\\n}\\n\\n.bi-book-half::before {\\n    content: \\"\\\\f193\\"\\n}\\n\\n.bi-book::before {\\n    content: \\"\\\\f194\\"\\n}\\n\\n.bi-bookmark-check-fill::before {\\n    content: \\"\\\\f195\\"\\n}\\n\\n.bi-bookmark-check::before {\\n    content: \\"\\\\f196\\"\\n}\\n\\n.bi-bookmark-dash-fill::before {\\n    content: \\"\\\\f197\\"\\n}\\n\\n.bi-bookmark-dash::before {\\n    content: \\"\\\\f198\\"\\n}\\n\\n.bi-bookmark-fill::before {\\n    content: \\"\\\\f199\\"\\n}\\n\\n.bi-bookmark-heart-fill::before {\\n    content: \\"\\\\f19a\\"\\n}\\n\\n.bi-bookmark-heart::before {\\n    content: \\"\\\\f19b\\"\\n}\\n\\n.bi-bookmark-plus-fill::before {\\n    content: \\"\\\\f19c\\"\\n}\\n\\n.bi-bookmark-plus::before {\\n    content: \\"\\\\f19d\\"\\n}\\n\\n.bi-bookmark-star-fill::before {\\n    content: \\"\\\\f19e\\"\\n}\\n\\n.bi-bookmark-star::before {\\n    content: \\"\\\\f19f\\"\\n}\\n\\n.bi-bookmark-x-fill::before {\\n    content: \\"\\\\f1a0\\"\\n}\\n\\n.bi-bookmark-x::before {\\n    content: \\"\\\\f1a1\\"\\n}\\n\\n.bi-bookmark::before {\\n    content: \\"\\\\f1a2\\"\\n}\\n\\n.bi-bookmarks-fill::before {\\n    content: \\"\\\\f1a3\\"\\n}\\n\\n.bi-bookmarks::before {\\n    content: \\"\\\\f1a4\\"\\n}\\n\\n.bi-bookshelf::before {\\n    content: \\"\\\\f1a5\\"\\n}\\n\\n.bi-bootstrap-fill::before {\\n    content: \\"\\\\f1a6\\"\\n}\\n\\n.bi-bootstrap-reboot::before {\\n    content: \\"\\\\f1a7\\"\\n}\\n\\n.bi-bootstrap::before {\\n    content: \\"\\\\f1a8\\"\\n}\\n\\n.bi-border-all::before {\\n    content: \\"\\\\f1a9\\"\\n}\\n\\n.bi-border-bottom::before {\\n    content: \\"\\\\f1aa\\"\\n}\\n\\n.bi-border-center::before {\\n    content: \\"\\\\f1ab\\"\\n}\\n\\n.bi-border-inner::before {\\n    content: \\"\\\\f1ac\\"\\n}\\n\\n.bi-border-left::before {\\n    content: \\"\\\\f1ad\\"\\n}\\n\\n.bi-border-middle::before {\\n    content: \\"\\\\f1ae\\"\\n}\\n\\n.bi-border-outer::before {\\n    content: \\"\\\\f1af\\"\\n}\\n\\n.bi-border-right::before {\\n    content: \\"\\\\f1b0\\"\\n}\\n\\n.bi-border-style::before {\\n    content: \\"\\\\f1b1\\"\\n}\\n\\n.bi-border-top::before {\\n    content: \\"\\\\f1b2\\"\\n}\\n\\n.bi-border-width::before {\\n    content: \\"\\\\f1b3\\"\\n}\\n\\n.bi-border::before {\\n    content: \\"\\\\f1b4\\"\\n}\\n\\n.bi-bounding-box-circles::before {\\n    content: \\"\\\\f1b5\\"\\n}\\n\\n.bi-bounding-box::before {\\n    content: \\"\\\\f1b6\\"\\n}\\n\\n.bi-box-arrow-down-left::before {\\n    content: \\"\\\\f1b7\\"\\n}\\n\\n.bi-box-arrow-down-right::before {\\n    content: \\"\\\\f1b8\\"\\n}\\n\\n.bi-box-arrow-down::before {\\n    content: \\"\\\\f1b9\\"\\n}\\n\\n.bi-box-arrow-in-down-left::before {\\n    content: \\"\\\\f1ba\\"\\n}\\n\\n.bi-box-arrow-in-down-right::before {\\n    content: \\"\\\\f1bb\\"\\n}\\n\\n.bi-box-arrow-in-down::before {\\n    content: \\"\\\\f1bc\\"\\n}\\n\\n.bi-box-arrow-in-left::before {\\n    content: \\"\\\\f1bd\\"\\n}\\n\\n.bi-box-arrow-in-right::before {\\n    content: \\"\\\\f1be\\"\\n}\\n\\n.bi-box-arrow-in-up-left::before {\\n    content: \\"\\\\f1bf\\"\\n}\\n\\n.bi-box-arrow-in-up-right::before {\\n    content: \\"\\\\f1c0\\"\\n}\\n\\n.bi-box-arrow-in-up::before {\\n    content: \\"\\\\f1c1\\"\\n}\\n\\n.bi-box-arrow-left::before {\\n    content: \\"\\\\f1c2\\"\\n}\\n\\n.bi-box-arrow-right::before {\\n    content: \\"\\\\f1c3\\"\\n}\\n\\n.bi-box-arrow-up-left::before {\\n    content: \\"\\\\f1c4\\"\\n}\\n\\n.bi-box-arrow-up-right::before {\\n    content: \\"\\\\f1c5\\"\\n}\\n\\n.bi-box-arrow-up::before {\\n    content: \\"\\\\f1c6\\"\\n}\\n\\n.bi-box-seam::before {\\n    content: \\"\\\\f1c7\\"\\n}\\n\\n.bi-box::before {\\n    content: \\"\\\\f1c8\\"\\n}\\n\\n.bi-braces::before {\\n    content: \\"\\\\f1c9\\"\\n}\\n\\n.bi-bricks::before {\\n    content: \\"\\\\f1ca\\"\\n}\\n\\n.bi-briefcase-fill::before {\\n    content: \\"\\\\f1cb\\"\\n}\\n\\n.bi-briefcase::before {\\n    content: \\"\\\\f1cc\\"\\n}\\n\\n.bi-brightness-alt-high-fill::before {\\n    content: \\"\\\\f1cd\\"\\n}\\n\\n.bi-brightness-alt-high::before {\\n    content: \\"\\\\f1ce\\"\\n}\\n\\n.bi-brightness-alt-low-fill::before {\\n    content: \\"\\\\f1cf\\"\\n}\\n\\n.bi-brightness-alt-low::before {\\n    content: \\"\\\\f1d0\\"\\n}\\n\\n.bi-brightness-high-fill::before {\\n    content: \\"\\\\f1d1\\"\\n}\\n\\n.bi-brightness-high::before {\\n    content: \\"\\\\f1d2\\"\\n}\\n\\n.bi-brightness-low-fill::before {\\n    content: \\"\\\\f1d3\\"\\n}\\n\\n.bi-brightness-low::before {\\n    content: \\"\\\\f1d4\\"\\n}\\n\\n.bi-broadcast-pin::before {\\n    content: \\"\\\\f1d5\\"\\n}\\n\\n.bi-broadcast::before {\\n    content: \\"\\\\f1d6\\"\\n}\\n\\n.bi-brush-fill::before {\\n    content: \\"\\\\f1d7\\"\\n}\\n\\n.bi-brush::before {\\n    content: \\"\\\\f1d8\\"\\n}\\n\\n.bi-bucket-fill::before {\\n    content: \\"\\\\f1d9\\"\\n}\\n\\n.bi-bucket::before {\\n    content: \\"\\\\f1da\\"\\n}\\n\\n.bi-bug-fill::before {\\n    content: \\"\\\\f1db\\"\\n}\\n\\n.bi-bug::before {\\n    content: \\"\\\\f1dc\\"\\n}\\n\\n.bi-building::before {\\n    content: \\"\\\\f1dd\\"\\n}\\n\\n.bi-bullseye::before {\\n    content: \\"\\\\f1de\\"\\n}\\n\\n.bi-calculator-fill::before {\\n    content: \\"\\\\f1df\\"\\n}\\n\\n.bi-calculator::before {\\n    content: \\"\\\\f1e0\\"\\n}\\n\\n.bi-calendar-check-fill::before {\\n    content: \\"\\\\f1e1\\"\\n}\\n\\n.bi-calendar-check::before {\\n    content: \\"\\\\f1e2\\"\\n}\\n\\n.bi-calendar-date-fill::before {\\n    content: \\"\\\\f1e3\\"\\n}\\n\\n.bi-calendar-date::before {\\n    content: \\"\\\\f1e4\\"\\n}\\n\\n.bi-calendar-day-fill::before {\\n    content: \\"\\\\f1e5\\"\\n}\\n\\n.bi-calendar-day::before {\\n    content: \\"\\\\f1e6\\"\\n}\\n\\n.bi-calendar-event-fill::before {\\n    content: \\"\\\\f1e7\\"\\n}\\n\\n.bi-calendar-event::before {\\n    content: \\"\\\\f1e8\\"\\n}\\n\\n.bi-calendar-fill::before {\\n    content: \\"\\\\f1e9\\"\\n}\\n\\n.bi-calendar-minus-fill::before {\\n    content: \\"\\\\f1ea\\"\\n}\\n\\n.bi-calendar-minus::before {\\n    content: \\"\\\\f1eb\\"\\n}\\n\\n.bi-calendar-month-fill::before {\\n    content: \\"\\\\f1ec\\"\\n}\\n\\n.bi-calendar-month::before {\\n    content: \\"\\\\f1ed\\"\\n}\\n\\n.bi-calendar-plus-fill::before {\\n    content: \\"\\\\f1ee\\"\\n}\\n\\n.bi-calendar-plus::before {\\n    content: \\"\\\\f1ef\\"\\n}\\n\\n.bi-calendar-range-fill::before {\\n    content: \\"\\\\f1f0\\"\\n}\\n\\n.bi-calendar-range::before {\\n    content: \\"\\\\f1f1\\"\\n}\\n\\n.bi-calendar-week-fill::before {\\n    content: \\"\\\\f1f2\\"\\n}\\n\\n.bi-calendar-week::before {\\n    content: \\"\\\\f1f3\\"\\n}\\n\\n.bi-calendar-x-fill::before {\\n    content: \\"\\\\f1f4\\"\\n}\\n\\n.bi-calendar-x::before {\\n    content: \\"\\\\f1f5\\"\\n}\\n\\n.bi-calendar::before {\\n    content: \\"\\\\f1f6\\"\\n}\\n\\n.bi-calendar2-check-fill::before {\\n    content: \\"\\\\f1f7\\"\\n}\\n\\n.bi-calendar2-check::before {\\n    content: \\"\\\\f1f8\\"\\n}\\n\\n.bi-calendar2-date-fill::before {\\n    content: \\"\\\\f1f9\\"\\n}\\n\\n.bi-calendar2-date::before {\\n    content: \\"\\\\f1fa\\"\\n}\\n\\n.bi-calendar2-day-fill::before {\\n    content: \\"\\\\f1fb\\"\\n}\\n\\n.bi-calendar2-day::before {\\n    content: \\"\\\\f1fc\\"\\n}\\n\\n.bi-calendar2-event-fill::before {\\n    content: \\"\\\\f1fd\\"\\n}\\n\\n.bi-calendar2-event::before {\\n    content: \\"\\\\f1fe\\"\\n}\\n\\n.bi-calendar2-fill::before {\\n    content: \\"\\\\f1ff\\"\\n}\\n\\n.bi-calendar2-minus-fill::before {\\n    content: \\"\\\\f200\\"\\n}\\n\\n.bi-calendar2-minus::before {\\n    content: \\"\\\\f201\\"\\n}\\n\\n.bi-calendar2-month-fill::before {\\n    content: \\"\\\\f202\\"\\n}\\n\\n.bi-calendar2-month::before {\\n    content: \\"\\\\f203\\"\\n}\\n\\n.bi-calendar2-plus-fill::before {\\n    content: \\"\\\\f204\\"\\n}\\n\\n.bi-calendar2-plus::before {\\n    content: \\"\\\\f205\\"\\n}\\n\\n.bi-calendar2-range-fill::before {\\n    content: \\"\\\\f206\\"\\n}\\n\\n.bi-calendar2-range::before {\\n    content: \\"\\\\f207\\"\\n}\\n\\n.bi-calendar2-week-fill::before {\\n    content: \\"\\\\f208\\"\\n}\\n\\n.bi-calendar2-week::before {\\n    content: \\"\\\\f209\\"\\n}\\n\\n.bi-calendar2-x-fill::before {\\n    content: \\"\\\\f20a\\"\\n}\\n\\n.bi-calendar2-x::before {\\n    content: \\"\\\\f20b\\"\\n}\\n\\n.bi-calendar2::before {\\n    content: \\"\\\\f20c\\"\\n}\\n\\n.bi-calendar3-event-fill::before {\\n    content: \\"\\\\f20d\\"\\n}\\n\\n.bi-calendar3-event::before {\\n    content: \\"\\\\f20e\\"\\n}\\n\\n.bi-calendar3-fill::before {\\n    content: \\"\\\\f20f\\"\\n}\\n\\n.bi-calendar3-range-fill::before {\\n    content: \\"\\\\f210\\"\\n}\\n\\n.bi-calendar3-range::before {\\n    content: \\"\\\\f211\\"\\n}\\n\\n.bi-calendar3-week-fill::before {\\n    content: \\"\\\\f212\\"\\n}\\n\\n.bi-calendar3-week::before {\\n    content: \\"\\\\f213\\"\\n}\\n\\n.bi-calendar3::before {\\n    content: \\"\\\\f214\\"\\n}\\n\\n.bi-calendar4-event::before {\\n    content: \\"\\\\f215\\"\\n}\\n\\n.bi-calendar4-range::before {\\n    content: \\"\\\\f216\\"\\n}\\n\\n.bi-calendar4-week::before {\\n    content: \\"\\\\f217\\"\\n}\\n\\n.bi-calendar4::before {\\n    content: \\"\\\\f218\\"\\n}\\n\\n.bi-camera-fill::before {\\n    content: \\"\\\\f219\\"\\n}\\n\\n.bi-camera-reels-fill::before {\\n    content: \\"\\\\f21a\\"\\n}\\n\\n.bi-camera-reels::before {\\n    content: \\"\\\\f21b\\"\\n}\\n\\n.bi-camera-video-fill::before {\\n    content: \\"\\\\f21c\\"\\n}\\n\\n.bi-camera-video-off-fill::before {\\n    content: \\"\\\\f21d\\"\\n}\\n\\n.bi-camera-video-off::before {\\n    content: \\"\\\\f21e\\"\\n}\\n\\n.bi-camera-video::before {\\n    content: \\"\\\\f21f\\"\\n}\\n\\n.bi-camera::before {\\n    content: \\"\\\\f220\\"\\n}\\n\\n.bi-camera2::before {\\n    content: \\"\\\\f221\\"\\n}\\n\\n.bi-capslock-fill::before {\\n    content: \\"\\\\f222\\"\\n}\\n\\n.bi-capslock::before {\\n    content: \\"\\\\f223\\"\\n}\\n\\n.bi-card-checklist::before {\\n    content: \\"\\\\f224\\"\\n}\\n\\n.bi-card-heading::before {\\n    content: \\"\\\\f225\\"\\n}\\n\\n.bi-card-image::before {\\n    content: \\"\\\\f226\\"\\n}\\n\\n.bi-card-list::before {\\n    content: \\"\\\\f227\\"\\n}\\n\\n.bi-card-text::before {\\n    content: \\"\\\\f228\\"\\n}\\n\\n.bi-caret-down-fill::before {\\n    content: \\"\\\\f229\\"\\n}\\n\\n.bi-caret-down-square-fill::before {\\n    content: \\"\\\\f22a\\"\\n}\\n\\n.bi-caret-down-square::before {\\n    content: \\"\\\\f22b\\"\\n}\\n\\n.bi-caret-down::before {\\n    content: \\"\\\\f22c\\"\\n}\\n\\n.bi-caret-left-fill::before {\\n    content: \\"\\\\f22d\\"\\n}\\n\\n.bi-caret-left-square-fill::before {\\n    content: \\"\\\\f22e\\"\\n}\\n\\n.bi-caret-left-square::before {\\n    content: \\"\\\\f22f\\"\\n}\\n\\n.bi-caret-left::before {\\n    content: \\"\\\\f230\\"\\n}\\n\\n.bi-caret-right-fill::before {\\n    content: \\"\\\\f231\\"\\n}\\n\\n.bi-caret-right-square-fill::before {\\n    content: \\"\\\\f232\\"\\n}\\n\\n.bi-caret-right-square::before {\\n    content: \\"\\\\f233\\"\\n}\\n\\n.bi-caret-right::before {\\n    content: \\"\\\\f234\\"\\n}\\n\\n.bi-caret-up-fill::before {\\n    content: \\"\\\\f235\\"\\n}\\n\\n.bi-caret-up-square-fill::before {\\n    content: \\"\\\\f236\\"\\n}\\n\\n.bi-caret-up-square::before {\\n    content: \\"\\\\f237\\"\\n}\\n\\n.bi-caret-up::before {\\n    content: \\"\\\\f238\\"\\n}\\n\\n.bi-cart-check-fill::before {\\n    content: \\"\\\\f239\\"\\n}\\n\\n.bi-cart-check::before {\\n    content: \\"\\\\f23a\\"\\n}\\n\\n.bi-cart-dash-fill::before {\\n    content: \\"\\\\f23b\\"\\n}\\n\\n.bi-cart-dash::before {\\n    content: \\"\\\\f23c\\"\\n}\\n\\n.bi-cart-fill::before {\\n    content: \\"\\\\f23d\\"\\n}\\n\\n.bi-cart-plus-fill::before {\\n    content: \\"\\\\f23e\\"\\n}\\n\\n.bi-cart-plus::before {\\n    content: \\"\\\\f23f\\"\\n}\\n\\n.bi-cart-x-fill::before {\\n    content: \\"\\\\f240\\"\\n}\\n\\n.bi-cart-x::before {\\n    content: \\"\\\\f241\\"\\n}\\n\\n.bi-cart::before {\\n    content: \\"\\\\f242\\"\\n}\\n\\n.bi-cart2::before {\\n    content: \\"\\\\f243\\"\\n}\\n\\n.bi-cart3::before {\\n    content: \\"\\\\f244\\"\\n}\\n\\n.bi-cart4::before {\\n    content: \\"\\\\f245\\"\\n}\\n\\n.bi-cash-stack::before {\\n    content: \\"\\\\f246\\"\\n}\\n\\n.bi-cash::before {\\n    content: \\"\\\\f247\\"\\n}\\n\\n.bi-cast::before {\\n    content: \\"\\\\f248\\"\\n}\\n\\n.bi-chat-dots-fill::before {\\n    content: \\"\\\\f249\\"\\n}\\n\\n.bi-chat-dots::before {\\n    content: \\"\\\\f24a\\"\\n}\\n\\n.bi-chat-fill::before {\\n    content: \\"\\\\f24b\\"\\n}\\n\\n.bi-chat-left-dots-fill::before {\\n    content: \\"\\\\f24c\\"\\n}\\n\\n.bi-chat-left-dots::before {\\n    content: \\"\\\\f24d\\"\\n}\\n\\n.bi-chat-left-fill::before {\\n    content: \\"\\\\f24e\\"\\n}\\n\\n.bi-chat-left-quote-fill::before {\\n    content: \\"\\\\f24f\\"\\n}\\n\\n.bi-chat-left-quote::before {\\n    content: \\"\\\\f250\\"\\n}\\n\\n.bi-chat-left-text-fill::before {\\n    content: \\"\\\\f251\\"\\n}\\n\\n.bi-chat-left-text::before {\\n    content: \\"\\\\f252\\"\\n}\\n\\n.bi-chat-left::before {\\n    content: \\"\\\\f253\\"\\n}\\n\\n.bi-chat-quote-fill::before {\\n    content: \\"\\\\f254\\"\\n}\\n\\n.bi-chat-quote::before {\\n    content: \\"\\\\f255\\"\\n}\\n\\n.bi-chat-right-dots-fill::before {\\n    content: \\"\\\\f256\\"\\n}\\n\\n.bi-chat-right-dots::before {\\n    content: \\"\\\\f257\\"\\n}\\n\\n.bi-chat-right-fill::before {\\n    content: \\"\\\\f258\\"\\n}\\n\\n.bi-chat-right-quote-fill::before {\\n    content: \\"\\\\f259\\"\\n}\\n\\n.bi-chat-right-quote::before {\\n    content: \\"\\\\f25a\\"\\n}\\n\\n.bi-chat-right-text-fill::before {\\n    content: \\"\\\\f25b\\"\\n}\\n\\n.bi-chat-right-text::before {\\n    content: \\"\\\\f25c\\"\\n}\\n\\n.bi-chat-right::before {\\n    content: \\"\\\\f25d\\"\\n}\\n\\n.bi-chat-square-dots-fill::before {\\n    content: \\"\\\\f25e\\"\\n}\\n\\n.bi-chat-square-dots::before {\\n    content: \\"\\\\f25f\\"\\n}\\n\\n.bi-chat-square-fill::before {\\n    content: \\"\\\\f260\\"\\n}\\n\\n.bi-chat-square-quote-fill::before {\\n    content: \\"\\\\f261\\"\\n}\\n\\n.bi-chat-square-quote::before {\\n    content: \\"\\\\f262\\"\\n}\\n\\n.bi-chat-square-text-fill::before {\\n    content: \\"\\\\f263\\"\\n}\\n\\n.bi-chat-square-text::before {\\n    content: \\"\\\\f264\\"\\n}\\n\\n.bi-chat-square::before {\\n    content: \\"\\\\f265\\"\\n}\\n\\n.bi-chat-text-fill::before {\\n    content: \\"\\\\f266\\"\\n}\\n\\n.bi-chat-text::before {\\n    content: \\"\\\\f267\\"\\n}\\n\\n.bi-chat::before {\\n    content: \\"\\\\f268\\"\\n}\\n\\n.bi-check-all::before {\\n    content: \\"\\\\f269\\"\\n}\\n\\n.bi-check-circle-fill::before {\\n    content: \\"\\\\f26a\\"\\n}\\n\\n.bi-check-circle::before {\\n    content: \\"\\\\f26b\\"\\n}\\n\\n.bi-check-square-fill::before {\\n    content: \\"\\\\f26c\\"\\n}\\n\\n.bi-check-square::before {\\n    content: \\"\\\\f26d\\"\\n}\\n\\n.bi-check::before {\\n    content: \\"\\\\f26e\\"\\n}\\n\\n.bi-check2-all::before {\\n    content: \\"\\\\f26f\\"\\n}\\n\\n.bi-check2-circle::before {\\n    content: \\"\\\\f270\\"\\n}\\n\\n.bi-check2-square::before {\\n    content: \\"\\\\f271\\"\\n}\\n\\n.bi-check2::before {\\n    content: \\"\\\\f272\\"\\n}\\n\\n.bi-chevron-bar-contract::before {\\n    content: \\"\\\\f273\\"\\n}\\n\\n.bi-chevron-bar-down::before {\\n    content: \\"\\\\f274\\"\\n}\\n\\n.bi-chevron-bar-expand::before {\\n    content: \\"\\\\f275\\"\\n}\\n\\n.bi-chevron-bar-left::before {\\n    content: \\"\\\\f276\\"\\n}\\n\\n.bi-chevron-bar-right::before {\\n    content: \\"\\\\f277\\"\\n}\\n\\n.bi-chevron-bar-up::before {\\n    content: \\"\\\\f278\\"\\n}\\n\\n.bi-chevron-compact-down::before {\\n    content: \\"\\\\f279\\"\\n}\\n\\n.bi-chevron-compact-left::before {\\n    content: \\"\\\\f27a\\"\\n}\\n\\n.bi-chevron-compact-right::before {\\n    content: \\"\\\\f27b\\"\\n}\\n\\n.bi-chevron-compact-up::before {\\n    content: \\"\\\\f27c\\"\\n}\\n\\n.bi-chevron-contract::before {\\n    content: \\"\\\\f27d\\"\\n}\\n\\n.bi-chevron-double-down::before {\\n    content: \\"\\\\f27e\\"\\n}\\n\\n.bi-chevron-double-left::before {\\n    content: \\"\\\\f27f\\"\\n}\\n\\n.bi-chevron-double-right::before {\\n    content: \\"\\\\f280\\"\\n}\\n\\n.bi-chevron-double-up::before {\\n    content: \\"\\\\f281\\"\\n}\\n\\n.bi-chevron-down::before {\\n    content: \\"\\\\f282\\"\\n}\\n\\n.bi-chevron-expand::before {\\n    content: \\"\\\\f283\\"\\n}\\n\\n.bi-chevron-left::before {\\n    content: \\"\\\\f284\\"\\n}\\n\\n.bi-chevron-right::before {\\n    content: \\"\\\\f285\\"\\n}\\n\\n.bi-chevron-up::before {\\n    content: \\"\\\\f286\\"\\n}\\n\\n.bi-circle-fill::before {\\n    content: \\"\\\\f287\\"\\n}\\n\\n.bi-circle-half::before {\\n    content: \\"\\\\f288\\"\\n}\\n\\n.bi-circle-square::before {\\n    content: \\"\\\\f289\\"\\n}\\n\\n.bi-circle::before {\\n    content: \\"\\\\f28a\\"\\n}\\n\\n.bi-clipboard-check::before {\\n    content: \\"\\\\f28b\\"\\n}\\n\\n.bi-clipboard-data::before {\\n    content: \\"\\\\f28c\\"\\n}\\n\\n.bi-clipboard-minus::before {\\n    content: \\"\\\\f28d\\"\\n}\\n\\n.bi-clipboard-plus::before {\\n    content: \\"\\\\f28e\\"\\n}\\n\\n.bi-clipboard-x::before {\\n    content: \\"\\\\f28f\\"\\n}\\n\\n.bi-clipboard::before {\\n    content: \\"\\\\f290\\"\\n}\\n\\n.bi-clock-fill::before {\\n    content: \\"\\\\f291\\"\\n}\\n\\n.bi-clock-history::before {\\n    content: \\"\\\\f292\\"\\n}\\n\\n.bi-clock::before {\\n    content: \\"\\\\f293\\"\\n}\\n\\n.bi-cloud-arrow-down-fill::before {\\n    content: \\"\\\\f294\\"\\n}\\n\\n.bi-cloud-arrow-down::before {\\n    content: \\"\\\\f295\\"\\n}\\n\\n.bi-cloud-arrow-up-fill::before {\\n    content: \\"\\\\f296\\"\\n}\\n\\n.bi-cloud-arrow-up::before {\\n    content: \\"\\\\f297\\"\\n}\\n\\n.bi-cloud-check-fill::before {\\n    content: \\"\\\\f298\\"\\n}\\n\\n.bi-cloud-check::before {\\n    content: \\"\\\\f299\\"\\n}\\n\\n.bi-cloud-download-fill::before {\\n    content: \\"\\\\f29a\\"\\n}\\n\\n.bi-cloud-download::before {\\n    content: \\"\\\\f29b\\"\\n}\\n\\n.bi-cloud-drizzle-fill::before {\\n    content: \\"\\\\f29c\\"\\n}\\n\\n.bi-cloud-drizzle::before {\\n    content: \\"\\\\f29d\\"\\n}\\n\\n.bi-cloud-fill::before {\\n    content: \\"\\\\f29e\\"\\n}\\n\\n.bi-cloud-fog-fill::before {\\n    content: \\"\\\\f29f\\"\\n}\\n\\n.bi-cloud-fog::before {\\n    content: \\"\\\\f2a0\\"\\n}\\n\\n.bi-cloud-fog2-fill::before {\\n    content: \\"\\\\f2a1\\"\\n}\\n\\n.bi-cloud-fog2::before {\\n    content: \\"\\\\f2a2\\"\\n}\\n\\n.bi-cloud-hail-fill::before {\\n    content: \\"\\\\f2a3\\"\\n}\\n\\n.bi-cloud-hail::before {\\n    content: \\"\\\\f2a4\\"\\n}\\n\\n.bi-cloud-haze-fill::before {\\n    content: \\"\\\\f2a6\\"\\n}\\n\\n.bi-cloud-haze::before {\\n    content: \\"\\\\f2a7\\"\\n}\\n\\n.bi-cloud-haze2-fill::before {\\n    content: \\"\\\\f2a8\\"\\n}\\n\\n.bi-cloud-lightning-fill::before {\\n    content: \\"\\\\f2a9\\"\\n}\\n\\n.bi-cloud-lightning-rain-fill::before {\\n    content: \\"\\\\f2aa\\"\\n}\\n\\n.bi-cloud-lightning-rain::before {\\n    content: \\"\\\\f2ab\\"\\n}\\n\\n.bi-cloud-lightning::before {\\n    content: \\"\\\\f2ac\\"\\n}\\n\\n.bi-cloud-minus-fill::before {\\n    content: \\"\\\\f2ad\\"\\n}\\n\\n.bi-cloud-minus::before {\\n    content: \\"\\\\f2ae\\"\\n}\\n\\n.bi-cloud-moon-fill::before {\\n    content: \\"\\\\f2af\\"\\n}\\n\\n.bi-cloud-moon::before {\\n    content: \\"\\\\f2b0\\"\\n}\\n\\n.bi-cloud-plus-fill::before {\\n    content: \\"\\\\f2b1\\"\\n}\\n\\n.bi-cloud-plus::before {\\n    content: \\"\\\\f2b2\\"\\n}\\n\\n.bi-cloud-rain-fill::before {\\n    content: \\"\\\\f2b3\\"\\n}\\n\\n.bi-cloud-rain-heavy-fill::before {\\n    content: \\"\\\\f2b4\\"\\n}\\n\\n.bi-cloud-rain-heavy::before {\\n    content: \\"\\\\f2b5\\"\\n}\\n\\n.bi-cloud-rain::before {\\n    content: \\"\\\\f2b6\\"\\n}\\n\\n.bi-cloud-slash-fill::before {\\n    content: \\"\\\\f2b7\\"\\n}\\n\\n.bi-cloud-slash::before {\\n    content: \\"\\\\f2b8\\"\\n}\\n\\n.bi-cloud-sleet-fill::before {\\n    content: \\"\\\\f2b9\\"\\n}\\n\\n.bi-cloud-sleet::before {\\n    content: \\"\\\\f2ba\\"\\n}\\n\\n.bi-cloud-snow-fill::before {\\n    content: \\"\\\\f2bb\\"\\n}\\n\\n.bi-cloud-snow::before {\\n    content: \\"\\\\f2bc\\"\\n}\\n\\n.bi-cloud-sun-fill::before {\\n    content: \\"\\\\f2bd\\"\\n}\\n\\n.bi-cloud-sun::before {\\n    content: \\"\\\\f2be\\"\\n}\\n\\n.bi-cloud-upload-fill::before {\\n    content: \\"\\\\f2bf\\"\\n}\\n\\n.bi-cloud-upload::before {\\n    content: \\"\\\\f2c0\\"\\n}\\n\\n.bi-cloud::before {\\n    content: \\"\\\\f2c1\\"\\n}\\n\\n.bi-clouds-fill::before {\\n    content: \\"\\\\f2c2\\"\\n}\\n\\n.bi-clouds::before {\\n    content: \\"\\\\f2c3\\"\\n}\\n\\n.bi-cloudy-fill::before {\\n    content: \\"\\\\f2c4\\"\\n}\\n\\n.bi-cloudy::before {\\n    content: \\"\\\\f2c5\\"\\n}\\n\\n.bi-code-slash::before {\\n    content: \\"\\\\f2c6\\"\\n}\\n\\n.bi-code-square::before {\\n    content: \\"\\\\f2c7\\"\\n}\\n\\n.bi-code::before {\\n    content: \\"\\\\f2c8\\"\\n}\\n\\n.bi-collection-fill::before {\\n    content: \\"\\\\f2c9\\"\\n}\\n\\n.bi-collection-play-fill::before {\\n    content: \\"\\\\f2ca\\"\\n}\\n\\n.bi-collection-play::before {\\n    content: \\"\\\\f2cb\\"\\n}\\n\\n.bi-collection::before {\\n    content: \\"\\\\f2cc\\"\\n}\\n\\n.bi-columns-gap::before {\\n    content: \\"\\\\f2cd\\"\\n}\\n\\n.bi-columns::before {\\n    content: \\"\\\\f2ce\\"\\n}\\n\\n.bi-command::before {\\n    content: \\"\\\\f2cf\\"\\n}\\n\\n.bi-compass-fill::before {\\n    content: \\"\\\\f2d0\\"\\n}\\n\\n.bi-compass::before {\\n    content: \\"\\\\f2d1\\"\\n}\\n\\n.bi-cone-striped::before {\\n    content: \\"\\\\f2d2\\"\\n}\\n\\n.bi-cone::before {\\n    content: \\"\\\\f2d3\\"\\n}\\n\\n.bi-controller::before {\\n    content: \\"\\\\f2d4\\"\\n}\\n\\n.bi-cpu-fill::before {\\n    content: \\"\\\\f2d5\\"\\n}\\n\\n.bi-cpu::before {\\n    content: \\"\\\\f2d6\\"\\n}\\n\\n.bi-credit-card-2-back-fill::before {\\n    content: \\"\\\\f2d7\\"\\n}\\n\\n.bi-credit-card-2-back::before {\\n    content: \\"\\\\f2d8\\"\\n}\\n\\n.bi-credit-card-2-front-fill::before {\\n    content: \\"\\\\f2d9\\"\\n}\\n\\n.bi-credit-card-2-front::before {\\n    content: \\"\\\\f2da\\"\\n}\\n\\n.bi-credit-card-fill::before {\\n    content: \\"\\\\f2db\\"\\n}\\n\\n.bi-credit-card::before {\\n    content: \\"\\\\f2dc\\"\\n}\\n\\n.bi-crop::before {\\n    content: \\"\\\\f2dd\\"\\n}\\n\\n.bi-cup-fill::before {\\n    content: \\"\\\\f2de\\"\\n}\\n\\n.bi-cup-straw::before {\\n    content: \\"\\\\f2df\\"\\n}\\n\\n.bi-cup::before {\\n    content: \\"\\\\f2e0\\"\\n}\\n\\n.bi-cursor-fill::before {\\n    content: \\"\\\\f2e1\\"\\n}\\n\\n.bi-cursor-text::before {\\n    content: \\"\\\\f2e2\\"\\n}\\n\\n.bi-cursor::before {\\n    content: \\"\\\\f2e3\\"\\n}\\n\\n.bi-dash-circle-dotted::before {\\n    content: \\"\\\\f2e4\\"\\n}\\n\\n.bi-dash-circle-fill::before {\\n    content: \\"\\\\f2e5\\"\\n}\\n\\n.bi-dash-circle::before {\\n    content: \\"\\\\f2e6\\"\\n}\\n\\n.bi-dash-square-dotted::before {\\n    content: \\"\\\\f2e7\\"\\n}\\n\\n.bi-dash-square-fill::before {\\n    content: \\"\\\\f2e8\\"\\n}\\n\\n.bi-dash-square::before {\\n    content: \\"\\\\f2e9\\"\\n}\\n\\n.bi-dash::before {\\n    content: \\"\\\\f2ea\\"\\n}\\n\\n.bi-diagram-2-fill::before {\\n    content: \\"\\\\f2eb\\"\\n}\\n\\n.bi-diagram-2::before {\\n    content: \\"\\\\f2ec\\"\\n}\\n\\n.bi-diagram-3-fill::before {\\n    content: \\"\\\\f2ed\\"\\n}\\n\\n.bi-diagram-3::before {\\n    content: \\"\\\\f2ee\\"\\n}\\n\\n.bi-diamond-fill::before {\\n    content: \\"\\\\f2ef\\"\\n}\\n\\n.bi-diamond-half::before {\\n    content: \\"\\\\f2f0\\"\\n}\\n\\n.bi-diamond::before {\\n    content: \\"\\\\f2f1\\"\\n}\\n\\n.bi-dice-1-fill::before {\\n    content: \\"\\\\f2f2\\"\\n}\\n\\n.bi-dice-1::before {\\n    content: \\"\\\\f2f3\\"\\n}\\n\\n.bi-dice-2-fill::before {\\n    content: \\"\\\\f2f4\\"\\n}\\n\\n.bi-dice-2::before {\\n    content: \\"\\\\f2f5\\"\\n}\\n\\n.bi-dice-3-fill::before {\\n    content: \\"\\\\f2f6\\"\\n}\\n\\n.bi-dice-3::before {\\n    content: \\"\\\\f2f7\\"\\n}\\n\\n.bi-dice-4-fill::before {\\n    content: \\"\\\\f2f8\\"\\n}\\n\\n.bi-dice-4::before {\\n    content: \\"\\\\f2f9\\"\\n}\\n\\n.bi-dice-5-fill::before {\\n    content: \\"\\\\f2fa\\"\\n}\\n\\n.bi-dice-5::before {\\n    content: \\"\\\\f2fb\\"\\n}\\n\\n.bi-dice-6-fill::before {\\n    content: \\"\\\\f2fc\\"\\n}\\n\\n.bi-dice-6::before {\\n    content: \\"\\\\f2fd\\"\\n}\\n\\n.bi-disc-fill::before {\\n    content: \\"\\\\f2fe\\"\\n}\\n\\n.bi-disc::before {\\n    content: \\"\\\\f2ff\\"\\n}\\n\\n.bi-discord::before {\\n    content: \\"\\\\f300\\"\\n}\\n\\n.bi-display-fill::before {\\n    content: \\"\\\\f301\\"\\n}\\n\\n.bi-display::before {\\n    content: \\"\\\\f302\\"\\n}\\n\\n.bi-distribute-horizontal::before {\\n    content: \\"\\\\f303\\"\\n}\\n\\n.bi-distribute-vertical::before {\\n    content: \\"\\\\f304\\"\\n}\\n\\n.bi-door-closed-fill::before {\\n    content: \\"\\\\f305\\"\\n}\\n\\n.bi-door-closed::before {\\n    content: \\"\\\\f306\\"\\n}\\n\\n.bi-door-open-fill::before {\\n    content: \\"\\\\f307\\"\\n}\\n\\n.bi-door-open::before {\\n    content: \\"\\\\f308\\"\\n}\\n\\n.bi-dot::before {\\n    content: \\"\\\\f309\\"\\n}\\n\\n.bi-download::before {\\n    content: \\"\\\\f30a\\"\\n}\\n\\n.bi-droplet-fill::before {\\n    content: \\"\\\\f30b\\"\\n}\\n\\n.bi-droplet-half::before {\\n    content: \\"\\\\f30c\\"\\n}\\n\\n.bi-droplet::before {\\n    content: \\"\\\\f30d\\"\\n}\\n\\n.bi-earbuds::before {\\n    content: \\"\\\\f30e\\"\\n}\\n\\n.bi-easel-fill::before {\\n    content: \\"\\\\f30f\\"\\n}\\n\\n.bi-easel::before {\\n    content: \\"\\\\f310\\"\\n}\\n\\n.bi-egg-fill::before {\\n    content: \\"\\\\f311\\"\\n}\\n\\n.bi-egg-fried::before {\\n    content: \\"\\\\f312\\"\\n}\\n\\n.bi-egg::before {\\n    content: \\"\\\\f313\\"\\n}\\n\\n.bi-eject-fill::before {\\n    content: \\"\\\\f314\\"\\n}\\n\\n.bi-eject::before {\\n    content: \\"\\\\f315\\"\\n}\\n\\n.bi-emoji-angry-fill::before {\\n    content: \\"\\\\f316\\"\\n}\\n\\n.bi-emoji-angry::before {\\n    content: \\"\\\\f317\\"\\n}\\n\\n.bi-emoji-dizzy-fill::before {\\n    content: \\"\\\\f318\\"\\n}\\n\\n.bi-emoji-dizzy::before {\\n    content: \\"\\\\f319\\"\\n}\\n\\n.bi-emoji-expressionless-fill::before {\\n    content: \\"\\\\f31a\\"\\n}\\n\\n.bi-emoji-expressionless::before {\\n    content: \\"\\\\f31b\\"\\n}\\n\\n.bi-emoji-frown-fill::before {\\n    content: \\"\\\\f31c\\"\\n}\\n\\n.bi-emoji-frown::before {\\n    content: \\"\\\\f31d\\"\\n}\\n\\n.bi-emoji-heart-eyes-fill::before {\\n    content: \\"\\\\f31e\\"\\n}\\n\\n.bi-emoji-heart-eyes::before {\\n    content: \\"\\\\f31f\\"\\n}\\n\\n.bi-emoji-laughing-fill::before {\\n    content: \\"\\\\f320\\"\\n}\\n\\n.bi-emoji-laughing::before {\\n    content: \\"\\\\f321\\"\\n}\\n\\n.bi-emoji-neutral-fill::before {\\n    content: \\"\\\\f322\\"\\n}\\n\\n.bi-emoji-neutral::before {\\n    content: \\"\\\\f323\\"\\n}\\n\\n.bi-emoji-smile-fill::before {\\n    content: \\"\\\\f324\\"\\n}\\n\\n.bi-emoji-smile-upside-down-fill::before {\\n    content: \\"\\\\f325\\"\\n}\\n\\n.bi-emoji-smile-upside-down::before {\\n    content: \\"\\\\f326\\"\\n}\\n\\n.bi-emoji-smile::before {\\n    content: \\"\\\\f327\\"\\n}\\n\\n.bi-emoji-sunglasses-fill::before {\\n    content: \\"\\\\f328\\"\\n}\\n\\n.bi-emoji-sunglasses::before {\\n    content: \\"\\\\f329\\"\\n}\\n\\n.bi-emoji-wink-fill::before {\\n    content: \\"\\\\f32a\\"\\n}\\n\\n.bi-emoji-wink::before {\\n    content: \\"\\\\f32b\\"\\n}\\n\\n.bi-envelope-fill::before {\\n    content: \\"\\\\f32c\\"\\n}\\n\\n.bi-envelope-open-fill::before {\\n    content: \\"\\\\f32d\\"\\n}\\n\\n.bi-envelope-open::before {\\n    content: \\"\\\\f32e\\"\\n}\\n\\n.bi-envelope::before {\\n    content: \\"\\\\f32f\\"\\n}\\n\\n.bi-eraser-fill::before {\\n    content: \\"\\\\f330\\"\\n}\\n\\n.bi-eraser::before {\\n    content: \\"\\\\f331\\"\\n}\\n\\n.bi-exclamation-circle-fill::before {\\n    content: \\"\\\\f332\\"\\n}\\n\\n.bi-exclamation-circle::before {\\n    content: \\"\\\\f333\\"\\n}\\n\\n.bi-exclamation-diamond-fill::before {\\n    content: \\"\\\\f334\\"\\n}\\n\\n.bi-exclamation-diamond::before {\\n    content: \\"\\\\f335\\"\\n}\\n\\n.bi-exclamation-octagon-fill::before {\\n    content: \\"\\\\f336\\"\\n}\\n\\n.bi-exclamation-octagon::before {\\n    content: \\"\\\\f337\\"\\n}\\n\\n.bi-exclamation-square-fill::before {\\n    content: \\"\\\\f338\\"\\n}\\n\\n.bi-exclamation-square::before {\\n    content: \\"\\\\f339\\"\\n}\\n\\n.bi-exclamation-triangle-fill::before {\\n    content: \\"\\\\f33a\\"\\n}\\n\\n.bi-exclamation-triangle::before {\\n    content: \\"\\\\f33b\\"\\n}\\n\\n.bi-exclamation::before {\\n    content: \\"\\\\f33c\\"\\n}\\n\\n.bi-exclude::before {\\n    content: \\"\\\\f33d\\"\\n}\\n\\n.bi-eye-fill::before {\\n    content: \\"\\\\f33e\\"\\n}\\n\\n.bi-eye-slash-fill::before {\\n    content: \\"\\\\f33f\\"\\n}\\n\\n.bi-eye-slash::before {\\n    content: \\"\\\\f340\\"\\n}\\n\\n.bi-eye::before {\\n    content: \\"\\\\f341\\"\\n}\\n\\n.bi-eyedropper::before {\\n    content: \\"\\\\f342\\"\\n}\\n\\n.bi-eyeglasses::before {\\n    content: \\"\\\\f343\\"\\n}\\n\\n.bi-facebook::before {\\n    content: \\"\\\\f344\\"\\n}\\n\\n.bi-file-arrow-down-fill::before {\\n    content: \\"\\\\f345\\"\\n}\\n\\n.bi-file-arrow-down::before {\\n    content: \\"\\\\f346\\"\\n}\\n\\n.bi-file-arrow-up-fill::before {\\n    content: \\"\\\\f347\\"\\n}\\n\\n.bi-file-arrow-up::before {\\n    content: \\"\\\\f348\\"\\n}\\n\\n.bi-file-bar-graph-fill::before {\\n    content: \\"\\\\f349\\"\\n}\\n\\n.bi-file-bar-graph::before {\\n    content: \\"\\\\f34a\\"\\n}\\n\\n.bi-file-binary-fill::before {\\n    content: \\"\\\\f34b\\"\\n}\\n\\n.bi-file-binary::before {\\n    content: \\"\\\\f34c\\"\\n}\\n\\n.bi-file-break-fill::before {\\n    content: \\"\\\\f34d\\"\\n}\\n\\n.bi-file-break::before {\\n    content: \\"\\\\f34e\\"\\n}\\n\\n.bi-file-check-fill::before {\\n    content: \\"\\\\f34f\\"\\n}\\n\\n.bi-file-check::before {\\n    content: \\"\\\\f350\\"\\n}\\n\\n.bi-file-code-fill::before {\\n    content: \\"\\\\f351\\"\\n}\\n\\n.bi-file-code::before {\\n    content: \\"\\\\f352\\"\\n}\\n\\n.bi-file-diff-fill::before {\\n    content: \\"\\\\f353\\"\\n}\\n\\n.bi-file-diff::before {\\n    content: \\"\\\\f354\\"\\n}\\n\\n.bi-file-earmark-arrow-down-fill::before {\\n    content: \\"\\\\f355\\"\\n}\\n\\n.bi-file-earmark-arrow-down::before {\\n    content: \\"\\\\f356\\"\\n}\\n\\n.bi-file-earmark-arrow-up-fill::before {\\n    content: \\"\\\\f357\\"\\n}\\n\\n.bi-file-earmark-arrow-up::before {\\n    content: \\"\\\\f358\\"\\n}\\n\\n.bi-file-earmark-bar-graph-fill::before {\\n    content: \\"\\\\f359\\"\\n}\\n\\n.bi-file-earmark-bar-graph::before {\\n    content: \\"\\\\f35a\\"\\n}\\n\\n.bi-file-earmark-binary-fill::before {\\n    content: \\"\\\\f35b\\"\\n}\\n\\n.bi-file-earmark-binary::before {\\n    content: \\"\\\\f35c\\"\\n}\\n\\n.bi-file-earmark-break-fill::before {\\n    content: \\"\\\\f35d\\"\\n}\\n\\n.bi-file-earmark-break::before {\\n    content: \\"\\\\f35e\\"\\n}\\n\\n.bi-file-earmark-check-fill::before {\\n    content: \\"\\\\f35f\\"\\n}\\n\\n.bi-file-earmark-check::before {\\n    content: \\"\\\\f360\\"\\n}\\n\\n.bi-file-earmark-code-fill::before {\\n    content: \\"\\\\f361\\"\\n}\\n\\n.bi-file-earmark-code::before {\\n    content: \\"\\\\f362\\"\\n}\\n\\n.bi-file-earmark-diff-fill::before {\\n    content: \\"\\\\f363\\"\\n}\\n\\n.bi-file-earmark-diff::before {\\n    content: \\"\\\\f364\\"\\n}\\n\\n.bi-file-earmark-easel-fill::before {\\n    content: \\"\\\\f365\\"\\n}\\n\\n.bi-file-earmark-easel::before {\\n    content: \\"\\\\f366\\"\\n}\\n\\n.bi-file-earmark-excel-fill::before {\\n    content: \\"\\\\f367\\"\\n}\\n\\n.bi-file-earmark-excel::before {\\n    content: \\"\\\\f368\\"\\n}\\n\\n.bi-file-earmark-fill::before {\\n    content: \\"\\\\f369\\"\\n}\\n\\n.bi-file-earmark-font-fill::before {\\n    content: \\"\\\\f36a\\"\\n}\\n\\n.bi-file-earmark-font::before {\\n    content: \\"\\\\f36b\\"\\n}\\n\\n.bi-file-earmark-image-fill::before {\\n    content: \\"\\\\f36c\\"\\n}\\n\\n.bi-file-earmark-image::before {\\n    content: \\"\\\\f36d\\"\\n}\\n\\n.bi-file-earmark-lock-fill::before {\\n    content: \\"\\\\f36e\\"\\n}\\n\\n.bi-file-earmark-lock::before {\\n    content: \\"\\\\f36f\\"\\n}\\n\\n.bi-file-earmark-lock2-fill::before {\\n    content: \\"\\\\f370\\"\\n}\\n\\n.bi-file-earmark-lock2::before {\\n    content: \\"\\\\f371\\"\\n}\\n\\n.bi-file-earmark-medical-fill::before {\\n    content: \\"\\\\f372\\"\\n}\\n\\n.bi-file-earmark-medical::before {\\n    content: \\"\\\\f373\\"\\n}\\n\\n.bi-file-earmark-minus-fill::before {\\n    content: \\"\\\\f374\\"\\n}\\n\\n.bi-file-earmark-minus::before {\\n    content: \\"\\\\f375\\"\\n}\\n\\n.bi-file-earmark-music-fill::before {\\n    content: \\"\\\\f376\\"\\n}\\n\\n.bi-file-earmark-music::before {\\n    content: \\"\\\\f377\\"\\n}\\n\\n.bi-file-earmark-person-fill::before {\\n    content: \\"\\\\f378\\"\\n}\\n\\n.bi-file-earmark-person::before {\\n    content: \\"\\\\f379\\"\\n}\\n\\n.bi-file-earmark-play-fill::before {\\n    content: \\"\\\\f37a\\"\\n}\\n\\n.bi-file-earmark-play::before {\\n    content: \\"\\\\f37b\\"\\n}\\n\\n.bi-file-earmark-plus-fill::before {\\n    content: \\"\\\\f37c\\"\\n}\\n\\n.bi-file-earmark-plus::before {\\n    content: \\"\\\\f37d\\"\\n}\\n\\n.bi-file-earmark-post-fill::before {\\n    content: \\"\\\\f37e\\"\\n}\\n\\n.bi-file-earmark-post::before {\\n    content: \\"\\\\f37f\\"\\n}\\n\\n.bi-file-earmark-ppt-fill::before {\\n    content: \\"\\\\f380\\"\\n}\\n\\n.bi-file-earmark-ppt::before {\\n    content: \\"\\\\f381\\"\\n}\\n\\n.bi-file-earmark-richtext-fill::before {\\n    content: \\"\\\\f382\\"\\n}\\n\\n.bi-file-earmark-richtext::before {\\n    content: \\"\\\\f383\\"\\n}\\n\\n.bi-file-earmark-ruled-fill::before {\\n    content: \\"\\\\f384\\"\\n}\\n\\n.bi-file-earmark-ruled::before {\\n    content: \\"\\\\f385\\"\\n}\\n\\n.bi-file-earmark-slides-fill::before {\\n    content: \\"\\\\f386\\"\\n}\\n\\n.bi-file-earmark-slides::before {\\n    content: \\"\\\\f387\\"\\n}\\n\\n.bi-file-earmark-spreadsheet-fill::before {\\n    content: \\"\\\\f388\\"\\n}\\n\\n.bi-file-earmark-spreadsheet::before {\\n    content: \\"\\\\f389\\"\\n}\\n\\n.bi-file-earmark-text-fill::before {\\n    content: \\"\\\\f38a\\"\\n}\\n\\n.bi-file-earmark-text::before {\\n    content: \\"\\\\f38b\\"\\n}\\n\\n.bi-file-earmark-word-fill::before {\\n    content: \\"\\\\f38c\\"\\n}\\n\\n.bi-file-earmark-word::before {\\n    content: \\"\\\\f38d\\"\\n}\\n\\n.bi-file-earmark-x-fill::before {\\n    content: \\"\\\\f38e\\"\\n}\\n\\n.bi-file-earmark-x::before {\\n    content: \\"\\\\f38f\\"\\n}\\n\\n.bi-file-earmark-zip-fill::before {\\n    content: \\"\\\\f390\\"\\n}\\n\\n.bi-file-earmark-zip::before {\\n    content: \\"\\\\f391\\"\\n}\\n\\n.bi-file-earmark::before {\\n    content: \\"\\\\f392\\"\\n}\\n\\n.bi-file-easel-fill::before {\\n    content: \\"\\\\f393\\"\\n}\\n\\n.bi-file-easel::before {\\n    content: \\"\\\\f394\\"\\n}\\n\\n.bi-file-excel-fill::before {\\n    content: \\"\\\\f395\\"\\n}\\n\\n.bi-file-excel::before {\\n    content: \\"\\\\f396\\"\\n}\\n\\n.bi-file-fill::before {\\n    content: \\"\\\\f397\\"\\n}\\n\\n.bi-file-font-fill::before {\\n    content: \\"\\\\f398\\"\\n}\\n\\n.bi-file-font::before {\\n    content: \\"\\\\f399\\"\\n}\\n\\n.bi-file-image-fill::before {\\n    content: \\"\\\\f39a\\"\\n}\\n\\n.bi-file-image::before {\\n    content: \\"\\\\f39b\\"\\n}\\n\\n.bi-file-lock-fill::before {\\n    content: \\"\\\\f39c\\"\\n}\\n\\n.bi-file-lock::before {\\n    content: \\"\\\\f39d\\"\\n}\\n\\n.bi-file-lock2-fill::before {\\n    content: \\"\\\\f39e\\"\\n}\\n\\n.bi-file-lock2::before {\\n    content: \\"\\\\f39f\\"\\n}\\n\\n.bi-file-medical-fill::before {\\n    content: \\"\\\\f3a0\\"\\n}\\n\\n.bi-file-medical::before {\\n    content: \\"\\\\f3a1\\"\\n}\\n\\n.bi-file-minus-fill::before {\\n    content: \\"\\\\f3a2\\"\\n}\\n\\n.bi-file-minus::before {\\n    content: \\"\\\\f3a3\\"\\n}\\n\\n.bi-file-music-fill::before {\\n    content: \\"\\\\f3a4\\"\\n}\\n\\n.bi-file-music::before {\\n    content: \\"\\\\f3a5\\"\\n}\\n\\n.bi-file-person-fill::before {\\n    content: \\"\\\\f3a6\\"\\n}\\n\\n.bi-file-person::before {\\n    content: \\"\\\\f3a7\\"\\n}\\n\\n.bi-file-play-fill::before {\\n    content: \\"\\\\f3a8\\"\\n}\\n\\n.bi-file-play::before {\\n    content: \\"\\\\f3a9\\"\\n}\\n\\n.bi-file-plus-fill::before {\\n    content: \\"\\\\f3aa\\"\\n}\\n\\n.bi-file-plus::before {\\n    content: \\"\\\\f3ab\\"\\n}\\n\\n.bi-file-post-fill::before {\\n    content: \\"\\\\f3ac\\"\\n}\\n\\n.bi-file-post::before {\\n    content: \\"\\\\f3ad\\"\\n}\\n\\n.bi-file-ppt-fill::before {\\n    content: \\"\\\\f3ae\\"\\n}\\n\\n.bi-file-ppt::before {\\n    content: \\"\\\\f3af\\"\\n}\\n\\n.bi-file-richtext-fill::before {\\n    content: \\"\\\\f3b0\\"\\n}\\n\\n.bi-file-richtext::before {\\n    content: \\"\\\\f3b1\\"\\n}\\n\\n.bi-file-ruled-fill::before {\\n    content: \\"\\\\f3b2\\"\\n}\\n\\n.bi-file-ruled::before {\\n    content: \\"\\\\f3b3\\"\\n}\\n\\n.bi-file-slides-fill::before {\\n    content: \\"\\\\f3b4\\"\\n}\\n\\n.bi-file-slides::before {\\n    content: \\"\\\\f3b5\\"\\n}\\n\\n.bi-file-spreadsheet-fill::before {\\n    content: \\"\\\\f3b6\\"\\n}\\n\\n.bi-file-spreadsheet::before {\\n    content: \\"\\\\f3b7\\"\\n}\\n\\n.bi-file-text-fill::before {\\n    content: \\"\\\\f3b8\\"\\n}\\n\\n.bi-file-text::before {\\n    content: \\"\\\\f3b9\\"\\n}\\n\\n.bi-file-word-fill::before {\\n    content: \\"\\\\f3ba\\"\\n}\\n\\n.bi-file-word::before {\\n    content: \\"\\\\f3bb\\"\\n}\\n\\n.bi-file-x-fill::before {\\n    content: \\"\\\\f3bc\\"\\n}\\n\\n.bi-file-x::before {\\n    content: \\"\\\\f3bd\\"\\n}\\n\\n.bi-file-zip-fill::before {\\n    content: \\"\\\\f3be\\"\\n}\\n\\n.bi-file-zip::before {\\n    content: \\"\\\\f3bf\\"\\n}\\n\\n.bi-file::before {\\n    content: \\"\\\\f3c0\\"\\n}\\n\\n.bi-files-alt::before {\\n    content: \\"\\\\f3c1\\"\\n}\\n\\n.bi-files::before {\\n    content: \\"\\\\f3c2\\"\\n}\\n\\n.bi-film::before {\\n    content: \\"\\\\f3c3\\"\\n}\\n\\n.bi-filter-circle-fill::before {\\n    content: \\"\\\\f3c4\\"\\n}\\n\\n.bi-filter-circle::before {\\n    content: \\"\\\\f3c5\\"\\n}\\n\\n.bi-filter-left::before {\\n    content: \\"\\\\f3c6\\"\\n}\\n\\n.bi-filter-right::before {\\n    content: \\"\\\\f3c7\\"\\n}\\n\\n.bi-filter-square-fill::before {\\n    content: \\"\\\\f3c8\\"\\n}\\n\\n.bi-filter-square::before {\\n    content: \\"\\\\f3c9\\"\\n}\\n\\n.bi-filter::before {\\n    content: \\"\\\\f3ca\\"\\n}\\n\\n.bi-flag-fill::before {\\n    content: \\"\\\\f3cb\\"\\n}\\n\\n.bi-flag::before {\\n    content: \\"\\\\f3cc\\"\\n}\\n\\n.bi-flower1::before {\\n    content: \\"\\\\f3cd\\"\\n}\\n\\n.bi-flower2::before {\\n    content: \\"\\\\f3ce\\"\\n}\\n\\n.bi-flower3::before {\\n    content: \\"\\\\f3cf\\"\\n}\\n\\n.bi-folder-check::before {\\n    content: \\"\\\\f3d0\\"\\n}\\n\\n.bi-folder-fill::before {\\n    content: \\"\\\\f3d1\\"\\n}\\n\\n.bi-folder-minus::before {\\n    content: \\"\\\\f3d2\\"\\n}\\n\\n.bi-folder-plus::before {\\n    content: \\"\\\\f3d3\\"\\n}\\n\\n.bi-folder-symlink-fill::before {\\n    content: \\"\\\\f3d4\\"\\n}\\n\\n.bi-folder-symlink::before {\\n    content: \\"\\\\f3d5\\"\\n}\\n\\n.bi-folder-x::before {\\n    content: \\"\\\\f3d6\\"\\n}\\n\\n.bi-folder::before {\\n    content: \\"\\\\f3d7\\"\\n}\\n\\n.bi-folder2-open::before {\\n    content: \\"\\\\f3d8\\"\\n}\\n\\n.bi-folder2::before {\\n    content: \\"\\\\f3d9\\"\\n}\\n\\n.bi-fonts::before {\\n    content: \\"\\\\f3da\\"\\n}\\n\\n.bi-forward-fill::before {\\n    content: \\"\\\\f3db\\"\\n}\\n\\n.bi-forward::before {\\n    content: \\"\\\\f3dc\\"\\n}\\n\\n.bi-front::before {\\n    content: \\"\\\\f3dd\\"\\n}\\n\\n.bi-fullscreen-exit::before {\\n    content: \\"\\\\f3de\\"\\n}\\n\\n.bi-fullscreen::before {\\n    content: \\"\\\\f3df\\"\\n}\\n\\n.bi-funnel-fill::before {\\n    content: \\"\\\\f3e0\\"\\n}\\n\\n.bi-funnel::before {\\n    content: \\"\\\\f3e1\\"\\n}\\n\\n.bi-gear-fill::before {\\n    content: \\"\\\\f3e2\\"\\n}\\n\\n.bi-gear-wide-connected::before {\\n    content: \\"\\\\f3e3\\"\\n}\\n\\n.bi-gear-wide::before {\\n    content: \\"\\\\f3e4\\"\\n}\\n\\n.bi-gear::before {\\n    content: \\"\\\\f3e5\\"\\n}\\n\\n.bi-gem::before {\\n    content: \\"\\\\f3e6\\"\\n}\\n\\n.bi-geo-alt-fill::before {\\n    content: \\"\\\\f3e7\\"\\n}\\n\\n.bi-geo-alt::before {\\n    content: \\"\\\\f3e8\\"\\n}\\n\\n.bi-geo-fill::before {\\n    content: \\"\\\\f3e9\\"\\n}\\n\\n.bi-geo::before {\\n    content: \\"\\\\f3ea\\"\\n}\\n\\n.bi-gift-fill::before {\\n    content: \\"\\\\f3eb\\"\\n}\\n\\n.bi-gift::before {\\n    content: \\"\\\\f3ec\\"\\n}\\n\\n.bi-github::before {\\n    content: \\"\\\\f3ed\\"\\n}\\n\\n.bi-globe::before {\\n    content: \\"\\\\f3ee\\"\\n}\\n\\n.bi-globe2::before {\\n    content: \\"\\\\f3ef\\"\\n}\\n\\n.bi-google::before {\\n    content: \\"\\\\f3f0\\"\\n}\\n\\n.bi-graph-down::before {\\n    content: \\"\\\\f3f1\\"\\n}\\n\\n.bi-graph-up::before {\\n    content: \\"\\\\f3f2\\"\\n}\\n\\n.bi-grid-1x2-fill::before {\\n    content: \\"\\\\f3f3\\"\\n}\\n\\n.bi-grid-1x2::before {\\n    content: \\"\\\\f3f4\\"\\n}\\n\\n.bi-grid-3x2-gap-fill::before {\\n    content: \\"\\\\f3f5\\"\\n}\\n\\n.bi-grid-3x2-gap::before {\\n    content: \\"\\\\f3f6\\"\\n}\\n\\n.bi-grid-3x2::before {\\n    content: \\"\\\\f3f7\\"\\n}\\n\\n.bi-grid-3x3-gap-fill::before {\\n    content: \\"\\\\f3f8\\"\\n}\\n\\n.bi-grid-3x3-gap::before {\\n    content: \\"\\\\f3f9\\"\\n}\\n\\n.bi-grid-3x3::before {\\n    content: \\"\\\\f3fa\\"\\n}\\n\\n.bi-grid-fill::before {\\n    content: \\"\\\\f3fb\\"\\n}\\n\\n.bi-grid::before {\\n    content: \\"\\\\f3fc\\"\\n}\\n\\n.bi-grip-horizontal::before {\\n    content: \\"\\\\f3fd\\"\\n}\\n\\n.bi-grip-vertical::before {\\n    content: \\"\\\\f3fe\\"\\n}\\n\\n.bi-hammer::before {\\n    content: \\"\\\\f3ff\\"\\n}\\n\\n.bi-hand-index-fill::before {\\n    content: \\"\\\\f400\\"\\n}\\n\\n.bi-hand-index-thumb-fill::before {\\n    content: \\"\\\\f401\\"\\n}\\n\\n.bi-hand-index-thumb::before {\\n    content: \\"\\\\f402\\"\\n}\\n\\n.bi-hand-index::before {\\n    content: \\"\\\\f403\\"\\n}\\n\\n.bi-hand-thumbs-down-fill::before {\\n    content: \\"\\\\f404\\"\\n}\\n\\n.bi-hand-thumbs-down::before {\\n    content: \\"\\\\f405\\"\\n}\\n\\n.bi-hand-thumbs-up-fill::before {\\n    content: \\"\\\\f406\\"\\n}\\n\\n.bi-hand-thumbs-up::before {\\n    content: \\"\\\\f407\\"\\n}\\n\\n.bi-handbag-fill::before {\\n    content: \\"\\\\f408\\"\\n}\\n\\n.bi-handbag::before {\\n    content: \\"\\\\f409\\"\\n}\\n\\n.bi-hash::before {\\n    content: \\"\\\\f40a\\"\\n}\\n\\n.bi-hdd-fill::before {\\n    content: \\"\\\\f40b\\"\\n}\\n\\n.bi-hdd-network-fill::before {\\n    content: \\"\\\\f40c\\"\\n}\\n\\n.bi-hdd-network::before {\\n    content: \\"\\\\f40d\\"\\n}\\n\\n.bi-hdd-rack-fill::before {\\n    content: \\"\\\\f40e\\"\\n}\\n\\n.bi-hdd-rack::before {\\n    content: \\"\\\\f40f\\"\\n}\\n\\n.bi-hdd-stack-fill::before {\\n    content: \\"\\\\f410\\"\\n}\\n\\n.bi-hdd-stack::before {\\n    content: \\"\\\\f411\\"\\n}\\n\\n.bi-hdd::before {\\n    content: \\"\\\\f412\\"\\n}\\n\\n.bi-headphones::before {\\n    content: \\"\\\\f413\\"\\n}\\n\\n.bi-headset::before {\\n    content: \\"\\\\f414\\"\\n}\\n\\n.bi-heart-fill::before {\\n    content: \\"\\\\f415\\"\\n}\\n\\n.bi-heart-half::before {\\n    content: \\"\\\\f416\\"\\n}\\n\\n.bi-heart::before {\\n    content: \\"\\\\f417\\"\\n}\\n\\n.bi-heptagon-fill::before {\\n    content: \\"\\\\f418\\"\\n}\\n\\n.bi-heptagon-half::before {\\n    content: \\"\\\\f419\\"\\n}\\n\\n.bi-heptagon::before {\\n    content: \\"\\\\f41a\\"\\n}\\n\\n.bi-hexagon-fill::before {\\n    content: \\"\\\\f41b\\"\\n}\\n\\n.bi-hexagon-half::before {\\n    content: \\"\\\\f41c\\"\\n}\\n\\n.bi-hexagon::before {\\n    content: \\"\\\\f41d\\"\\n}\\n\\n.bi-hourglass-bottom::before {\\n    content: \\"\\\\f41e\\"\\n}\\n\\n.bi-hourglass-split::before {\\n    content: \\"\\\\f41f\\"\\n}\\n\\n.bi-hourglass-top::before {\\n    content: \\"\\\\f420\\"\\n}\\n\\n.bi-hourglass::before {\\n    content: \\"\\\\f421\\"\\n}\\n\\n.bi-house-door-fill::before {\\n    content: \\"\\\\f422\\"\\n}\\n\\n.bi-house-door::before {\\n    content: \\"\\\\f423\\"\\n}\\n\\n.bi-house-fill::before {\\n    content: \\"\\\\f424\\"\\n}\\n\\n.bi-house::before {\\n    content: \\"\\\\f425\\"\\n}\\n\\n.bi-hr::before {\\n    content: \\"\\\\f426\\"\\n}\\n\\n.bi-hurricane::before {\\n    content: \\"\\\\f427\\"\\n}\\n\\n.bi-image-alt::before {\\n    content: \\"\\\\f428\\"\\n}\\n\\n.bi-image-fill::before {\\n    content: \\"\\\\f429\\"\\n}\\n\\n.bi-image::before {\\n    content: \\"\\\\f42a\\"\\n}\\n\\n.bi-images::before {\\n    content: \\"\\\\f42b\\"\\n}\\n\\n.bi-inbox-fill::before {\\n    content: \\"\\\\f42c\\"\\n}\\n\\n.bi-inbox::before {\\n    content: \\"\\\\f42d\\"\\n}\\n\\n.bi-inboxes-fill::before {\\n    content: \\"\\\\f42e\\"\\n}\\n\\n.bi-inboxes::before {\\n    content: \\"\\\\f42f\\"\\n}\\n\\n.bi-info-circle-fill::before {\\n    content: \\"\\\\f430\\"\\n}\\n\\n.bi-info-circle::before {\\n    content: \\"\\\\f431\\"\\n}\\n\\n.bi-info-square-fill::before {\\n    content: \\"\\\\f432\\"\\n}\\n\\n.bi-info-square::before {\\n    content: \\"\\\\f433\\"\\n}\\n\\n.bi-info::before {\\n    content: \\"\\\\f434\\"\\n}\\n\\n.bi-input-cursor-text::before {\\n    content: \\"\\\\f435\\"\\n}\\n\\n.bi-input-cursor::before {\\n    content: \\"\\\\f436\\"\\n}\\n\\n.bi-instagram::before {\\n    content: \\"\\\\f437\\"\\n}\\n\\n.bi-intersect::before {\\n    content: \\"\\\\f438\\"\\n}\\n\\n.bi-journal-album::before {\\n    content: \\"\\\\f439\\"\\n}\\n\\n.bi-journal-arrow-down::before {\\n    content: \\"\\\\f43a\\"\\n}\\n\\n.bi-journal-arrow-up::before {\\n    content: \\"\\\\f43b\\"\\n}\\n\\n.bi-journal-bookmark-fill::before {\\n    content: \\"\\\\f43c\\"\\n}\\n\\n.bi-journal-bookmark::before {\\n    content: \\"\\\\f43d\\"\\n}\\n\\n.bi-journal-check::before {\\n    content: \\"\\\\f43e\\"\\n}\\n\\n.bi-journal-code::before {\\n    content: \\"\\\\f43f\\"\\n}\\n\\n.bi-journal-medical::before {\\n    content: \\"\\\\f440\\"\\n}\\n\\n.bi-journal-minus::before {\\n    content: \\"\\\\f441\\"\\n}\\n\\n.bi-journal-plus::before {\\n    content: \\"\\\\f442\\"\\n}\\n\\n.bi-journal-richtext::before {\\n    content: \\"\\\\f443\\"\\n}\\n\\n.bi-journal-text::before {\\n    content: \\"\\\\f444\\"\\n}\\n\\n.bi-journal-x::before {\\n    content: \\"\\\\f445\\"\\n}\\n\\n.bi-journal::before {\\n    content: \\"\\\\f446\\"\\n}\\n\\n.bi-journals::before {\\n    content: \\"\\\\f447\\"\\n}\\n\\n.bi-joystick::before {\\n    content: \\"\\\\f448\\"\\n}\\n\\n.bi-justify-left::before {\\n    content: \\"\\\\f449\\"\\n}\\n\\n.bi-justify-right::before {\\n    content: \\"\\\\f44a\\"\\n}\\n\\n.bi-justify::before {\\n    content: \\"\\\\f44b\\"\\n}\\n\\n.bi-kanban-fill::before {\\n    content: \\"\\\\f44c\\"\\n}\\n\\n.bi-kanban::before {\\n    content: \\"\\\\f44d\\"\\n}\\n\\n.bi-key-fill::before {\\n    content: \\"\\\\f44e\\"\\n}\\n\\n.bi-key::before {\\n    content: \\"\\\\f44f\\"\\n}\\n\\n.bi-keyboard-fill::before {\\n    content: \\"\\\\f450\\"\\n}\\n\\n.bi-keyboard::before {\\n    content: \\"\\\\f451\\"\\n}\\n\\n.bi-ladder::before {\\n    content: \\"\\\\f452\\"\\n}\\n\\n.bi-lamp-fill::before {\\n    content: \\"\\\\f453\\"\\n}\\n\\n.bi-lamp::before {\\n    content: \\"\\\\f454\\"\\n}\\n\\n.bi-laptop-fill::before {\\n    content: \\"\\\\f455\\"\\n}\\n\\n.bi-laptop::before {\\n    content: \\"\\\\f456\\"\\n}\\n\\n.bi-layer-backward::before {\\n    content: \\"\\\\f457\\"\\n}\\n\\n.bi-layer-forward::before {\\n    content: \\"\\\\f458\\"\\n}\\n\\n.bi-layers-fill::before {\\n    content: \\"\\\\f459\\"\\n}\\n\\n.bi-layers-half::before {\\n    content: \\"\\\\f45a\\"\\n}\\n\\n.bi-layers::before {\\n    content: \\"\\\\f45b\\"\\n}\\n\\n.bi-layout-sidebar-inset-reverse::before {\\n    content: \\"\\\\f45c\\"\\n}\\n\\n.bi-layout-sidebar-inset::before {\\n    content: \\"\\\\f45d\\"\\n}\\n\\n.bi-layout-sidebar-reverse::before {\\n    content: \\"\\\\f45e\\"\\n}\\n\\n.bi-layout-sidebar::before {\\n    content: \\"\\\\f45f\\"\\n}\\n\\n.bi-layout-split::before {\\n    content: \\"\\\\f460\\"\\n}\\n\\n.bi-layout-text-sidebar-reverse::before {\\n    content: \\"\\\\f461\\"\\n}\\n\\n.bi-layout-text-sidebar::before {\\n    content: \\"\\\\f462\\"\\n}\\n\\n.bi-layout-text-window-reverse::before {\\n    content: \\"\\\\f463\\"\\n}\\n\\n.bi-layout-text-window::before {\\n    content: \\"\\\\f464\\"\\n}\\n\\n.bi-layout-three-columns::before {\\n    content: \\"\\\\f465\\"\\n}\\n\\n.bi-layout-wtf::before {\\n    content: \\"\\\\f466\\"\\n}\\n\\n.bi-life-preserver::before {\\n    content: \\"\\\\f467\\"\\n}\\n\\n.bi-lightbulb-fill::before {\\n    content: \\"\\\\f468\\"\\n}\\n\\n.bi-lightbulb-off-fill::before {\\n    content: \\"\\\\f469\\"\\n}\\n\\n.bi-lightbulb-off::before {\\n    content: \\"\\\\f46a\\"\\n}\\n\\n.bi-lightbulb::before {\\n    content: \\"\\\\f46b\\"\\n}\\n\\n.bi-lightning-charge-fill::before {\\n    content: \\"\\\\f46c\\"\\n}\\n\\n.bi-lightning-charge::before {\\n    content: \\"\\\\f46d\\"\\n}\\n\\n.bi-lightning-fill::before {\\n    content: \\"\\\\f46e\\"\\n}\\n\\n.bi-lightning::before {\\n    content: \\"\\\\f46f\\"\\n}\\n\\n.bi-link-45deg::before {\\n    content: \\"\\\\f470\\"\\n}\\n\\n.bi-link::before {\\n    content: \\"\\\\f471\\"\\n}\\n\\n.bi-linkedin::before {\\n    content: \\"\\\\f472\\"\\n}\\n\\n.bi-list-check::before {\\n    content: \\"\\\\f473\\"\\n}\\n\\n.bi-list-nested::before {\\n    content: \\"\\\\f474\\"\\n}\\n\\n.bi-list-ol::before {\\n    content: \\"\\\\f475\\"\\n}\\n\\n.bi-list-stars::before {\\n    content: \\"\\\\f476\\"\\n}\\n\\n.bi-list-task::before {\\n    content: \\"\\\\f477\\"\\n}\\n\\n.bi-list-ul::before {\\n    content: \\"\\\\f478\\"\\n}\\n\\n.bi-list::before {\\n    content: \\"\\\\f479\\"\\n}\\n\\n.bi-lock-fill::before {\\n    content: \\"\\\\f47a\\"\\n}\\n\\n.bi-lock::before {\\n    content: \\"\\\\f47b\\"\\n}\\n\\n.bi-mailbox::before {\\n    content: \\"\\\\f47c\\"\\n}\\n\\n.bi-mailbox2::before {\\n    content: \\"\\\\f47d\\"\\n}\\n\\n.bi-map-fill::before {\\n    content: \\"\\\\f47e\\"\\n}\\n\\n.bi-map::before {\\n    content: \\"\\\\f47f\\"\\n}\\n\\n.bi-markdown-fill::before {\\n    content: \\"\\\\f480\\"\\n}\\n\\n.bi-markdown::before {\\n    content: \\"\\\\f481\\"\\n}\\n\\n.bi-mask::before {\\n    content: \\"\\\\f482\\"\\n}\\n\\n.bi-megaphone-fill::before {\\n    content: \\"\\\\f483\\"\\n}\\n\\n.bi-megaphone::before {\\n    content: \\"\\\\f484\\"\\n}\\n\\n.bi-menu-app-fill::before {\\n    content: \\"\\\\f485\\"\\n}\\n\\n.bi-menu-app::before {\\n    content: \\"\\\\f486\\"\\n}\\n\\n.bi-menu-button-fill::before {\\n    content: \\"\\\\f487\\"\\n}\\n\\n.bi-menu-button-wide-fill::before {\\n    content: \\"\\\\f488\\"\\n}\\n\\n.bi-menu-button-wide::before {\\n    content: \\"\\\\f489\\"\\n}\\n\\n.bi-menu-button::before {\\n    content: \\"\\\\f48a\\"\\n}\\n\\n.bi-menu-down::before {\\n    content: \\"\\\\f48b\\"\\n}\\n\\n.bi-menu-up::before {\\n    content: \\"\\\\f48c\\"\\n}\\n\\n.bi-mic-fill::before {\\n    content: \\"\\\\f48d\\"\\n}\\n\\n.bi-mic-mute-fill::before {\\n    content: \\"\\\\f48e\\"\\n}\\n\\n.bi-mic-mute::before {\\n    content: \\"\\\\f48f\\"\\n}\\n\\n.bi-mic::before {\\n    content: \\"\\\\f490\\"\\n}\\n\\n.bi-minecart-loaded::before {\\n    content: \\"\\\\f491\\"\\n}\\n\\n.bi-minecart::before {\\n    content: \\"\\\\f492\\"\\n}\\n\\n.bi-moisture::before {\\n    content: \\"\\\\f493\\"\\n}\\n\\n.bi-moon-fill::before {\\n    content: \\"\\\\f494\\"\\n}\\n\\n.bi-moon-stars-fill::before {\\n    content: \\"\\\\f495\\"\\n}\\n\\n.bi-moon-stars::before {\\n    content: \\"\\\\f496\\"\\n}\\n\\n.bi-moon::before {\\n    content: \\"\\\\f497\\"\\n}\\n\\n.bi-mouse-fill::before {\\n    content: \\"\\\\f498\\"\\n}\\n\\n.bi-mouse::before {\\n    content: \\"\\\\f499\\"\\n}\\n\\n.bi-mouse2-fill::before {\\n    content: \\"\\\\f49a\\"\\n}\\n\\n.bi-mouse2::before {\\n    content: \\"\\\\f49b\\"\\n}\\n\\n.bi-mouse3-fill::before {\\n    content: \\"\\\\f49c\\"\\n}\\n\\n.bi-mouse3::before {\\n    content: \\"\\\\f49d\\"\\n}\\n\\n.bi-music-note-beamed::before {\\n    content: \\"\\\\f49e\\"\\n}\\n\\n.bi-music-note-list::before {\\n    content: \\"\\\\f49f\\"\\n}\\n\\n.bi-music-note::before {\\n    content: \\"\\\\f4a0\\"\\n}\\n\\n.bi-music-player-fill::before {\\n    content: \\"\\\\f4a1\\"\\n}\\n\\n.bi-music-player::before {\\n    content: \\"\\\\f4a2\\"\\n}\\n\\n.bi-newspaper::before {\\n    content: \\"\\\\f4a3\\"\\n}\\n\\n.bi-node-minus-fill::before {\\n    content: \\"\\\\f4a4\\"\\n}\\n\\n.bi-node-minus::before {\\n    content: \\"\\\\f4a5\\"\\n}\\n\\n.bi-node-plus-fill::before {\\n    content: \\"\\\\f4a6\\"\\n}\\n\\n.bi-node-plus::before {\\n    content: \\"\\\\f4a7\\"\\n}\\n\\n.bi-nut-fill::before {\\n    content: \\"\\\\f4a8\\"\\n}\\n\\n.bi-nut::before {\\n    content: \\"\\\\f4a9\\"\\n}\\n\\n.bi-octagon-fill::before {\\n    content: \\"\\\\f4aa\\"\\n}\\n\\n.bi-octagon-half::before {\\n    content: \\"\\\\f4ab\\"\\n}\\n\\n.bi-octagon::before {\\n    content: \\"\\\\f4ac\\"\\n}\\n\\n.bi-option::before {\\n    content: \\"\\\\f4ad\\"\\n}\\n\\n.bi-outlet::before {\\n    content: \\"\\\\f4ae\\"\\n}\\n\\n.bi-paint-bucket::before {\\n    content: \\"\\\\f4af\\"\\n}\\n\\n.bi-palette-fill::before {\\n    content: \\"\\\\f4b0\\"\\n}\\n\\n.bi-palette::before {\\n    content: \\"\\\\f4b1\\"\\n}\\n\\n.bi-palette2::before {\\n    content: \\"\\\\f4b2\\"\\n}\\n\\n.bi-paperclip::before {\\n    content: \\"\\\\f4b3\\"\\n}\\n\\n.bi-paragraph::before {\\n    content: \\"\\\\f4b4\\"\\n}\\n\\n.bi-patch-check-fill::before {\\n    content: \\"\\\\f4b5\\"\\n}\\n\\n.bi-patch-check::before {\\n    content: \\"\\\\f4b6\\"\\n}\\n\\n.bi-patch-exclamation-fill::before {\\n    content: \\"\\\\f4b7\\"\\n}\\n\\n.bi-patch-exclamation::before {\\n    content: \\"\\\\f4b8\\"\\n}\\n\\n.bi-patch-minus-fill::before {\\n    content: \\"\\\\f4b9\\"\\n}\\n\\n.bi-patch-minus::before {\\n    content: \\"\\\\f4ba\\"\\n}\\n\\n.bi-patch-plus-fill::before {\\n    content: \\"\\\\f4bb\\"\\n}\\n\\n.bi-patch-plus::before {\\n    content: \\"\\\\f4bc\\"\\n}\\n\\n.bi-patch-question-fill::before {\\n    content: \\"\\\\f4bd\\"\\n}\\n\\n.bi-patch-question::before {\\n    content: \\"\\\\f4be\\"\\n}\\n\\n.bi-pause-btn-fill::before {\\n    content: \\"\\\\f4bf\\"\\n}\\n\\n.bi-pause-btn::before {\\n    content: \\"\\\\f4c0\\"\\n}\\n\\n.bi-pause-circle-fill::before {\\n    content: \\"\\\\f4c1\\"\\n}\\n\\n.bi-pause-circle::before {\\n    content: \\"\\\\f4c2\\"\\n}\\n\\n.bi-pause-fill::before {\\n    content: \\"\\\\f4c3\\"\\n}\\n\\n.bi-pause::before {\\n    content: \\"\\\\f4c4\\"\\n}\\n\\n.bi-peace-fill::before {\\n    content: \\"\\\\f4c5\\"\\n}\\n\\n.bi-peace::before {\\n    content: \\"\\\\f4c6\\"\\n}\\n\\n.bi-pen-fill::before {\\n    content: \\"\\\\f4c7\\"\\n}\\n\\n.bi-pen::before {\\n    content: \\"\\\\f4c8\\"\\n}\\n\\n.bi-pencil-fill::before {\\n    content: \\"\\\\f4c9\\"\\n}\\n\\n.bi-pencil-square::before {\\n    content: \\"\\\\f4ca\\"\\n}\\n\\n.bi-pencil::before {\\n    content: \\"\\\\f4cb\\"\\n}\\n\\n.bi-pentagon-fill::before {\\n    content: \\"\\\\f4cc\\"\\n}\\n\\n.bi-pentagon-half::before {\\n    content: \\"\\\\f4cd\\"\\n}\\n\\n.bi-pentagon::before {\\n    content: \\"\\\\f4ce\\"\\n}\\n\\n.bi-people-fill::before {\\n    content: \\"\\\\f4cf\\"\\n}\\n\\n.bi-people::before {\\n    content: \\"\\\\f4d0\\"\\n}\\n\\n.bi-percent::before {\\n    content: \\"\\\\f4d1\\"\\n}\\n\\n.bi-person-badge-fill::before {\\n    content: \\"\\\\f4d2\\"\\n}\\n\\n.bi-person-badge::before {\\n    content: \\"\\\\f4d3\\"\\n}\\n\\n.bi-person-bounding-box::before {\\n    content: \\"\\\\f4d4\\"\\n}\\n\\n.bi-person-check-fill::before {\\n    content: \\"\\\\f4d5\\"\\n}\\n\\n.bi-person-check::before {\\n    content: \\"\\\\f4d6\\"\\n}\\n\\n.bi-person-circle::before {\\n    content: \\"\\\\f4d7\\"\\n}\\n\\n.bi-person-dash-fill::before {\\n    content: \\"\\\\f4d8\\"\\n}\\n\\n.bi-person-dash::before {\\n    content: \\"\\\\f4d9\\"\\n}\\n\\n.bi-person-fill::before {\\n    content: \\"\\\\f4da\\"\\n}\\n\\n.bi-person-lines-fill::before {\\n    content: \\"\\\\f4db\\"\\n}\\n\\n.bi-person-plus-fill::before {\\n    content: \\"\\\\f4dc\\"\\n}\\n\\n.bi-person-plus::before {\\n    content: \\"\\\\f4dd\\"\\n}\\n\\n.bi-person-square::before {\\n    content: \\"\\\\f4de\\"\\n}\\n\\n.bi-person-x-fill::before {\\n    content: \\"\\\\f4df\\"\\n}\\n\\n.bi-person-x::before {\\n    content: \\"\\\\f4e0\\"\\n}\\n\\n.bi-person::before {\\n    content: \\"\\\\f4e1\\"\\n}\\n\\n.bi-phone-fill::before {\\n    content: \\"\\\\f4e2\\"\\n}\\n\\n.bi-phone-landscape-fill::before {\\n    content: \\"\\\\f4e3\\"\\n}\\n\\n.bi-phone-landscape::before {\\n    content: \\"\\\\f4e4\\"\\n}\\n\\n.bi-phone-vibrate-fill::before {\\n    content: \\"\\\\f4e5\\"\\n}\\n\\n.bi-phone-vibrate::before {\\n    content: \\"\\\\f4e6\\"\\n}\\n\\n.bi-phone::before {\\n    content: \\"\\\\f4e7\\"\\n}\\n\\n.bi-pie-chart-fill::before {\\n    content: \\"\\\\f4e8\\"\\n}\\n\\n.bi-pie-chart::before {\\n    content: \\"\\\\f4e9\\"\\n}\\n\\n.bi-pin-angle-fill::before {\\n    content: \\"\\\\f4ea\\"\\n}\\n\\n.bi-pin-angle::before {\\n    content: \\"\\\\f4eb\\"\\n}\\n\\n.bi-pin-fill::before {\\n    content: \\"\\\\f4ec\\"\\n}\\n\\n.bi-pin::before {\\n    content: \\"\\\\f4ed\\"\\n}\\n\\n.bi-pip-fill::before {\\n    content: \\"\\\\f4ee\\"\\n}\\n\\n.bi-pip::before {\\n    content: \\"\\\\f4ef\\"\\n}\\n\\n.bi-play-btn-fill::before {\\n    content: \\"\\\\f4f0\\"\\n}\\n\\n.bi-play-btn::before {\\n    content: \\"\\\\f4f1\\"\\n}\\n\\n.bi-play-circle-fill::before {\\n    content: \\"\\\\f4f2\\"\\n}\\n\\n.bi-play-circle::before {\\n    content: \\"\\\\f4f3\\"\\n}\\n\\n.bi-play-fill::before {\\n    content: \\"\\\\f4f4\\"\\n}\\n\\n.bi-play::before {\\n    content: \\"\\\\f4f5\\"\\n}\\n\\n.bi-plug-fill::before {\\n    content: \\"\\\\f4f6\\"\\n}\\n\\n.bi-plug::before {\\n    content: \\"\\\\f4f7\\"\\n}\\n\\n.bi-plus-circle-dotted::before {\\n    content: \\"\\\\f4f8\\"\\n}\\n\\n.bi-plus-circle-fill::before {\\n    content: \\"\\\\f4f9\\"\\n}\\n\\n.bi-plus-circle::before {\\n    content: \\"\\\\f4fa\\"\\n}\\n\\n.bi-plus-square-dotted::before {\\n    content: \\"\\\\f4fb\\"\\n}\\n\\n.bi-plus-square-fill::before {\\n    content: \\"\\\\f4fc\\"\\n}\\n\\n.bi-plus-square::before {\\n    content: \\"\\\\f4fd\\"\\n}\\n\\n.bi-plus::before {\\n    content: \\"\\\\f4fe\\"\\n}\\n\\n.bi-power::before {\\n    content: \\"\\\\f4ff\\"\\n}\\n\\n.bi-printer-fill::before {\\n    content: \\"\\\\f500\\"\\n}\\n\\n.bi-printer::before {\\n    content: \\"\\\\f501\\"\\n}\\n\\n.bi-puzzle-fill::before {\\n    content: \\"\\\\f502\\"\\n}\\n\\n.bi-puzzle::before {\\n    content: \\"\\\\f503\\"\\n}\\n\\n.bi-question-circle-fill::before {\\n    content: \\"\\\\f504\\"\\n}\\n\\n.bi-question-circle::before {\\n    content: \\"\\\\f505\\"\\n}\\n\\n.bi-question-diamond-fill::before {\\n    content: \\"\\\\f506\\"\\n}\\n\\n.bi-question-diamond::before {\\n    content: \\"\\\\f507\\"\\n}\\n\\n.bi-question-octagon-fill::before {\\n    content: \\"\\\\f508\\"\\n}\\n\\n.bi-question-octagon::before {\\n    content: \\"\\\\f509\\"\\n}\\n\\n.bi-question-square-fill::before {\\n    content: \\"\\\\f50a\\"\\n}\\n\\n.bi-question-square::before {\\n    content: \\"\\\\f50b\\"\\n}\\n\\n.bi-question::before {\\n    content: \\"\\\\f50c\\"\\n}\\n\\n.bi-rainbow::before {\\n    content: \\"\\\\f50d\\"\\n}\\n\\n.bi-receipt-cutoff::before {\\n    content: \\"\\\\f50e\\"\\n}\\n\\n.bi-receipt::before {\\n    content: \\"\\\\f50f\\"\\n}\\n\\n.bi-reception-0::before {\\n    content: \\"\\\\f510\\"\\n}\\n\\n.bi-reception-1::before {\\n    content: \\"\\\\f511\\"\\n}\\n\\n.bi-reception-2::before {\\n    content: \\"\\\\f512\\"\\n}\\n\\n.bi-reception-3::before {\\n    content: \\"\\\\f513\\"\\n}\\n\\n.bi-reception-4::before {\\n    content: \\"\\\\f514\\"\\n}\\n\\n.bi-record-btn-fill::before {\\n    content: \\"\\\\f515\\"\\n}\\n\\n.bi-record-btn::before {\\n    content: \\"\\\\f516\\"\\n}\\n\\n.bi-record-circle-fill::before {\\n    content: \\"\\\\f517\\"\\n}\\n\\n.bi-record-circle::before {\\n    content: \\"\\\\f518\\"\\n}\\n\\n.bi-record-fill::before {\\n    content: \\"\\\\f519\\"\\n}\\n\\n.bi-record::before {\\n    content: \\"\\\\f51a\\"\\n}\\n\\n.bi-record2-fill::before {\\n    content: \\"\\\\f51b\\"\\n}\\n\\n.bi-record2::before {\\n    content: \\"\\\\f51c\\"\\n}\\n\\n.bi-reply-all-fill::before {\\n    content: \\"\\\\f51d\\"\\n}\\n\\n.bi-reply-all::before {\\n    content: \\"\\\\f51e\\"\\n}\\n\\n.bi-reply-fill::before {\\n    content: \\"\\\\f51f\\"\\n}\\n\\n.bi-reply::before {\\n    content: \\"\\\\f520\\"\\n}\\n\\n.bi-rss-fill::before {\\n    content: \\"\\\\f521\\"\\n}\\n\\n.bi-rss::before {\\n    content: \\"\\\\f522\\"\\n}\\n\\n.bi-rulers::before {\\n    content: \\"\\\\f523\\"\\n}\\n\\n.bi-save-fill::before {\\n    content: \\"\\\\f524\\"\\n}\\n\\n.bi-save::before {\\n    content: \\"\\\\f525\\"\\n}\\n\\n.bi-save2-fill::before {\\n    content: \\"\\\\f526\\"\\n}\\n\\n.bi-save2::before {\\n    content: \\"\\\\f527\\"\\n}\\n\\n.bi-scissors::before {\\n    content: \\"\\\\f528\\"\\n}\\n\\n.bi-screwdriver::before {\\n    content: \\"\\\\f529\\"\\n}\\n\\n.bi-search::before {\\n    content: \\"\\\\f52a\\"\\n}\\n\\n.bi-segmented-nav::before {\\n    content: \\"\\\\f52b\\"\\n}\\n\\n.bi-server::before {\\n    content: \\"\\\\f52c\\"\\n}\\n\\n.bi-share-fill::before {\\n    content: \\"\\\\f52d\\"\\n}\\n\\n.bi-share::before {\\n    content: \\"\\\\f52e\\"\\n}\\n\\n.bi-shield-check::before {\\n    content: \\"\\\\f52f\\"\\n}\\n\\n.bi-shield-exclamation::before {\\n    content: \\"\\\\f530\\"\\n}\\n\\n.bi-shield-fill-check::before {\\n    content: \\"\\\\f531\\"\\n}\\n\\n.bi-shield-fill-exclamation::before {\\n    content: \\"\\\\f532\\"\\n}\\n\\n.bi-shield-fill-minus::before {\\n    content: \\"\\\\f533\\"\\n}\\n\\n.bi-shield-fill-plus::before {\\n    content: \\"\\\\f534\\"\\n}\\n\\n.bi-shield-fill-x::before {\\n    content: \\"\\\\f535\\"\\n}\\n\\n.bi-shield-fill::before {\\n    content: \\"\\\\f536\\"\\n}\\n\\n.bi-shield-lock-fill::before {\\n    content: \\"\\\\f537\\"\\n}\\n\\n.bi-shield-lock::before {\\n    content: \\"\\\\f538\\"\\n}\\n\\n.bi-shield-minus::before {\\n    content: \\"\\\\f539\\"\\n}\\n\\n.bi-shield-plus::before {\\n    content: \\"\\\\f53a\\"\\n}\\n\\n.bi-shield-shaded::before {\\n    content: \\"\\\\f53b\\"\\n}\\n\\n.bi-shield-slash-fill::before {\\n    content: \\"\\\\f53c\\"\\n}\\n\\n.bi-shield-slash::before {\\n    content: \\"\\\\f53d\\"\\n}\\n\\n.bi-shield-x::before {\\n    content: \\"\\\\f53e\\"\\n}\\n\\n.bi-shield::before {\\n    content: \\"\\\\f53f\\"\\n}\\n\\n.bi-shift-fill::before {\\n    content: \\"\\\\f540\\"\\n}\\n\\n.bi-shift::before {\\n    content: \\"\\\\f541\\"\\n}\\n\\n.bi-shop-window::before {\\n    content: \\"\\\\f542\\"\\n}\\n\\n.bi-shop::before {\\n    content: \\"\\\\f543\\"\\n}\\n\\n.bi-shuffle::before {\\n    content: \\"\\\\f544\\"\\n}\\n\\n.bi-signpost-2-fill::before {\\n    content: \\"\\\\f545\\"\\n}\\n\\n.bi-signpost-2::before {\\n    content: \\"\\\\f546\\"\\n}\\n\\n.bi-signpost-fill::before {\\n    content: \\"\\\\f547\\"\\n}\\n\\n.bi-signpost-split-fill::before {\\n    content: \\"\\\\f548\\"\\n}\\n\\n.bi-signpost-split::before {\\n    content: \\"\\\\f549\\"\\n}\\n\\n.bi-signpost::before {\\n    content: \\"\\\\f54a\\"\\n}\\n\\n.bi-sim-fill::before {\\n    content: \\"\\\\f54b\\"\\n}\\n\\n.bi-sim::before {\\n    content: \\"\\\\f54c\\"\\n}\\n\\n.bi-skip-backward-btn-fill::before {\\n    content: \\"\\\\f54d\\"\\n}\\n\\n.bi-skip-backward-btn::before {\\n    content: \\"\\\\f54e\\"\\n}\\n\\n.bi-skip-backward-circle-fill::before {\\n    content: \\"\\\\f54f\\"\\n}\\n\\n.bi-skip-backward-circle::before {\\n    content: \\"\\\\f550\\"\\n}\\n\\n.bi-skip-backward-fill::before {\\n    content: \\"\\\\f551\\"\\n}\\n\\n.bi-skip-backward::before {\\n    content: \\"\\\\f552\\"\\n}\\n\\n.bi-skip-end-btn-fill::before {\\n    content: \\"\\\\f553\\"\\n}\\n\\n.bi-skip-end-btn::before {\\n    content: \\"\\\\f554\\"\\n}\\n\\n.bi-skip-end-circle-fill::before {\\n    content: \\"\\\\f555\\"\\n}\\n\\n.bi-skip-end-circle::before {\\n    content: \\"\\\\f556\\"\\n}\\n\\n.bi-skip-end-fill::before {\\n    content: \\"\\\\f557\\"\\n}\\n\\n.bi-skip-end::before {\\n    content: \\"\\\\f558\\"\\n}\\n\\n.bi-skip-forward-btn-fill::before {\\n    content: \\"\\\\f559\\"\\n}\\n\\n.bi-skip-forward-btn::before {\\n    content: \\"\\\\f55a\\"\\n}\\n\\n.bi-skip-forward-circle-fill::before {\\n    content: \\"\\\\f55b\\"\\n}\\n\\n.bi-skip-forward-circle::before {\\n    content: \\"\\\\f55c\\"\\n}\\n\\n.bi-skip-forward-fill::before {\\n    content: \\"\\\\f55d\\"\\n}\\n\\n.bi-skip-forward::before {\\n    content: \\"\\\\f55e\\"\\n}\\n\\n.bi-skip-start-btn-fill::before {\\n    content: \\"\\\\f55f\\"\\n}\\n\\n.bi-skip-start-btn::before {\\n    content: \\"\\\\f560\\"\\n}\\n\\n.bi-skip-start-circle-fill::before {\\n    content: \\"\\\\f561\\"\\n}\\n\\n.bi-skip-start-circle::before {\\n    content: \\"\\\\f562\\"\\n}\\n\\n.bi-skip-start-fill::before {\\n    content: \\"\\\\f563\\"\\n}\\n\\n.bi-skip-start::before {\\n    content: \\"\\\\f564\\"\\n}\\n\\n.bi-slack::before {\\n    content: \\"\\\\f565\\"\\n}\\n\\n.bi-slash-circle-fill::before {\\n    content: \\"\\\\f566\\"\\n}\\n\\n.bi-slash-circle::before {\\n    content: \\"\\\\f567\\"\\n}\\n\\n.bi-slash-square-fill::before {\\n    content: \\"\\\\f568\\"\\n}\\n\\n.bi-slash-square::before {\\n    content: \\"\\\\f569\\"\\n}\\n\\n.bi-slash::before {\\n    content: \\"\\\\f56a\\"\\n}\\n\\n.bi-sliders::before {\\n    content: \\"\\\\f56b\\"\\n}\\n\\n.bi-smartwatch::before {\\n    content: \\"\\\\f56c\\"\\n}\\n\\n.bi-snow::before {\\n    content: \\"\\\\f56d\\"\\n}\\n\\n.bi-snow2::before {\\n    content: \\"\\\\f56e\\"\\n}\\n\\n.bi-snow3::before {\\n    content: \\"\\\\f56f\\"\\n}\\n\\n.bi-sort-alpha-down-alt::before {\\n    content: \\"\\\\f570\\"\\n}\\n\\n.bi-sort-alpha-down::before {\\n    content: \\"\\\\f571\\"\\n}\\n\\n.bi-sort-alpha-up-alt::before {\\n    content: \\"\\\\f572\\"\\n}\\n\\n.bi-sort-alpha-up::before {\\n    content: \\"\\\\f573\\"\\n}\\n\\n.bi-sort-down-alt::before {\\n    content: \\"\\\\f574\\"\\n}\\n\\n.bi-sort-down::before {\\n    content: \\"\\\\f575\\"\\n}\\n\\n.bi-sort-numeric-down-alt::before {\\n    content: \\"\\\\f576\\"\\n}\\n\\n.bi-sort-numeric-down::before {\\n    content: \\"\\\\f577\\"\\n}\\n\\n.bi-sort-numeric-up-alt::before {\\n    content: \\"\\\\f578\\"\\n}\\n\\n.bi-sort-numeric-up::before {\\n    content: \\"\\\\f579\\"\\n}\\n\\n.bi-sort-up-alt::before {\\n    content: \\"\\\\f57a\\"\\n}\\n\\n.bi-sort-up::before {\\n    content: \\"\\\\f57b\\"\\n}\\n\\n.bi-soundwave::before {\\n    content: \\"\\\\f57c\\"\\n}\\n\\n.bi-speaker-fill::before {\\n    content: \\"\\\\f57d\\"\\n}\\n\\n.bi-speaker::before {\\n    content: \\"\\\\f57e\\"\\n}\\n\\n.bi-speedometer::before {\\n    content: \\"\\\\f57f\\"\\n}\\n\\n.bi-speedometer2::before {\\n    content: \\"\\\\f580\\"\\n}\\n\\n.bi-spellcheck::before {\\n    content: \\"\\\\f581\\"\\n}\\n\\n.bi-square-fill::before {\\n    content: \\"\\\\f582\\"\\n}\\n\\n.bi-square-half::before {\\n    content: \\"\\\\f583\\"\\n}\\n\\n.bi-square::before {\\n    content: \\"\\\\f584\\"\\n}\\n\\n.bi-stack::before {\\n    content: \\"\\\\f585\\"\\n}\\n\\n.bi-star-fill::before {\\n    content: \\"\\\\f586\\"\\n}\\n\\n.bi-star-half::before {\\n    content: \\"\\\\f587\\"\\n}\\n\\n.bi-star::before {\\n    content: \\"\\\\f588\\"\\n}\\n\\n.bi-stars::before {\\n    content: \\"\\\\f589\\"\\n}\\n\\n.bi-stickies-fill::before {\\n    content: \\"\\\\f58a\\"\\n}\\n\\n.bi-stickies::before {\\n    content: \\"\\\\f58b\\"\\n}\\n\\n.bi-sticky-fill::before {\\n    content: \\"\\\\f58c\\"\\n}\\n\\n.bi-sticky::before {\\n    content: \\"\\\\f58d\\"\\n}\\n\\n.bi-stop-btn-fill::before {\\n    content: \\"\\\\f58e\\"\\n}\\n\\n.bi-stop-btn::before {\\n    content: \\"\\\\f58f\\"\\n}\\n\\n.bi-stop-circle-fill::before {\\n    content: \\"\\\\f590\\"\\n}\\n\\n.bi-stop-circle::before {\\n    content: \\"\\\\f591\\"\\n}\\n\\n.bi-stop-fill::before {\\n    content: \\"\\\\f592\\"\\n}\\n\\n.bi-stop::before {\\n    content: \\"\\\\f593\\"\\n}\\n\\n.bi-stoplights-fill::before {\\n    content: \\"\\\\f594\\"\\n}\\n\\n.bi-stoplights::before {\\n    content: \\"\\\\f595\\"\\n}\\n\\n.bi-stopwatch-fill::before {\\n    content: \\"\\\\f596\\"\\n}\\n\\n.bi-stopwatch::before {\\n    content: \\"\\\\f597\\"\\n}\\n\\n.bi-subtract::before {\\n    content: \\"\\\\f598\\"\\n}\\n\\n.bi-suit-club-fill::before {\\n    content: \\"\\\\f599\\"\\n}\\n\\n.bi-suit-club::before {\\n    content: \\"\\\\f59a\\"\\n}\\n\\n.bi-suit-diamond-fill::before {\\n    content: \\"\\\\f59b\\"\\n}\\n\\n.bi-suit-diamond::before {\\n    content: \\"\\\\f59c\\"\\n}\\n\\n.bi-suit-heart-fill::before {\\n    content: \\"\\\\f59d\\"\\n}\\n\\n.bi-suit-heart::before {\\n    content: \\"\\\\f59e\\"\\n}\\n\\n.bi-suit-spade-fill::before {\\n    content: \\"\\\\f59f\\"\\n}\\n\\n.bi-suit-spade::before {\\n    content: \\"\\\\f5a0\\"\\n}\\n\\n.bi-sun-fill::before {\\n    content: \\"\\\\f5a1\\"\\n}\\n\\n.bi-sun::before {\\n    content: \\"\\\\f5a2\\"\\n}\\n\\n.bi-sunglasses::before {\\n    content: \\"\\\\f5a3\\"\\n}\\n\\n.bi-sunrise-fill::before {\\n    content: \\"\\\\f5a4\\"\\n}\\n\\n.bi-sunrise::before {\\n    content: \\"\\\\f5a5\\"\\n}\\n\\n.bi-sunset-fill::before {\\n    content: \\"\\\\f5a6\\"\\n}\\n\\n.bi-sunset::before {\\n    content: \\"\\\\f5a7\\"\\n}\\n\\n.bi-symmetry-horizontal::before {\\n    content: \\"\\\\f5a8\\"\\n}\\n\\n.bi-symmetry-vertical::before {\\n    content: \\"\\\\f5a9\\"\\n}\\n\\n.bi-table::before {\\n    content: \\"\\\\f5aa\\"\\n}\\n\\n.bi-tablet-fill::before {\\n    content: \\"\\\\f5ab\\"\\n}\\n\\n.bi-tablet-landscape-fill::before {\\n    content: \\"\\\\f5ac\\"\\n}\\n\\n.bi-tablet-landscape::before {\\n    content: \\"\\\\f5ad\\"\\n}\\n\\n.bi-tablet::before {\\n    content: \\"\\\\f5ae\\"\\n}\\n\\n.bi-tag-fill::before {\\n    content: \\"\\\\f5af\\"\\n}\\n\\n.bi-tag::before {\\n    content: \\"\\\\f5b0\\"\\n}\\n\\n.bi-tags-fill::before {\\n    content: \\"\\\\f5b1\\"\\n}\\n\\n.bi-tags::before {\\n    content: \\"\\\\f5b2\\"\\n}\\n\\n.bi-telegram::before {\\n    content: \\"\\\\f5b3\\"\\n}\\n\\n.bi-telephone-fill::before {\\n    content: \\"\\\\f5b4\\"\\n}\\n\\n.bi-telephone-forward-fill::before {\\n    content: \\"\\\\f5b5\\"\\n}\\n\\n.bi-telephone-forward::before {\\n    content: \\"\\\\f5b6\\"\\n}\\n\\n.bi-telephone-inbound-fill::before {\\n    content: \\"\\\\f5b7\\"\\n}\\n\\n.bi-telephone-inbound::before {\\n    content: \\"\\\\f5b8\\"\\n}\\n\\n.bi-telephone-minus-fill::before {\\n    content: \\"\\\\f5b9\\"\\n}\\n\\n.bi-telephone-minus::before {\\n    content: \\"\\\\f5ba\\"\\n}\\n\\n.bi-telephone-outbound-fill::before {\\n    content: \\"\\\\f5bb\\"\\n}\\n\\n.bi-telephone-outbound::before {\\n    content: \\"\\\\f5bc\\"\\n}\\n\\n.bi-telephone-plus-fill::before {\\n    content: \\"\\\\f5bd\\"\\n}\\n\\n.bi-telephone-plus::before {\\n    content: \\"\\\\f5be\\"\\n}\\n\\n.bi-telephone-x-fill::before {\\n    content: \\"\\\\f5bf\\"\\n}\\n\\n.bi-telephone-x::before {\\n    content: \\"\\\\f5c0\\"\\n}\\n\\n.bi-telephone::before {\\n    content: \\"\\\\f5c1\\"\\n}\\n\\n.bi-terminal-fill::before {\\n    content: \\"\\\\f5c2\\"\\n}\\n\\n.bi-terminal::before {\\n    content: \\"\\\\f5c3\\"\\n}\\n\\n.bi-text-center::before {\\n    content: \\"\\\\f5c4\\"\\n}\\n\\n.bi-text-indent-left::before {\\n    content: \\"\\\\f5c5\\"\\n}\\n\\n.bi-text-indent-right::before {\\n    content: \\"\\\\f5c6\\"\\n}\\n\\n.bi-text-left::before {\\n    content: \\"\\\\f5c7\\"\\n}\\n\\n.bi-text-paragraph::before {\\n    content: \\"\\\\f5c8\\"\\n}\\n\\n.bi-text-right::before {\\n    content: \\"\\\\f5c9\\"\\n}\\n\\n.bi-textarea-resize::before {\\n    content: \\"\\\\f5ca\\"\\n}\\n\\n.bi-textarea-t::before {\\n    content: \\"\\\\f5cb\\"\\n}\\n\\n.bi-textarea::before {\\n    content: \\"\\\\f5cc\\"\\n}\\n\\n.bi-thermometer-half::before {\\n    content: \\"\\\\f5cd\\"\\n}\\n\\n.bi-thermometer-high::before {\\n    content: \\"\\\\f5ce\\"\\n}\\n\\n.bi-thermometer-low::before {\\n    content: \\"\\\\f5cf\\"\\n}\\n\\n.bi-thermometer-snow::before {\\n    content: \\"\\\\f5d0\\"\\n}\\n\\n.bi-thermometer-sun::before {\\n    content: \\"\\\\f5d1\\"\\n}\\n\\n.bi-thermometer::before {\\n    content: \\"\\\\f5d2\\"\\n}\\n\\n.bi-three-dots-vertical::before {\\n    content: \\"\\\\f5d3\\"\\n}\\n\\n.bi-three-dots::before {\\n    content: \\"\\\\f5d4\\"\\n}\\n\\n.bi-toggle-off::before {\\n    content: \\"\\\\f5d5\\"\\n}\\n\\n.bi-toggle-on::before {\\n    content: \\"\\\\f5d6\\"\\n}\\n\\n.bi-toggle2-off::before {\\n    content: \\"\\\\f5d7\\"\\n}\\n\\n.bi-toggle2-on::before {\\n    content: \\"\\\\f5d8\\"\\n}\\n\\n.bi-toggles::before {\\n    content: \\"\\\\f5d9\\"\\n}\\n\\n.bi-toggles2::before {\\n    content: \\"\\\\f5da\\"\\n}\\n\\n.bi-tools::before {\\n    content: \\"\\\\f5db\\"\\n}\\n\\n.bi-tornado::before {\\n    content: \\"\\\\f5dc\\"\\n}\\n\\n.bi-trash-fill::before {\\n    content: \\"\\\\f5dd\\"\\n}\\n\\n.bi-trash::before {\\n    content: \\"\\\\f5de\\"\\n}\\n\\n.bi-trash2-fill::before {\\n    content: \\"\\\\f5df\\"\\n}\\n\\n.bi-trash2::before {\\n    content: \\"\\\\f5e0\\"\\n}\\n\\n.bi-tree-fill::before {\\n    content: \\"\\\\f5e1\\"\\n}\\n\\n.bi-tree::before {\\n    content: \\"\\\\f5e2\\"\\n}\\n\\n.bi-triangle-fill::before {\\n    content: \\"\\\\f5e3\\"\\n}\\n\\n.bi-triangle-half::before {\\n    content: \\"\\\\f5e4\\"\\n}\\n\\n.bi-triangle::before {\\n    content: \\"\\\\f5e5\\"\\n}\\n\\n.bi-trophy-fill::before {\\n    content: \\"\\\\f5e6\\"\\n}\\n\\n.bi-trophy::before {\\n    content: \\"\\\\f5e7\\"\\n}\\n\\n.bi-tropical-storm::before {\\n    content: \\"\\\\f5e8\\"\\n}\\n\\n.bi-truck-flatbed::before {\\n    content: \\"\\\\f5e9\\"\\n}\\n\\n.bi-truck::before {\\n    content: \\"\\\\f5ea\\"\\n}\\n\\n.bi-tsunami::before {\\n    content: \\"\\\\f5eb\\"\\n}\\n\\n.bi-tv-fill::before {\\n    content: \\"\\\\f5ec\\"\\n}\\n\\n.bi-tv::before {\\n    content: \\"\\\\f5ed\\"\\n}\\n\\n.bi-twitch::before {\\n    content: \\"\\\\f5ee\\"\\n}\\n\\n.bi-twitter::before {\\n    content: \\"\\\\f5ef\\"\\n}\\n\\n.bi-type-bold::before {\\n    content: \\"\\\\f5f0\\"\\n}\\n\\n.bi-type-h1::before {\\n    content: \\"\\\\f5f1\\"\\n}\\n\\n.bi-type-h2::before {\\n    content: \\"\\\\f5f2\\"\\n}\\n\\n.bi-type-h3::before {\\n    content: \\"\\\\f5f3\\"\\n}\\n\\n.bi-type-italic::before {\\n    content: \\"\\\\f5f4\\"\\n}\\n\\n.bi-type-strikethrough::before {\\n    content: \\"\\\\f5f5\\"\\n}\\n\\n.bi-type-underline::before {\\n    content: \\"\\\\f5f6\\"\\n}\\n\\n.bi-type::before {\\n    content: \\"\\\\f5f7\\"\\n}\\n\\n.bi-ui-checks-grid::before {\\n    content: \\"\\\\f5f8\\"\\n}\\n\\n.bi-ui-checks::before {\\n    content: \\"\\\\f5f9\\"\\n}\\n\\n.bi-ui-radios-grid::before {\\n    content: \\"\\\\f5fa\\"\\n}\\n\\n.bi-ui-radios::before {\\n    content: \\"\\\\f5fb\\"\\n}\\n\\n.bi-umbrella-fill::before {\\n    content: \\"\\\\f5fc\\"\\n}\\n\\n.bi-umbrella::before {\\n    content: \\"\\\\f5fd\\"\\n}\\n\\n.bi-union::before {\\n    content: \\"\\\\f5fe\\"\\n}\\n\\n.bi-unlock-fill::before {\\n    content: \\"\\\\f5ff\\"\\n}\\n\\n.bi-unlock::before {\\n    content: \\"\\\\f600\\"\\n}\\n\\n.bi-upc-scan::before {\\n    content: \\"\\\\f601\\"\\n}\\n\\n.bi-upc::before {\\n    content: \\"\\\\f602\\"\\n}\\n\\n.bi-upload::before {\\n    content: \\"\\\\f603\\"\\n}\\n\\n.bi-vector-pen::before {\\n    content: \\"\\\\f604\\"\\n}\\n\\n.bi-view-list::before {\\n    content: \\"\\\\f605\\"\\n}\\n\\n.bi-view-stacked::before {\\n    content: \\"\\\\f606\\"\\n}\\n\\n.bi-vinyl-fill::before {\\n    content: \\"\\\\f607\\"\\n}\\n\\n.bi-vinyl::before {\\n    content: \\"\\\\f608\\"\\n}\\n\\n.bi-voicemail::before {\\n    content: \\"\\\\f609\\"\\n}\\n\\n.bi-volume-down-fill::before {\\n    content: \\"\\\\f60a\\"\\n}\\n\\n.bi-volume-down::before {\\n    content: \\"\\\\f60b\\"\\n}\\n\\n.bi-volume-mute-fill::before {\\n    content: \\"\\\\f60c\\"\\n}\\n\\n.bi-volume-mute::before {\\n    content: \\"\\\\f60d\\"\\n}\\n\\n.bi-volume-off-fill::before {\\n    content: \\"\\\\f60e\\"\\n}\\n\\n.bi-volume-off::before {\\n    content: \\"\\\\f60f\\"\\n}\\n\\n.bi-volume-up-fill::before {\\n    content: \\"\\\\f610\\"\\n}\\n\\n.bi-volume-up::before {\\n    content: \\"\\\\f611\\"\\n}\\n\\n.bi-vr::before {\\n    content: \\"\\\\f612\\"\\n}\\n\\n.bi-wallet-fill::before {\\n    content: \\"\\\\f613\\"\\n}\\n\\n.bi-wallet::before {\\n    content: \\"\\\\f614\\"\\n}\\n\\n.bi-wallet2::before {\\n    content: \\"\\\\f615\\"\\n}\\n\\n.bi-watch::before {\\n    content: \\"\\\\f616\\"\\n}\\n\\n.bi-water::before {\\n    content: \\"\\\\f617\\"\\n}\\n\\n.bi-whatsapp::before {\\n    content: \\"\\\\f618\\"\\n}\\n\\n.bi-wifi-1::before {\\n    content: \\"\\\\f619\\"\\n}\\n\\n.bi-wifi-2::before {\\n    content: \\"\\\\f61a\\"\\n}\\n\\n.bi-wifi-off::before {\\n    content: \\"\\\\f61b\\"\\n}\\n\\n.bi-wifi::before {\\n    content: \\"\\\\f61c\\"\\n}\\n\\n.bi-wind::before {\\n    content: \\"\\\\f61d\\"\\n}\\n\\n.bi-window-dock::before {\\n    content: \\"\\\\f61e\\"\\n}\\n\\n.bi-window-sidebar::before {\\n    content: \\"\\\\f61f\\"\\n}\\n\\n.bi-window::before {\\n    content: \\"\\\\f620\\"\\n}\\n\\n.bi-wrench::before {\\n    content: \\"\\\\f621\\"\\n}\\n\\n.bi-x-circle-fill::before {\\n    content: \\"\\\\f622\\"\\n}\\n\\n.bi-x-circle::before {\\n    content: \\"\\\\f623\\"\\n}\\n\\n.bi-x-diamond-fill::before {\\n    content: \\"\\\\f624\\"\\n}\\n\\n.bi-x-diamond::before {\\n    content: \\"\\\\f625\\"\\n}\\n\\n.bi-x-octagon-fill::before {\\n    content: \\"\\\\f626\\"\\n}\\n\\n.bi-x-octagon::before {\\n    content: \\"\\\\f627\\"\\n}\\n\\n.bi-x-square-fill::before {\\n    content: \\"\\\\f628\\"\\n}\\n\\n.bi-x-square::before {\\n    content: \\"\\\\f629\\"\\n}\\n\\n.bi-x::before {\\n    content: \\"\\\\f62a\\"\\n}\\n\\n.bi-youtube::before {\\n    content: \\"\\\\f62b\\"\\n}\\n\\n.bi-zoom-in::before {\\n    content: \\"\\\\f62c\\"\\n}\\n\\n.bi-zoom-out::before {\\n    content: \\"\\\\f62d\\"\\n}\\n\\n.bi-bank::before {\\n    content: \\"\\\\f62e\\"\\n}\\n\\n.bi-bank2::before {\\n    content: \\"\\\\f62f\\"\\n}\\n\\n.bi-bell-slash-fill::before {\\n    content: \\"\\\\f630\\"\\n}\\n\\n.bi-bell-slash::before {\\n    content: \\"\\\\f631\\"\\n}\\n\\n.bi-cash-coin::before {\\n    content: \\"\\\\f632\\"\\n}\\n\\n.bi-check-lg::before {\\n    content: \\"\\\\f633\\"\\n}\\n\\n.bi-coin::before {\\n    content: \\"\\\\f634\\"\\n}\\n\\n.bi-currency-bitcoin::before {\\n    content: \\"\\\\f635\\"\\n}\\n\\n.bi-currency-dollar::before {\\n    content: \\"\\\\f636\\"\\n}\\n\\n.bi-currency-euro::before {\\n    content: \\"\\\\f637\\"\\n}\\n\\n.bi-currency-exchange::before {\\n    content: \\"\\\\f638\\"\\n}\\n\\n.bi-currency-pound::before {\\n    content: \\"\\\\f639\\"\\n}\\n\\n.bi-currency-yen::before {\\n    content: \\"\\\\f63a\\"\\n}\\n\\n.bi-dash-lg::before {\\n    content: \\"\\\\f63b\\"\\n}\\n\\n.bi-exclamation-lg::before {\\n    content: \\"\\\\f63c\\"\\n}\\n\\n.bi-file-earmark-pdf-fill::before {\\n    content: \\"\\\\f63d\\"\\n}\\n\\n.bi-file-earmark-pdf::before {\\n    content: \\"\\\\f63e\\"\\n}\\n\\n.bi-file-pdf-fill::before {\\n    content: \\"\\\\f63f\\"\\n}\\n\\n.bi-file-pdf::before {\\n    content: \\"\\\\f640\\"\\n}\\n\\n.bi-gender-ambiguous::before {\\n    content: \\"\\\\f641\\"\\n}\\n\\n.bi-gender-female::before {\\n    content: \\"\\\\f642\\"\\n}\\n\\n.bi-gender-male::before {\\n    content: \\"\\\\f643\\"\\n}\\n\\n.bi-gender-trans::before {\\n    content: \\"\\\\f644\\"\\n}\\n\\n.bi-headset-vr::before {\\n    content: \\"\\\\f645\\"\\n}\\n\\n.bi-info-lg::before {\\n    content: \\"\\\\f646\\"\\n}\\n\\n.bi-mastodon::before {\\n    content: \\"\\\\f647\\"\\n}\\n\\n.bi-messenger::before {\\n    content: \\"\\\\f648\\"\\n}\\n\\n.bi-piggy-bank-fill::before {\\n    content: \\"\\\\f649\\"\\n}\\n\\n.bi-piggy-bank::before {\\n    content: \\"\\\\f64a\\"\\n}\\n\\n.bi-pin-map-fill::before {\\n    content: \\"\\\\f64b\\"\\n}\\n\\n.bi-pin-map::before {\\n    content: \\"\\\\f64c\\"\\n}\\n\\n.bi-plus-lg::before {\\n    content: \\"\\\\f64d\\"\\n}\\n\\n.bi-question-lg::before {\\n    content: \\"\\\\f64e\\"\\n}\\n\\n.bi-recycle::before {\\n    content: \\"\\\\f64f\\"\\n}\\n\\n.bi-reddit::before {\\n    content: \\"\\\\f650\\"\\n}\\n\\n.bi-safe-fill::before {\\n    content: \\"\\\\f651\\"\\n}\\n\\n.bi-safe2-fill::before {\\n    content: \\"\\\\f652\\"\\n}\\n\\n.bi-safe2::before {\\n    content: \\"\\\\f653\\"\\n}\\n\\n.bi-sd-card-fill::before {\\n    content: \\"\\\\f654\\"\\n}\\n\\n.bi-sd-card::before {\\n    content: \\"\\\\f655\\"\\n}\\n\\n.bi-skype::before {\\n    content: \\"\\\\f656\\"\\n}\\n\\n.bi-slash-lg::before {\\n    content: \\"\\\\f657\\"\\n}\\n\\n.bi-translate::before {\\n    content: \\"\\\\f658\\"\\n}\\n\\n.bi-x-lg::before {\\n    content: \\"\\\\f659\\"\\n}\\n\\n.bi-safe::before {\\n    content: \\"\\\\f65a\\"\\n}\\n\\n.bi-apple::before {\\n    content: \\"\\\\f65b\\"\\n}\\n\\n.bi-microsoft::before {\\n    content: \\"\\\\f65d\\"\\n}\\n\\n.bi-windows::before {\\n    content: \\"\\\\f65e\\"\\n}\\n\\n.bi-behance::before {\\n    content: \\"\\\\f65c\\"\\n}\\n\\n.bi-dribbble::before {\\n    content: \\"\\\\f65f\\"\\n}\\n\\n.bi-line::before {\\n    content: \\"\\\\f660\\"\\n}\\n\\n.bi-medium::before {\\n    content: \\"\\\\f661\\"\\n}\\n\\n.bi-paypal::before {\\n    content: \\"\\\\f662\\"\\n}\\n\\n.bi-pinterest::before {\\n    content: \\"\\\\f663\\"\\n}\\n\\n.bi-signal::before {\\n    content: \\"\\\\f664\\"\\n}\\n\\n.bi-snapchat::before {\\n    content: \\"\\\\f665\\"\\n}\\n\\n.bi-spotify::before {\\n    content: \\"\\\\f666\\"\\n}\\n\\n.bi-stack-overflow::before {\\n    content: \\"\\\\f667\\"\\n}\\n\\n.bi-strava::before {\\n    content: \\"\\\\f668\\"\\n}\\n\\n.bi-wordpress::before {\\n    content: \\"\\\\f669\\"\\n}\\n\\n.bi-vimeo::before {\\n    content: \\"\\\\f66a\\"\\n}\\n\\n.bi-activity::before {\\n    content: \\"\\\\f66b\\"\\n}\\n\\n.bi-easel2-fill::before {\\n    content: \\"\\\\f66c\\"\\n}\\n\\n.bi-easel2::before {\\n    content: \\"\\\\f66d\\"\\n}\\n\\n.bi-easel3-fill::before {\\n    content: \\"\\\\f66e\\"\\n}\\n\\n.bi-easel3::before {\\n    content: \\"\\\\f66f\\"\\n}\\n\\n.bi-fan::before {\\n    content: \\"\\\\f670\\"\\n}\\n\\n.bi-fingerprint::before {\\n    content: \\"\\\\f671\\"\\n}\\n\\n.bi-graph-down-arrow::before {\\n    content: \\"\\\\f672\\"\\n}\\n\\n.bi-graph-up-arrow::before {\\n    content: \\"\\\\f673\\"\\n}\\n\\n.bi-hypnotize::before {\\n    content: \\"\\\\f674\\"\\n}\\n\\n.bi-magic::before {\\n    content: \\"\\\\f675\\"\\n}\\n\\n.bi-person-rolodex::before {\\n    content: \\"\\\\f676\\"\\n}\\n\\n.bi-person-video::before {\\n    content: \\"\\\\f677\\"\\n}\\n\\n.bi-person-video2::before {\\n    content: \\"\\\\f678\\"\\n}\\n\\n.bi-person-video3::before {\\n    content: \\"\\\\f679\\"\\n}\\n\\n.bi-person-workspace::before {\\n    content: \\"\\\\f67a\\"\\n}\\n\\n.bi-radioactive::before {\\n    content: \\"\\\\f67b\\"\\n}\\n\\n.bi-webcam-fill::before {\\n    content: \\"\\\\f67c\\"\\n}\\n\\n.bi-webcam::before {\\n    content: \\"\\\\f67d\\"\\n}\\n\\n.bi-yin-yang::before {\\n    content: \\"\\\\f67e\\"\\n}\\n\\n.bi-bandaid-fill::before {\\n    content: \\"\\\\f680\\"\\n}\\n\\n.bi-bandaid::before {\\n    content: \\"\\\\f681\\"\\n}\\n\\n.bi-bluetooth::before {\\n    content: \\"\\\\f682\\"\\n}\\n\\n.bi-body-text::before {\\n    content: \\"\\\\f683\\"\\n}\\n\\n.bi-boombox::before {\\n    content: \\"\\\\f684\\"\\n}\\n\\n.bi-boxes::before {\\n    content: \\"\\\\f685\\"\\n}\\n\\n.bi-dpad-fill::before {\\n    content: \\"\\\\f686\\"\\n}\\n\\n.bi-dpad::before {\\n    content: \\"\\\\f687\\"\\n}\\n\\n.bi-ear-fill::before {\\n    content: \\"\\\\f688\\"\\n}\\n\\n.bi-ear::before {\\n    content: \\"\\\\f689\\"\\n}\\n\\n.bi-envelope-check-fill::before {\\n    content: \\"\\\\f68b\\"\\n}\\n\\n.bi-envelope-check::before {\\n    content: \\"\\\\f68c\\"\\n}\\n\\n.bi-envelope-dash-fill::before {\\n    content: \\"\\\\f68e\\"\\n}\\n\\n.bi-envelope-dash::before {\\n    content: \\"\\\\f68f\\"\\n}\\n\\n.bi-envelope-exclamation-fill::before {\\n    content: \\"\\\\f691\\"\\n}\\n\\n.bi-envelope-exclamation::before {\\n    content: \\"\\\\f692\\"\\n}\\n\\n.bi-envelope-plus-fill::before {\\n    content: \\"\\\\f693\\"\\n}\\n\\n.bi-envelope-plus::before {\\n    content: \\"\\\\f694\\"\\n}\\n\\n.bi-envelope-slash-fill::before {\\n    content: \\"\\\\f696\\"\\n}\\n\\n.bi-envelope-slash::before {\\n    content: \\"\\\\f697\\"\\n}\\n\\n.bi-envelope-x-fill::before {\\n    content: \\"\\\\f699\\"\\n}\\n\\n.bi-envelope-x::before {\\n    content: \\"\\\\f69a\\"\\n}\\n\\n.bi-explicit-fill::before {\\n    content: \\"\\\\f69b\\"\\n}\\n\\n.bi-explicit::before {\\n    content: \\"\\\\f69c\\"\\n}\\n\\n.bi-git::before {\\n    content: \\"\\\\f69d\\"\\n}\\n\\n.bi-infinity::before {\\n    content: \\"\\\\f69e\\"\\n}\\n\\n.bi-list-columns-reverse::before {\\n    content: \\"\\\\f69f\\"\\n}\\n\\n.bi-list-columns::before {\\n    content: \\"\\\\f6a0\\"\\n}\\n\\n.bi-meta::before {\\n    content: \\"\\\\f6a1\\"\\n}\\n\\n.bi-nintendo-switch::before {\\n    content: \\"\\\\f6a4\\"\\n}\\n\\n.bi-pc-display-horizontal::before {\\n    content: \\"\\\\f6a5\\"\\n}\\n\\n.bi-pc-display::before {\\n    content: \\"\\\\f6a6\\"\\n}\\n\\n.bi-pc-horizontal::before {\\n    content: \\"\\\\f6a7\\"\\n}\\n\\n.bi-pc::before {\\n    content: \\"\\\\f6a8\\"\\n}\\n\\n.bi-playstation::before {\\n    content: \\"\\\\f6a9\\"\\n}\\n\\n.bi-plus-slash-minus::before {\\n    content: \\"\\\\f6aa\\"\\n}\\n\\n.bi-projector-fill::before {\\n    content: \\"\\\\f6ab\\"\\n}\\n\\n.bi-projector::before {\\n    content: \\"\\\\f6ac\\"\\n}\\n\\n.bi-qr-code-scan::before {\\n    content: \\"\\\\f6ad\\"\\n}\\n\\n.bi-qr-code::before {\\n    content: \\"\\\\f6ae\\"\\n}\\n\\n.bi-quora::before {\\n    content: \\"\\\\f6af\\"\\n}\\n\\n.bi-quote::before {\\n    content: \\"\\\\f6b0\\"\\n}\\n\\n.bi-robot::before {\\n    content: \\"\\\\f6b1\\"\\n}\\n\\n.bi-send-check-fill::before {\\n    content: \\"\\\\f6b2\\"\\n}\\n\\n.bi-send-check::before {\\n    content: \\"\\\\f6b3\\"\\n}\\n\\n.bi-send-dash-fill::before {\\n    content: \\"\\\\f6b4\\"\\n}\\n\\n.bi-send-dash::before {\\n    content: \\"\\\\f6b5\\"\\n}\\n\\n.bi-send-exclamation-fill::before {\\n    content: \\"\\\\f6b7\\"\\n}\\n\\n.bi-send-exclamation::before {\\n    content: \\"\\\\f6b8\\"\\n}\\n\\n.bi-send-fill::before {\\n    content: \\"\\\\f6b9\\"\\n}\\n\\n.bi-send-plus-fill::before {\\n    content: \\"\\\\f6ba\\"\\n}\\n\\n.bi-send-plus::before {\\n    content: \\"\\\\f6bb\\"\\n}\\n\\n.bi-send-slash-fill::before {\\n    content: \\"\\\\f6bc\\"\\n}\\n\\n.bi-send-slash::before {\\n    content: \\"\\\\f6bd\\"\\n}\\n\\n.bi-send-x-fill::before {\\n    content: \\"\\\\f6be\\"\\n}\\n\\n.bi-send-x::before {\\n    content: \\"\\\\f6bf\\"\\n}\\n\\n.bi-send::before {\\n    content: \\"\\\\f6c0\\"\\n}\\n\\n.bi-steam::before {\\n    content: \\"\\\\f6c1\\"\\n}\\n\\n.bi-terminal-dash::before {\\n    content: \\"\\\\f6c3\\"\\n}\\n\\n.bi-terminal-plus::before {\\n    content: \\"\\\\f6c4\\"\\n}\\n\\n.bi-terminal-split::before {\\n    content: \\"\\\\f6c5\\"\\n}\\n\\n.bi-ticket-detailed-fill::before {\\n    content: \\"\\\\f6c6\\"\\n}\\n\\n.bi-ticket-detailed::before {\\n    content: \\"\\\\f6c7\\"\\n}\\n\\n.bi-ticket-fill::before {\\n    content: \\"\\\\f6c8\\"\\n}\\n\\n.bi-ticket-perforated-fill::before {\\n    content: \\"\\\\f6c9\\"\\n}\\n\\n.bi-ticket-perforated::before {\\n    content: \\"\\\\f6ca\\"\\n}\\n\\n.bi-ticket::before {\\n    content: \\"\\\\f6cb\\"\\n}\\n\\n.bi-tiktok::before {\\n    content: \\"\\\\f6cc\\"\\n}\\n\\n.bi-window-dash::before {\\n    content: \\"\\\\f6cd\\"\\n}\\n\\n.bi-window-desktop::before {\\n    content: \\"\\\\f6ce\\"\\n}\\n\\n.bi-window-fullscreen::before {\\n    content: \\"\\\\f6cf\\"\\n}\\n\\n.bi-window-plus::before {\\n    content: \\"\\\\f6d0\\"\\n}\\n\\n.bi-window-split::before {\\n    content: \\"\\\\f6d1\\"\\n}\\n\\n.bi-window-stack::before {\\n    content: \\"\\\\f6d2\\"\\n}\\n\\n.bi-window-x::before {\\n    content: \\"\\\\f6d3\\"\\n}\\n\\n.bi-xbox::before {\\n    content: \\"\\\\f6d4\\"\\n}\\n\\n.bi-ethernet::before {\\n    content: \\"\\\\f6d5\\"\\n}\\n\\n.bi-hdmi-fill::before {\\n    content: \\"\\\\f6d6\\"\\n}\\n\\n.bi-hdmi::before {\\n    content: \\"\\\\f6d7\\"\\n}\\n\\n.bi-usb-c-fill::before {\\n    content: \\"\\\\f6d8\\"\\n}\\n\\n.bi-usb-c::before {\\n    content: \\"\\\\f6d9\\"\\n}\\n\\n.bi-usb-fill::before {\\n    content: \\"\\\\f6da\\"\\n}\\n\\n.bi-usb-plug-fill::before {\\n    content: \\"\\\\f6db\\"\\n}\\n\\n.bi-usb-plug::before {\\n    content: \\"\\\\f6dc\\"\\n}\\n\\n.bi-usb-symbol::before {\\n    content: \\"\\\\f6dd\\"\\n}\\n\\n.bi-usb::before {\\n    content: \\"\\\\f6de\\"\\n}\\n\\n.bi-boombox-fill::before {\\n    content: \\"\\\\f6df\\"\\n}\\n\\n.bi-displayport::before {\\n    content: \\"\\\\f6e1\\"\\n}\\n\\n.bi-gpu-card::before {\\n    content: \\"\\\\f6e2\\"\\n}\\n\\n.bi-memory::before {\\n    content: \\"\\\\f6e3\\"\\n}\\n\\n.bi-modem-fill::before {\\n    content: \\"\\\\f6e4\\"\\n}\\n\\n.bi-modem::before {\\n    content: \\"\\\\f6e5\\"\\n}\\n\\n.bi-motherboard-fill::before {\\n    content: \\"\\\\f6e6\\"\\n}\\n\\n.bi-motherboard::before {\\n    content: \\"\\\\f6e7\\"\\n}\\n\\n.bi-optical-audio-fill::before {\\n    content: \\"\\\\f6e8\\"\\n}\\n\\n.bi-optical-audio::before {\\n    content: \\"\\\\f6e9\\"\\n}\\n\\n.bi-pci-card::before {\\n    content: \\"\\\\f6ea\\"\\n}\\n\\n.bi-router-fill::before {\\n    content: \\"\\\\f6eb\\"\\n}\\n\\n.bi-router::before {\\n    content: \\"\\\\f6ec\\"\\n}\\n\\n.bi-thunderbolt-fill::before {\\n    content: \\"\\\\f6ef\\"\\n}\\n\\n.bi-thunderbolt::before {\\n    content: \\"\\\\f6f0\\"\\n}\\n\\n.bi-usb-drive-fill::before {\\n    content: \\"\\\\f6f1\\"\\n}\\n\\n.bi-usb-drive::before {\\n    content: \\"\\\\f6f2\\"\\n}\\n\\n.bi-usb-micro-fill::before {\\n    content: \\"\\\\f6f3\\"\\n}\\n\\n.bi-usb-micro::before {\\n    content: \\"\\\\f6f4\\"\\n}\\n\\n.bi-usb-mini-fill::before {\\n    content: \\"\\\\f6f5\\"\\n}\\n\\n.bi-usb-mini::before {\\n    content: \\"\\\\f6f6\\"\\n}\\n\\n.bi-cloud-haze2::before {\\n    content: \\"\\\\f6f7\\"\\n}\\n\\n.bi-device-hdd-fill::before {\\n    content: \\"\\\\f6f8\\"\\n}\\n\\n.bi-device-hdd::before {\\n    content: \\"\\\\f6f9\\"\\n}\\n\\n.bi-device-ssd-fill::before {\\n    content: \\"\\\\f6fa\\"\\n}\\n\\n.bi-device-ssd::before {\\n    content: \\"\\\\f6fb\\"\\n}\\n\\n.bi-displayport-fill::before {\\n    content: \\"\\\\f6fc\\"\\n}\\n\\n.bi-mortarboard-fill::before {\\n    content: \\"\\\\f6fd\\"\\n}\\n\\n.bi-mortarboard::before {\\n    content: \\"\\\\f6fe\\"\\n}\\n\\n.bi-terminal-x::before {\\n    content: \\"\\\\f6ff\\"\\n}\\n\\n.bi-arrow-through-heart-fill::before {\\n    content: \\"\\\\f700\\"\\n}\\n\\n.bi-arrow-through-heart::before {\\n    content: \\"\\\\f701\\"\\n}\\n\\n.bi-badge-sd-fill::before {\\n    content: \\"\\\\f702\\"\\n}\\n\\n.bi-badge-sd::before {\\n    content: \\"\\\\f703\\"\\n}\\n\\n.bi-bag-heart-fill::before {\\n    content: \\"\\\\f704\\"\\n}\\n\\n.bi-bag-heart::before {\\n    content: \\"\\\\f705\\"\\n}\\n\\n.bi-balloon-fill::before {\\n    content: \\"\\\\f706\\"\\n}\\n\\n.bi-balloon-heart-fill::before {\\n    content: \\"\\\\f707\\"\\n}\\n\\n.bi-balloon-heart::before {\\n    content: \\"\\\\f708\\"\\n}\\n\\n.bi-balloon::before {\\n    content: \\"\\\\f709\\"\\n}\\n\\n.bi-box2-fill::before {\\n    content: \\"\\\\f70a\\"\\n}\\n\\n.bi-box2-heart-fill::before {\\n    content: \\"\\\\f70b\\"\\n}\\n\\n.bi-box2-heart::before {\\n    content: \\"\\\\f70c\\"\\n}\\n\\n.bi-box2::before {\\n    content: \\"\\\\f70d\\"\\n}\\n\\n.bi-braces-asterisk::before {\\n    content: \\"\\\\f70e\\"\\n}\\n\\n.bi-calendar-heart-fill::before {\\n    content: \\"\\\\f70f\\"\\n}\\n\\n.bi-calendar-heart::before {\\n    content: \\"\\\\f710\\"\\n}\\n\\n.bi-calendar2-heart-fill::before {\\n    content: \\"\\\\f711\\"\\n}\\n\\n.bi-calendar2-heart::before {\\n    content: \\"\\\\f712\\"\\n}\\n\\n.bi-chat-heart-fill::before {\\n    content: \\"\\\\f713\\"\\n}\\n\\n.bi-chat-heart::before {\\n    content: \\"\\\\f714\\"\\n}\\n\\n.bi-chat-left-heart-fill::before {\\n    content: \\"\\\\f715\\"\\n}\\n\\n.bi-chat-left-heart::before {\\n    content: \\"\\\\f716\\"\\n}\\n\\n.bi-chat-right-heart-fill::before {\\n    content: \\"\\\\f717\\"\\n}\\n\\n.bi-chat-right-heart::before {\\n    content: \\"\\\\f718\\"\\n}\\n\\n.bi-chat-square-heart-fill::before {\\n    content: \\"\\\\f719\\"\\n}\\n\\n.bi-chat-square-heart::before {\\n    content: \\"\\\\f71a\\"\\n}\\n\\n.bi-clipboard-check-fill::before {\\n    content: \\"\\\\f71b\\"\\n}\\n\\n.bi-clipboard-data-fill::before {\\n    content: \\"\\\\f71c\\"\\n}\\n\\n.bi-clipboard-fill::before {\\n    content: \\"\\\\f71d\\"\\n}\\n\\n.bi-clipboard-heart-fill::before {\\n    content: \\"\\\\f71e\\"\\n}\\n\\n.bi-clipboard-heart::before {\\n    content: \\"\\\\f71f\\"\\n}\\n\\n.bi-clipboard-minus-fill::before {\\n    content: \\"\\\\f720\\"\\n}\\n\\n.bi-clipboard-plus-fill::before {\\n    content: \\"\\\\f721\\"\\n}\\n\\n.bi-clipboard-pulse::before {\\n    content: \\"\\\\f722\\"\\n}\\n\\n.bi-clipboard-x-fill::before {\\n    content: \\"\\\\f723\\"\\n}\\n\\n.bi-clipboard2-check-fill::before {\\n    content: \\"\\\\f724\\"\\n}\\n\\n.bi-clipboard2-check::before {\\n    content: \\"\\\\f725\\"\\n}\\n\\n.bi-clipboard2-data-fill::before {\\n    content: \\"\\\\f726\\"\\n}\\n\\n.bi-clipboard2-data::before {\\n    content: \\"\\\\f727\\"\\n}\\n\\n.bi-clipboard2-fill::before {\\n    content: \\"\\\\f728\\"\\n}\\n\\n.bi-clipboard2-heart-fill::before {\\n    content: \\"\\\\f729\\"\\n}\\n\\n.bi-clipboard2-heart::before {\\n    content: \\"\\\\f72a\\"\\n}\\n\\n.bi-clipboard2-minus-fill::before {\\n    content: \\"\\\\f72b\\"\\n}\\n\\n.bi-clipboard2-minus::before {\\n    content: \\"\\\\f72c\\"\\n}\\n\\n.bi-clipboard2-plus-fill::before {\\n    content: \\"\\\\f72d\\"\\n}\\n\\n.bi-clipboard2-plus::before {\\n    content: \\"\\\\f72e\\"\\n}\\n\\n.bi-clipboard2-pulse-fill::before {\\n    content: \\"\\\\f72f\\"\\n}\\n\\n.bi-clipboard2-pulse::before {\\n    content: \\"\\\\f730\\"\\n}\\n\\n.bi-clipboard2-x-fill::before {\\n    content: \\"\\\\f731\\"\\n}\\n\\n.bi-clipboard2-x::before {\\n    content: \\"\\\\f732\\"\\n}\\n\\n.bi-clipboard2::before {\\n    content: \\"\\\\f733\\"\\n}\\n\\n.bi-emoji-kiss-fill::before {\\n    content: \\"\\\\f734\\"\\n}\\n\\n.bi-emoji-kiss::before {\\n    content: \\"\\\\f735\\"\\n}\\n\\n.bi-envelope-heart-fill::before {\\n    content: \\"\\\\f736\\"\\n}\\n\\n.bi-envelope-heart::before {\\n    content: \\"\\\\f737\\"\\n}\\n\\n.bi-envelope-open-heart-fill::before {\\n    content: \\"\\\\f738\\"\\n}\\n\\n.bi-envelope-open-heart::before {\\n    content: \\"\\\\f739\\"\\n}\\n\\n.bi-envelope-paper-fill::before {\\n    content: \\"\\\\f73a\\"\\n}\\n\\n.bi-envelope-paper-heart-fill::before {\\n    content: \\"\\\\f73b\\"\\n}\\n\\n.bi-envelope-paper-heart::before {\\n    content: \\"\\\\f73c\\"\\n}\\n\\n.bi-envelope-paper::before {\\n    content: \\"\\\\f73d\\"\\n}\\n\\n.bi-filetype-aac::before {\\n    content: \\"\\\\f73e\\"\\n}\\n\\n.bi-filetype-ai::before {\\n    content: \\"\\\\f73f\\"\\n}\\n\\n.bi-filetype-bmp::before {\\n    content: \\"\\\\f740\\"\\n}\\n\\n.bi-filetype-cs::before {\\n    content: \\"\\\\f741\\"\\n}\\n\\n.bi-filetype-css::before {\\n    content: \\"\\\\f742\\"\\n}\\n\\n.bi-filetype-csv::before {\\n    content: \\"\\\\f743\\"\\n}\\n\\n.bi-filetype-doc::before {\\n    content: \\"\\\\f744\\"\\n}\\n\\n.bi-filetype-docx::before {\\n    content: \\"\\\\f745\\"\\n}\\n\\n.bi-filetype-exe::before {\\n    content: \\"\\\\f746\\"\\n}\\n\\n.bi-filetype-gif::before {\\n    content: \\"\\\\f747\\"\\n}\\n\\n.bi-filetype-heic::before {\\n    content: \\"\\\\f748\\"\\n}\\n\\n.bi-filetype-html::before {\\n    content: \\"\\\\f749\\"\\n}\\n\\n.bi-filetype-java::before {\\n    content: \\"\\\\f74a\\"\\n}\\n\\n.bi-filetype-jpg::before {\\n    content: \\"\\\\f74b\\"\\n}\\n\\n.bi-filetype-js::before {\\n    content: \\"\\\\f74c\\"\\n}\\n\\n.bi-filetype-jsx::before {\\n    content: \\"\\\\f74d\\"\\n}\\n\\n.bi-filetype-key::before {\\n    content: \\"\\\\f74e\\"\\n}\\n\\n.bi-filetype-m4p::before {\\n    content: \\"\\\\f74f\\"\\n}\\n\\n.bi-filetype-md::before {\\n    content: \\"\\\\f750\\"\\n}\\n\\n.bi-filetype-mdx::before {\\n    content: \\"\\\\f751\\"\\n}\\n\\n.bi-filetype-mov::before {\\n    content: \\"\\\\f752\\"\\n}\\n\\n.bi-filetype-mp3::before {\\n    content: \\"\\\\f753\\"\\n}\\n\\n.bi-filetype-mp4::before {\\n    content: \\"\\\\f754\\"\\n}\\n\\n.bi-filetype-otf::before {\\n    content: \\"\\\\f755\\"\\n}\\n\\n.bi-filetype-pdf::before {\\n    content: \\"\\\\f756\\"\\n}\\n\\n.bi-filetype-php::before {\\n    content: \\"\\\\f757\\"\\n}\\n\\n.bi-filetype-png::before {\\n    content: \\"\\\\f758\\"\\n}\\n\\n.bi-filetype-ppt::before {\\n    content: \\"\\\\f75a\\"\\n}\\n\\n.bi-filetype-psd::before {\\n    content: \\"\\\\f75b\\"\\n}\\n\\n.bi-filetype-py::before {\\n    content: \\"\\\\f75c\\"\\n}\\n\\n.bi-filetype-raw::before {\\n    content: \\"\\\\f75d\\"\\n}\\n\\n.bi-filetype-rb::before {\\n    content: \\"\\\\f75e\\"\\n}\\n\\n.bi-filetype-sass::before {\\n    content: \\"\\\\f75f\\"\\n}\\n\\n.bi-filetype-scss::before {\\n    content: \\"\\\\f760\\"\\n}\\n\\n.bi-filetype-sh::before {\\n    content: \\"\\\\f761\\"\\n}\\n\\n.bi-filetype-svg::before {\\n    content: \\"\\\\f762\\"\\n}\\n\\n.bi-filetype-tiff::before {\\n    content: \\"\\\\f763\\"\\n}\\n\\n.bi-filetype-tsx::before {\\n    content: \\"\\\\f764\\"\\n}\\n\\n.bi-filetype-ttf::before {\\n    content: \\"\\\\f765\\"\\n}\\n\\n.bi-filetype-txt::before {\\n    content: \\"\\\\f766\\"\\n}\\n\\n.bi-filetype-wav::before {\\n    content: \\"\\\\f767\\"\\n}\\n\\n.bi-filetype-woff::before {\\n    content: \\"\\\\f768\\"\\n}\\n\\n.bi-filetype-xls::before {\\n    content: \\"\\\\f76a\\"\\n}\\n\\n.bi-filetype-xml::before {\\n    content: \\"\\\\f76b\\"\\n}\\n\\n.bi-filetype-yml::before {\\n    content: \\"\\\\f76c\\"\\n}\\n\\n.bi-heart-arrow::before {\\n    content: \\"\\\\f76d\\"\\n}\\n\\n.bi-heart-pulse-fill::before {\\n    content: \\"\\\\f76e\\"\\n}\\n\\n.bi-heart-pulse::before {\\n    content: \\"\\\\f76f\\"\\n}\\n\\n.bi-heartbreak-fill::before {\\n    content: \\"\\\\f770\\"\\n}\\n\\n.bi-heartbreak::before {\\n    content: \\"\\\\f771\\"\\n}\\n\\n.bi-hearts::before {\\n    content: \\"\\\\f772\\"\\n}\\n\\n.bi-hospital-fill::before {\\n    content: \\"\\\\f773\\"\\n}\\n\\n.bi-hospital::before {\\n    content: \\"\\\\f774\\"\\n}\\n\\n.bi-house-heart-fill::before {\\n    content: \\"\\\\f775\\"\\n}\\n\\n.bi-house-heart::before {\\n    content: \\"\\\\f776\\"\\n}\\n\\n.bi-incognito::before {\\n    content: \\"\\\\f777\\"\\n}\\n\\n.bi-magnet-fill::before {\\n    content: \\"\\\\f778\\"\\n}\\n\\n.bi-magnet::before {\\n    content: \\"\\\\f779\\"\\n}\\n\\n.bi-person-heart::before {\\n    content: \\"\\\\f77a\\"\\n}\\n\\n.bi-person-hearts::before {\\n    content: \\"\\\\f77b\\"\\n}\\n\\n.bi-phone-flip::before {\\n    content: \\"\\\\f77c\\"\\n}\\n\\n.bi-plugin::before {\\n    content: \\"\\\\f77d\\"\\n}\\n\\n.bi-postage-fill::before {\\n    content: \\"\\\\f77e\\"\\n}\\n\\n.bi-postage-heart-fill::before {\\n    content: \\"\\\\f77f\\"\\n}\\n\\n.bi-postage-heart::before {\\n    content: \\"\\\\f780\\"\\n}\\n\\n.bi-postage::before {\\n    content: \\"\\\\f781\\"\\n}\\n\\n.bi-postcard-fill::before {\\n    content: \\"\\\\f782\\"\\n}\\n\\n.bi-postcard-heart-fill::before {\\n    content: \\"\\\\f783\\"\\n}\\n\\n.bi-postcard-heart::before {\\n    content: \\"\\\\f784\\"\\n}\\n\\n.bi-postcard::before {\\n    content: \\"\\\\f785\\"\\n}\\n\\n.bi-search-heart-fill::before {\\n    content: \\"\\\\f786\\"\\n}\\n\\n.bi-search-heart::before {\\n    content: \\"\\\\f787\\"\\n}\\n\\n.bi-sliders2-vertical::before {\\n    content: \\"\\\\f788\\"\\n}\\n\\n.bi-sliders2::before {\\n    content: \\"\\\\f789\\"\\n}\\n\\n.bi-trash3-fill::before {\\n    content: \\"\\\\f78a\\"\\n}\\n\\n.bi-trash3::before {\\n    content: \\"\\\\f78b\\"\\n}\\n\\n.bi-valentine::before {\\n    content: \\"\\\\f78c\\"\\n}\\n\\n.bi-valentine2::before {\\n    content: \\"\\\\f78d\\"\\n}\\n\\n.bi-wrench-adjustable-circle-fill::before {\\n    content: \\"\\\\f78e\\"\\n}\\n\\n.bi-wrench-adjustable-circle::before {\\n    content: \\"\\\\f78f\\"\\n}\\n\\n.bi-wrench-adjustable::before {\\n    content: \\"\\\\f790\\"\\n}\\n\\n.bi-filetype-json::before {\\n    content: \\"\\\\f791\\"\\n}\\n\\n.bi-filetype-pptx::before {\\n    content: \\"\\\\f792\\"\\n}\\n\\n.bi-filetype-xlsx::before {\\n    content: \\"\\\\f793\\"\\n}\\n\\n.bi-1-circle-fill::before {\\n    content: \\"\\\\f796\\"\\n}\\n\\n.bi-1-circle::before {\\n    content: \\"\\\\f797\\"\\n}\\n\\n.bi-1-square-fill::before {\\n    content: \\"\\\\f798\\"\\n}\\n\\n.bi-1-square::before {\\n    content: \\"\\\\f799\\"\\n}\\n\\n.bi-2-circle-fill::before {\\n    content: \\"\\\\f79c\\"\\n}\\n\\n.bi-2-circle::before {\\n    content: \\"\\\\f79d\\"\\n}\\n\\n.bi-2-square-fill::before {\\n    content: \\"\\\\f79e\\"\\n}\\n\\n.bi-2-square::before {\\n    content: \\"\\\\f79f\\"\\n}\\n\\n.bi-3-circle-fill::before {\\n    content: \\"\\\\f7a2\\"\\n}\\n\\n.bi-3-circle::before {\\n    content: \\"\\\\f7a3\\"\\n}\\n\\n.bi-3-square-fill::before {\\n    content: \\"\\\\f7a4\\"\\n}\\n\\n.bi-3-square::before {\\n    content: \\"\\\\f7a5\\"\\n}\\n\\n.bi-4-circle-fill::before {\\n    content: \\"\\\\f7a8\\"\\n}\\n\\n.bi-4-circle::before {\\n    content: \\"\\\\f7a9\\"\\n}\\n\\n.bi-4-square-fill::before {\\n    content: \\"\\\\f7aa\\"\\n}\\n\\n.bi-4-square::before {\\n    content: \\"\\\\f7ab\\"\\n}\\n\\n.bi-5-circle-fill::before {\\n    content: \\"\\\\f7ae\\"\\n}\\n\\n.bi-5-circle::before {\\n    content: \\"\\\\f7af\\"\\n}\\n\\n.bi-5-square-fill::before {\\n    content: \\"\\\\f7b0\\"\\n}\\n\\n.bi-5-square::before {\\n    content: \\"\\\\f7b1\\"\\n}\\n\\n.bi-6-circle-fill::before {\\n    content: \\"\\\\f7b4\\"\\n}\\n\\n.bi-6-circle::before {\\n    content: \\"\\\\f7b5\\"\\n}\\n\\n.bi-6-square-fill::before {\\n    content: \\"\\\\f7b6\\"\\n}\\n\\n.bi-6-square::before {\\n    content: \\"\\\\f7b7\\"\\n}\\n\\n.bi-7-circle-fill::before {\\n    content: \\"\\\\f7ba\\"\\n}\\n\\n.bi-7-circle::before {\\n    content: \\"\\\\f7bb\\"\\n}\\n\\n.bi-7-square-fill::before {\\n    content: \\"\\\\f7bc\\"\\n}\\n\\n.bi-7-square::before {\\n    content: \\"\\\\f7bd\\"\\n}\\n\\n.bi-8-circle-fill::before {\\n    content: \\"\\\\f7c0\\"\\n}\\n\\n.bi-8-circle::before {\\n    content: \\"\\\\f7c1\\"\\n}\\n\\n.bi-8-square-fill::before {\\n    content: \\"\\\\f7c2\\"\\n}\\n\\n.bi-8-square::before {\\n    content: \\"\\\\f7c3\\"\\n}\\n\\n.bi-9-circle-fill::before {\\n    content: \\"\\\\f7c6\\"\\n}\\n\\n.bi-9-circle::before {\\n    content: \\"\\\\f7c7\\"\\n}\\n\\n.bi-9-square-fill::before {\\n    content: \\"\\\\f7c8\\"\\n}\\n\\n.bi-9-square::before {\\n    content: \\"\\\\f7c9\\"\\n}\\n\\n.bi-airplane-engines-fill::before {\\n    content: \\"\\\\f7ca\\"\\n}\\n\\n.bi-airplane-engines::before {\\n    content: \\"\\\\f7cb\\"\\n}\\n\\n.bi-airplane-fill::before {\\n    content: \\"\\\\f7cc\\"\\n}\\n\\n.bi-airplane::before {\\n    content: \\"\\\\f7cd\\"\\n}\\n\\n.bi-alexa::before {\\n    content: \\"\\\\f7ce\\"\\n}\\n\\n.bi-alipay::before {\\n    content: \\"\\\\f7cf\\"\\n}\\n\\n.bi-android::before {\\n    content: \\"\\\\f7d0\\"\\n}\\n\\n.bi-android2::before {\\n    content: \\"\\\\f7d1\\"\\n}\\n\\n.bi-box-fill::before {\\n    content: \\"\\\\f7d2\\"\\n}\\n\\n.bi-box-seam-fill::before {\\n    content: \\"\\\\f7d3\\"\\n}\\n\\n.bi-browser-chrome::before {\\n    content: \\"\\\\f7d4\\"\\n}\\n\\n.bi-browser-edge::before {\\n    content: \\"\\\\f7d5\\"\\n}\\n\\n.bi-browser-firefox::before {\\n    content: \\"\\\\f7d6\\"\\n}\\n\\n.bi-browser-safari::before {\\n    content: \\"\\\\f7d7\\"\\n}\\n\\n.bi-c-circle-fill::before {\\n    content: \\"\\\\f7da\\"\\n}\\n\\n.bi-c-circle::before {\\n    content: \\"\\\\f7db\\"\\n}\\n\\n.bi-c-square-fill::before {\\n    content: \\"\\\\f7dc\\"\\n}\\n\\n.bi-c-square::before {\\n    content: \\"\\\\f7dd\\"\\n}\\n\\n.bi-capsule-pill::before {\\n    content: \\"\\\\f7de\\"\\n}\\n\\n.bi-capsule::before {\\n    content: \\"\\\\f7df\\"\\n}\\n\\n.bi-car-front-fill::before {\\n    content: \\"\\\\f7e0\\"\\n}\\n\\n.bi-car-front::before {\\n    content: \\"\\\\f7e1\\"\\n}\\n\\n.bi-cassette-fill::before {\\n    content: \\"\\\\f7e2\\"\\n}\\n\\n.bi-cassette::before {\\n    content: \\"\\\\f7e3\\"\\n}\\n\\n.bi-cc-circle-fill::before {\\n    content: \\"\\\\f7e6\\"\\n}\\n\\n.bi-cc-circle::before {\\n    content: \\"\\\\f7e7\\"\\n}\\n\\n.bi-cc-square-fill::before {\\n    content: \\"\\\\f7e8\\"\\n}\\n\\n.bi-cc-square::before {\\n    content: \\"\\\\f7e9\\"\\n}\\n\\n.bi-cup-hot-fill::before {\\n    content: \\"\\\\f7ea\\"\\n}\\n\\n.bi-cup-hot::before {\\n    content: \\"\\\\f7eb\\"\\n}\\n\\n.bi-currency-rupee::before {\\n    content: \\"\\\\f7ec\\"\\n}\\n\\n.bi-dropbox::before {\\n    content: \\"\\\\f7ed\\"\\n}\\n\\n.bi-escape::before {\\n    content: \\"\\\\f7ee\\"\\n}\\n\\n.bi-fast-forward-btn-fill::before {\\n    content: \\"\\\\f7ef\\"\\n}\\n\\n.bi-fast-forward-btn::before {\\n    content: \\"\\\\f7f0\\"\\n}\\n\\n.bi-fast-forward-circle-fill::before {\\n    content: \\"\\\\f7f1\\"\\n}\\n\\n.bi-fast-forward-circle::before {\\n    content: \\"\\\\f7f2\\"\\n}\\n\\n.bi-fast-forward-fill::before {\\n    content: \\"\\\\f7f3\\"\\n}\\n\\n.bi-fast-forward::before {\\n    content: \\"\\\\f7f4\\"\\n}\\n\\n.bi-filetype-sql::before {\\n    content: \\"\\\\f7f5\\"\\n}\\n\\n.bi-fire::before {\\n    content: \\"\\\\f7f6\\"\\n}\\n\\n.bi-google-play::before {\\n    content: \\"\\\\f7f7\\"\\n}\\n\\n.bi-h-circle-fill::before {\\n    content: \\"\\\\f7fa\\"\\n}\\n\\n.bi-h-circle::before {\\n    content: \\"\\\\f7fb\\"\\n}\\n\\n.bi-h-square-fill::before {\\n    content: \\"\\\\f7fc\\"\\n}\\n\\n.bi-h-square::before {\\n    content: \\"\\\\f7fd\\"\\n}\\n\\n.bi-indent::before {\\n    content: \\"\\\\f7fe\\"\\n}\\n\\n.bi-lungs-fill::before {\\n    content: \\"\\\\f7ff\\"\\n}\\n\\n.bi-lungs::before {\\n    content: \\"\\\\f800\\"\\n}\\n\\n.bi-microsoft-teams::before {\\n    content: \\"\\\\f801\\"\\n}\\n\\n.bi-p-circle-fill::before {\\n    content: \\"\\\\f804\\"\\n}\\n\\n.bi-p-circle::before {\\n    content: \\"\\\\f805\\"\\n}\\n\\n.bi-p-square-fill::before {\\n    content: \\"\\\\f806\\"\\n}\\n\\n.bi-p-square::before {\\n    content: \\"\\\\f807\\"\\n}\\n\\n.bi-pass-fill::before {\\n    content: \\"\\\\f808\\"\\n}\\n\\n.bi-pass::before {\\n    content: \\"\\\\f809\\"\\n}\\n\\n.bi-prescription::before {\\n    content: \\"\\\\f80a\\"\\n}\\n\\n.bi-prescription2::before {\\n    content: \\"\\\\f80b\\"\\n}\\n\\n.bi-r-circle-fill::before {\\n    content: \\"\\\\f80e\\"\\n}\\n\\n.bi-r-circle::before {\\n    content: \\"\\\\f80f\\"\\n}\\n\\n.bi-r-square-fill::before {\\n    content: \\"\\\\f810\\"\\n}\\n\\n.bi-r-square::before {\\n    content: \\"\\\\f811\\"\\n}\\n\\n.bi-repeat-1::before {\\n    content: \\"\\\\f812\\"\\n}\\n\\n.bi-repeat::before {\\n    content: \\"\\\\f813\\"\\n}\\n\\n.bi-rewind-btn-fill::before {\\n    content: \\"\\\\f814\\"\\n}\\n\\n.bi-rewind-btn::before {\\n    content: \\"\\\\f815\\"\\n}\\n\\n.bi-rewind-circle-fill::before {\\n    content: \\"\\\\f816\\"\\n}\\n\\n.bi-rewind-circle::before {\\n    content: \\"\\\\f817\\"\\n}\\n\\n.bi-rewind-fill::before {\\n    content: \\"\\\\f818\\"\\n}\\n\\n.bi-rewind::before {\\n    content: \\"\\\\f819\\"\\n}\\n\\n.bi-train-freight-front-fill::before {\\n    content: \\"\\\\f81a\\"\\n}\\n\\n.bi-train-freight-front::before {\\n    content: \\"\\\\f81b\\"\\n}\\n\\n.bi-train-front-fill::before {\\n    content: \\"\\\\f81c\\"\\n}\\n\\n.bi-train-front::before {\\n    content: \\"\\\\f81d\\"\\n}\\n\\n.bi-train-lightrail-front-fill::before {\\n    content: \\"\\\\f81e\\"\\n}\\n\\n.bi-train-lightrail-front::before {\\n    content: \\"\\\\f81f\\"\\n}\\n\\n.bi-truck-front-fill::before {\\n    content: \\"\\\\f820\\"\\n}\\n\\n.bi-truck-front::before {\\n    content: \\"\\\\f821\\"\\n}\\n\\n.bi-ubuntu::before {\\n    content: \\"\\\\f822\\"\\n}\\n\\n.bi-unindent::before {\\n    content: \\"\\\\f823\\"\\n}\\n\\n.bi-unity::before {\\n    content: \\"\\\\f824\\"\\n}\\n\\n.bi-universal-access-circle::before {\\n    content: \\"\\\\f825\\"\\n}\\n\\n.bi-universal-access::before {\\n    content: \\"\\\\f826\\"\\n}\\n\\n.bi-virus::before {\\n    content: \\"\\\\f827\\"\\n}\\n\\n.bi-virus2::before {\\n    content: \\"\\\\f828\\"\\n}\\n\\n.bi-wechat::before {\\n    content: \\"\\\\f829\\"\\n}\\n\\n.bi-yelp::before {\\n    content: \\"\\\\f82a\\"\\n}\\n\\n.bi-sign-stop-fill::before {\\n    content: \\"\\\\f82b\\"\\n}\\n\\n.bi-sign-stop-lights-fill::before {\\n    content: \\"\\\\f82c\\"\\n}\\n\\n.bi-sign-stop-lights::before {\\n    content: \\"\\\\f82d\\"\\n}\\n\\n.bi-sign-stop::before {\\n    content: \\"\\\\f82e\\"\\n}\\n\\n.bi-sign-turn-left-fill::before {\\n    content: \\"\\\\f82f\\"\\n}\\n\\n.bi-sign-turn-left::before {\\n    content: \\"\\\\f830\\"\\n}\\n\\n.bi-sign-turn-right-fill::before {\\n    content: \\"\\\\f831\\"\\n}\\n\\n.bi-sign-turn-right::before {\\n    content: \\"\\\\f832\\"\\n}\\n\\n.bi-sign-turn-slight-left-fill::before {\\n    content: \\"\\\\f833\\"\\n}\\n\\n.bi-sign-turn-slight-left::before {\\n    content: \\"\\\\f834\\"\\n}\\n\\n.bi-sign-turn-slight-right-fill::before {\\n    content: \\"\\\\f835\\"\\n}\\n\\n.bi-sign-turn-slight-right::before {\\n    content: \\"\\\\f836\\"\\n}\\n\\n.bi-sign-yield-fill::before {\\n    content: \\"\\\\f837\\"\\n}\\n\\n.bi-sign-yield::before {\\n    content: \\"\\\\f838\\"\\n}\\n\\n.bi-ev-station-fill::before {\\n    content: \\"\\\\f839\\"\\n}\\n\\n.bi-ev-station::before {\\n    content: \\"\\\\f83a\\"\\n}\\n\\n.bi-fuel-pump-diesel-fill::before {\\n    content: \\"\\\\f83b\\"\\n}\\n\\n.bi-fuel-pump-diesel::before {\\n    content: \\"\\\\f83c\\"\\n}\\n\\n.bi-fuel-pump-fill::before {\\n    content: \\"\\\\f83d\\"\\n}\\n\\n.bi-fuel-pump::before {\\n    content: \\"\\\\f83e\\"\\n}\\n\\n.bi-0-circle-fill::before {\\n    content: \\"\\\\f83f\\"\\n}\\n\\n.bi-0-circle::before {\\n    content: \\"\\\\f840\\"\\n}\\n\\n.bi-0-square-fill::before {\\n    content: \\"\\\\f841\\"\\n}\\n\\n.bi-0-square::before {\\n    content: \\"\\\\f842\\"\\n}\\n\\n.bi-rocket-fill::before {\\n    content: \\"\\\\f843\\"\\n}\\n\\n.bi-rocket-takeoff-fill::before {\\n    content: \\"\\\\f844\\"\\n}\\n\\n.bi-rocket-takeoff::before {\\n    content: \\"\\\\f845\\"\\n}\\n\\n.bi-rocket::before {\\n    content: \\"\\\\f846\\"\\n}\\n\\n.bi-stripe::before {\\n    content: \\"\\\\f847\\"\\n}\\n\\n.bi-subscript::before {\\n    content: \\"\\\\f848\\"\\n}\\n\\n.bi-superscript::before {\\n    content: \\"\\\\f849\\"\\n}\\n\\n.bi-trello::before {\\n    content: \\"\\\\f84a\\"\\n}\\n\\n.bi-envelope-at-fill::before {\\n    content: \\"\\\\f84b\\"\\n}\\n\\n.bi-envelope-at::before {\\n    content: \\"\\\\f84c\\"\\n}\\n\\n.bi-regex::before {\\n    content: \\"\\\\f84d\\"\\n}\\n\\n.bi-text-wrap::before {\\n    content: \\"\\\\f84e\\"\\n}\\n\\n.bi-sign-dead-end-fill::before {\\n    content: \\"\\\\f84f\\"\\n}\\n\\n.bi-sign-dead-end::before {\\n    content: \\"\\\\f850\\"\\n}\\n\\n.bi-sign-do-not-enter-fill::before {\\n    content: \\"\\\\f851\\"\\n}\\n\\n.bi-sign-do-not-enter::before {\\n    content: \\"\\\\f852\\"\\n}\\n\\n.bi-sign-intersection-fill::before {\\n    content: \\"\\\\f853\\"\\n}\\n\\n.bi-sign-intersection-side-fill::before {\\n    content: \\"\\\\f854\\"\\n}\\n\\n.bi-sign-intersection-side::before {\\n    content: \\"\\\\f855\\"\\n}\\n\\n.bi-sign-intersection-t-fill::before {\\n    content: \\"\\\\f856\\"\\n}\\n\\n.bi-sign-intersection-t::before {\\n    content: \\"\\\\f857\\"\\n}\\n\\n.bi-sign-intersection-y-fill::before {\\n    content: \\"\\\\f858\\"\\n}\\n\\n.bi-sign-intersection-y::before {\\n    content: \\"\\\\f859\\"\\n}\\n\\n.bi-sign-intersection::before {\\n    content: \\"\\\\f85a\\"\\n}\\n\\n.bi-sign-merge-left-fill::before {\\n    content: \\"\\\\f85b\\"\\n}\\n\\n.bi-sign-merge-left::before {\\n    content: \\"\\\\f85c\\"\\n}\\n\\n.bi-sign-merge-right-fill::before {\\n    content: \\"\\\\f85d\\"\\n}\\n\\n.bi-sign-merge-right::before {\\n    content: \\"\\\\f85e\\"\\n}\\n\\n.bi-sign-no-left-turn-fill::before {\\n    content: \\"\\\\f85f\\"\\n}\\n\\n.bi-sign-no-left-turn::before {\\n    content: \\"\\\\f860\\"\\n}\\n\\n.bi-sign-no-parking-fill::before {\\n    content: \\"\\\\f861\\"\\n}\\n\\n.bi-sign-no-parking::before {\\n    content: \\"\\\\f862\\"\\n}\\n\\n.bi-sign-no-right-turn-fill::before {\\n    content: \\"\\\\f863\\"\\n}\\n\\n.bi-sign-no-right-turn::before {\\n    content: \\"\\\\f864\\"\\n}\\n\\n.bi-sign-railroad-fill::before {\\n    content: \\"\\\\f865\\"\\n}\\n\\n.bi-sign-railroad::before {\\n    content: \\"\\\\f866\\"\\n}\\n\\n.bi-building-add::before {\\n    content: \\"\\\\f867\\"\\n}\\n\\n.bi-building-check::before {\\n    content: \\"\\\\f868\\"\\n}\\n\\n.bi-building-dash::before {\\n    content: \\"\\\\f869\\"\\n}\\n\\n.bi-building-down::before {\\n    content: \\"\\\\f86a\\"\\n}\\n\\n.bi-building-exclamation::before {\\n    content: \\"\\\\f86b\\"\\n}\\n\\n.bi-building-fill-add::before {\\n    content: \\"\\\\f86c\\"\\n}\\n\\n.bi-building-fill-check::before {\\n    content: \\"\\\\f86d\\"\\n}\\n\\n.bi-building-fill-dash::before {\\n    content: \\"\\\\f86e\\"\\n}\\n\\n.bi-building-fill-down::before {\\n    content: \\"\\\\f86f\\"\\n}\\n\\n.bi-building-fill-exclamation::before {\\n    content: \\"\\\\f870\\"\\n}\\n\\n.bi-building-fill-gear::before {\\n    content: \\"\\\\f871\\"\\n}\\n\\n.bi-building-fill-lock::before {\\n    content: \\"\\\\f872\\"\\n}\\n\\n.bi-building-fill-slash::before {\\n    content: \\"\\\\f873\\"\\n}\\n\\n.bi-building-fill-up::before {\\n    content: \\"\\\\f874\\"\\n}\\n\\n.bi-building-fill-x::before {\\n    content: \\"\\\\f875\\"\\n}\\n\\n.bi-building-fill::before {\\n    content: \\"\\\\f876\\"\\n}\\n\\n.bi-building-gear::before {\\n    content: \\"\\\\f877\\"\\n}\\n\\n.bi-building-lock::before {\\n    content: \\"\\\\f878\\"\\n}\\n\\n.bi-building-slash::before {\\n    content: \\"\\\\f879\\"\\n}\\n\\n.bi-building-up::before {\\n    content: \\"\\\\f87a\\"\\n}\\n\\n.bi-building-x::before {\\n    content: \\"\\\\f87b\\"\\n}\\n\\n.bi-buildings-fill::before {\\n    content: \\"\\\\f87c\\"\\n}\\n\\n.bi-buildings::before {\\n    content: \\"\\\\f87d\\"\\n}\\n\\n.bi-bus-front-fill::before {\\n    content: \\"\\\\f87e\\"\\n}\\n\\n.bi-bus-front::before {\\n    content: \\"\\\\f87f\\"\\n}\\n\\n.bi-ev-front-fill::before {\\n    content: \\"\\\\f880\\"\\n}\\n\\n.bi-ev-front::before {\\n    content: \\"\\\\f881\\"\\n}\\n\\n.bi-globe-americas::before {\\n    content: \\"\\\\f882\\"\\n}\\n\\n.bi-globe-asia-australia::before {\\n    content: \\"\\\\f883\\"\\n}\\n\\n.bi-globe-central-south-asia::before {\\n    content: \\"\\\\f884\\"\\n}\\n\\n.bi-globe-europe-africa::before {\\n    content: \\"\\\\f885\\"\\n}\\n\\n.bi-house-add-fill::before {\\n    content: \\"\\\\f886\\"\\n}\\n\\n.bi-house-add::before {\\n    content: \\"\\\\f887\\"\\n}\\n\\n.bi-house-check-fill::before {\\n    content: \\"\\\\f888\\"\\n}\\n\\n.bi-house-check::before {\\n    content: \\"\\\\f889\\"\\n}\\n\\n.bi-house-dash-fill::before {\\n    content: \\"\\\\f88a\\"\\n}\\n\\n.bi-house-dash::before {\\n    content: \\"\\\\f88b\\"\\n}\\n\\n.bi-house-down-fill::before {\\n    content: \\"\\\\f88c\\"\\n}\\n\\n.bi-house-down::before {\\n    content: \\"\\\\f88d\\"\\n}\\n\\n.bi-house-exclamation-fill::before {\\n    content: \\"\\\\f88e\\"\\n}\\n\\n.bi-house-exclamation::before {\\n    content: \\"\\\\f88f\\"\\n}\\n\\n.bi-house-gear-fill::before {\\n    content: \\"\\\\f890\\"\\n}\\n\\n.bi-house-gear::before {\\n    content: \\"\\\\f891\\"\\n}\\n\\n.bi-house-lock-fill::before {\\n    content: \\"\\\\f892\\"\\n}\\n\\n.bi-house-lock::before {\\n    content: \\"\\\\f893\\"\\n}\\n\\n.bi-house-slash-fill::before {\\n    content: \\"\\\\f894\\"\\n}\\n\\n.bi-house-slash::before {\\n    content: \\"\\\\f895\\"\\n}\\n\\n.bi-house-up-fill::before {\\n    content: \\"\\\\f896\\"\\n}\\n\\n.bi-house-up::before {\\n    content: \\"\\\\f897\\"\\n}\\n\\n.bi-house-x-fill::before {\\n    content: \\"\\\\f898\\"\\n}\\n\\n.bi-house-x::before {\\n    content: \\"\\\\f899\\"\\n}\\n\\n.bi-person-add::before {\\n    content: \\"\\\\f89a\\"\\n}\\n\\n.bi-person-down::before {\\n    content: \\"\\\\f89b\\"\\n}\\n\\n.bi-person-exclamation::before {\\n    content: \\"\\\\f89c\\"\\n}\\n\\n.bi-person-fill-add::before {\\n    content: \\"\\\\f89d\\"\\n}\\n\\n.bi-person-fill-check::before {\\n    content: \\"\\\\f89e\\"\\n}\\n\\n.bi-person-fill-dash::before {\\n    content: \\"\\\\f89f\\"\\n}\\n\\n.bi-person-fill-down::before {\\n    content: \\"\\\\f8a0\\"\\n}\\n\\n.bi-person-fill-exclamation::before {\\n    content: \\"\\\\f8a1\\"\\n}\\n\\n.bi-person-fill-gear::before {\\n    content: \\"\\\\f8a2\\"\\n}\\n\\n.bi-person-fill-lock::before {\\n    content: \\"\\\\f8a3\\"\\n}\\n\\n.bi-person-fill-slash::before {\\n    content: \\"\\\\f8a4\\"\\n}\\n\\n.bi-person-fill-up::before {\\n    content: \\"\\\\f8a5\\"\\n}\\n\\n.bi-person-fill-x::before {\\n    content: \\"\\\\f8a6\\"\\n}\\n\\n.bi-person-gear::before {\\n    content: \\"\\\\f8a7\\"\\n}\\n\\n.bi-person-lock::before {\\n    content: \\"\\\\f8a8\\"\\n}\\n\\n.bi-person-slash::before {\\n    content: \\"\\\\f8a9\\"\\n}\\n\\n.bi-person-up::before {\\n    content: \\"\\\\f8aa\\"\\n}\\n\\n.bi-scooter::before {\\n    content: \\"\\\\f8ab\\"\\n}\\n\\n.bi-taxi-front-fill::before {\\n    content: \\"\\\\f8ac\\"\\n}\\n\\n.bi-taxi-front::before {\\n    content: \\"\\\\f8ad\\"\\n}\\n\\n.bi-amd::before {\\n    content: \\"\\\\f8ae\\"\\n}\\n\\n.bi-database-add::before {\\n    content: \\"\\\\f8af\\"\\n}\\n\\n.bi-database-check::before {\\n    content: \\"\\\\f8b0\\"\\n}\\n\\n.bi-database-dash::before {\\n    content: \\"\\\\f8b1\\"\\n}\\n\\n.bi-database-down::before {\\n    content: \\"\\\\f8b2\\"\\n}\\n\\n.bi-database-exclamation::before {\\n    content: \\"\\\\f8b3\\"\\n}\\n\\n.bi-database-fill-add::before {\\n    content: \\"\\\\f8b4\\"\\n}\\n\\n.bi-database-fill-check::before {\\n    content: \\"\\\\f8b5\\"\\n}\\n\\n.bi-database-fill-dash::before {\\n    content: \\"\\\\f8b6\\"\\n}\\n\\n.bi-database-fill-down::before {\\n    content: \\"\\\\f8b7\\"\\n}\\n\\n.bi-database-fill-exclamation::before {\\n    content: \\"\\\\f8b8\\"\\n}\\n\\n.bi-database-fill-gear::before {\\n    content: \\"\\\\f8b9\\"\\n}\\n\\n.bi-database-fill-lock::before {\\n    content: \\"\\\\f8ba\\"\\n}\\n\\n.bi-database-fill-slash::before {\\n    content: \\"\\\\f8bb\\"\\n}\\n\\n.bi-database-fill-up::before {\\n    content: \\"\\\\f8bc\\"\\n}\\n\\n.bi-database-fill-x::before {\\n    content: \\"\\\\f8bd\\"\\n}\\n\\n.bi-database-fill::before {\\n    content: \\"\\\\f8be\\"\\n}\\n\\n.bi-database-gear::before {\\n    content: \\"\\\\f8bf\\"\\n}\\n\\n.bi-database-lock::before {\\n    content: \\"\\\\f8c0\\"\\n}\\n\\n.bi-database-slash::before {\\n    content: \\"\\\\f8c1\\"\\n}\\n\\n.bi-database-up::before {\\n    content: \\"\\\\f8c2\\"\\n}\\n\\n.bi-database-x::before {\\n    content: \\"\\\\f8c3\\"\\n}\\n\\n.bi-database::before {\\n    content: \\"\\\\f8c4\\"\\n}\\n\\n.bi-houses-fill::before {\\n    content: \\"\\\\f8c5\\"\\n}\\n\\n.bi-houses::before {\\n    content: \\"\\\\f8c6\\"\\n}\\n\\n.bi-nvidia::before {\\n    content: \\"\\\\f8c7\\"\\n}\\n\\n.bi-person-vcard-fill::before {\\n    content: \\"\\\\f8c8\\"\\n}\\n\\n.bi-person-vcard::before {\\n    content: \\"\\\\f8c9\\"\\n}\\n\\n.bi-sina-weibo::before {\\n    content: \\"\\\\f8ca\\"\\n}\\n\\n.bi-tencent-qq::before {\\n    content: \\"\\\\f8cb\\"\\n}\\n\\n.bi-wikipedia::before {\\n    content: \\"\\\\f8cc\\"\\n}";

    leistrap.addStyle(style);
    leistrap.addStyle(leisR);
    leistrap.addStyle(icons);
    leisMain();

})();
</script></body></html>`